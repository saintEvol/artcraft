//! Catalog + load-state tracking (plan section 15.2).

use std::collections::HashMap;

use bevy::asset::{AssetServer, Handle, LoadState};
use bevy::prelude::*;

use crate::animation_2d::FrameTable;
use crate::json_asset::JsonAsset;
use crate::lod::GameAssetLodChain;
use crate::manifest::{GameAssetPackManifest, ManifestAsset, ManifestDependency, ManifestRig};
use crate::GameAssetId;

/// Loaded 2D animation state: the atlas page, the parsed frame table and
/// the arbitrary-rect layout built from it (plan 12.2).
#[derive(Debug, Clone, Default)]
pub struct GameAssetAnimation2dEntry {
  pub atlas_image: Option<Handle<Image>>,
  pub frames_handle: Option<Handle<JsonAsset>>,
  /// Parsed once the frames.json asset finishes loading; None until then.
  pub table: Option<FrameTable>,
  pub pixels_per_world_unit: f32,
  /// nearest | linear (per-asset sampling; never ImagePlugin defaults).
  pub sampling: String,
  pub layout: Option<Handle<TextureAtlasLayout>>,
}

/// Loaded 3D animation state: the single clip plus the skeleton map that
/// owns its loop/duration metadata (plan 11.2: no second copy of clip
/// metadata).
#[derive(Debug, Clone, Default)]
pub struct GameAssetAnimation3dEntry {
  pub clip: Option<Handle<AnimationClip>>,
  pub skeleton_map: Option<Handle<JsonAsset>>,
  /// Parsed skeleton map playback metadata.
  pub looping: bool,
  pub clip_name: String,
}

/// One catalogued asset: identity + version + loaded handles + spec.
#[derive(Debug, Clone)]
pub struct GameAssetEntry {
  pub id: GameAssetId,
  /// Manifest asset identity (2.0 dependency addressing).
  pub asset_id: String,
  pub version_id: String,
  pub display_name: String,
  pub kind: String,
  /// 2.0 dependencies as delivered (anim_3d carries one rig).
  pub dependencies: Vec<ManifestDependency>,
  /// Handles to every file role, by role name.
  pub image: Option<Handle<Image>>,
  pub render_image: Option<Handle<Image>>,
  pub atlas: Option<crate::manifest::ManifestAtlas>,
  pub pixels_per_world_unit: f32,
  pub scene: Option<Handle<WorldAsset>>,
  pub width: u32,
  pub height: u32,
  pub anchor: (f32, f32),
  pub sampling: String,
  pub triangles: Option<u64>,
  pub collision: Option<crate::spawn::GameAssetCollisionDescriptor>,
  /// Explicit LOD chain (plan 13.5): None when the asset ships main-only.
  pub lod: Option<GameAssetLodChain>,
  /// character_3d rig binding contract (2.0).
  pub rig: Option<ManifestRig>,
  pub animation_2d: Option<GameAssetAnimation2dEntry>,
  pub animation_3d: Option<GameAssetAnimation3dEntry>,
}

/// The catalog maps stable IDs to versions/handles. Re-importing a pack
/// with updated content UPDATES entries in place; [`GameAssetId`]s stay
/// valid, which is the update-without-losing-references guarantee.
#[derive(Debug, Clone, Default, Resource)]
pub struct GameAssetCatalog {
  pub namespace: String,
  pub pack_id: Option<String>,
  pub entries: HashMap<GameAssetId, GameAssetEntry>,
  /// Assets the pack lists but the catalog refused (e.g. no main file):
  /// surfaced as Failed load states with the reason, never silently
  /// dropped (plan 15.3: missing/damaged resources must fail loudly).
  pub problems: HashMap<GameAssetId, String>,
}

impl GameAssetCatalog {
  /// Load every pack file through the AssetServer and catalogue handles.
  /// Files load asynchronously; readiness is tracked by
  /// [`crate::state::GameAssetLoadState`].
  pub fn load_pack(
    &mut self,
    asset_server: &AssetServer,
    manifest: &GameAssetPackManifest,
    pack_root: &str,
  ) {
    self.namespace = manifest.project_namespace();
    self.pack_id = Some(manifest.pack_id.clone());
    self.problems.clear();
    for asset in &manifest.assets {
      self.load_asset(asset_server, asset, pack_root);
    }
  }

  /// Explicit resource reload after a verified local installation. Existing
  /// helper-spawned roots keep their entity ids and game transforms.
  pub fn reload_pack(
    &mut self,
    server: &AssetServer,
    manifest: &GameAssetPackManifest,
    pack_root: &str,
  ) {
    for asset in &manifest.assets {
      for file in &asset.files {
        if ["main", "lod", "atlas_page"].contains(&file.role.as_str()) {
          server.reload(pack_path(pack_root, &file.path));
        }
      }
    }
    self.load_pack(server, manifest, pack_root);
  }

  fn load_asset(&mut self, asset_server: &AssetServer, asset: &ManifestAsset, pack_root: &str) {
    // 2.0 animation/character keys live in per-kind directories so the
    // same stable key can exist as anim_2d and anim_3d (manifest.rs).
    let id = GameAssetId::new(&self.namespace, asset.catalog_key());
    let main_file = asset
      .image
      .as_ref()
      .and_then(|image| image.atlas.as_ref())
      .and_then(|atlas| asset.files.get(atlas.page_file_index))
      .or_else(|| asset.main_file())
      .or_else(|| asset.files.iter().find(|file| file.role == "main"));
    let Some(main_file) = main_file else {
      self.problems.insert(id, "asset lists no main file".to_string());
      return;
    };
    let main_path = pack_path(pack_root, &main_file.path);

    let (image, scene, lod) = match asset.kind.as_str() {
      "icon_2d" | "sprite_2d" => {
        (Some(asset_server.load::<bevy::image::Image>(&main_path)), None, None)
      },
      "prop_3d" | "character_3d" => {
        let scene = asset_server.load(
          bevy::gltf::GltfAssetLabel::Scene(
            asset.mesh.as_ref().map(|m| m.scene_index).unwrap_or(0),
          )
          .from_asset(main_path.clone()),
        );
        // Load every lod file's scene into the chain skeleton (plan
        // 13.5: the chain, not glTF, carries LOD behavior).
        let lod = asset.mesh.as_ref().and_then(|mesh| mesh.lod.as_ref()).map(|block| {
          let mut chain = GameAssetLodChain::from_manifest(block);
          for level in chain.levels.iter_mut() {
            let Some(manifest_level) = block.levels.iter().find(|l| l.level == level.level) else {
              continue;
            };
            let Some(file) = asset.files.get(manifest_level.file_index) else {
              continue;
            };
            let path = pack_path(pack_root, &file.path);
            level.scene = asset_server
              .load(bevy::gltf::GltfAssetLabel::Scene(manifest_level.scene_index).from_asset(path));
          }
          chain
        });
        (None, Some(scene), lod)
      },
      // Single-clip animation GLB: the map (loaded beside it) owns the
      // loop/duration metadata.
      "anim_3d" => (None, None, None),
      // 2D frames arrive as one extruded atlas page + a frames.json.
      "anim_2d" => (None, None, None),
      _ => (None, None, None),
    };

    let mut animation_2d = None;
    let mut animation_3d = None;
    match asset.kind.as_str() {
      "anim_2d" => {
        if let Some(block) = &asset.animation_2d {
          let frames_handle = asset
            .files
            .iter()
            .find(|file| file.role == block.frames_file.role && file.ordinal == block.frames_file.ordinal)
            .map(|file| asset_server.load::<JsonAsset>(&pack_path(pack_root, &file.path)));
          animation_2d = Some(GameAssetAnimation2dEntry {
            atlas_image: Some(asset_server.load::<bevy::image::Image>(&main_path)),
            frames_handle,
            table: None,
            pixels_per_world_unit: block.pixels_per_world_unit,
            sampling: block.sampling.clone(),
            layout: None,
          });
        }
      },
      "anim_3d" => {
        if let Some(block) = &asset.animation_3d {
          let skeleton_map = asset
            .files
            .iter()
            .find(|file| file.role == block.skeleton_map_file.role && file.ordinal == block.skeleton_map_file.ordinal)
            .map(|file| asset_server.load::<JsonAsset>(&pack_path(pack_root, &file.path)));
          animation_3d = Some(GameAssetAnimation3dEntry {
            clip: Some(asset_server.load(
              bevy::gltf::GltfAssetLabel::Animation(0).from_asset(main_path.clone()),
            )),
            skeleton_map,
            looping: false,
            clip_name: String::new(),
          });
        }
      },
      _ => {},
    }

    let entry = GameAssetEntry {
      id: id.clone(),
      asset_id: asset.asset_id.clone(),
      version_id: asset.version_id.clone(),
      display_name: if asset.display_name.trim().is_empty() {
        asset.catalog_key()
      } else {
        asset.display_name.clone()
      },
      kind: asset.kind.clone(),
      dependencies: asset.dependencies.clone().unwrap_or_default(),
      image,
      render_image: None,
      atlas: asset.image.as_ref().and_then(|i| i.atlas.clone()),
      pixels_per_world_unit: asset
        .animation_2d
        .as_ref()
        .map(|block| block.pixels_per_world_unit)
        .or_else(|| asset.image.as_ref().map(|i| i.pixels_per_world_unit))
        .unwrap_or(100.0),
      scene,
      // anim_2d canvas/anchor arrive with frames.json; filled by the
      // prepare system once it parses.
      width: asset
        .image
        .as_ref()
        .map(|i| i.atlas.as_ref().map(|a| a.uncropped_size.width).unwrap_or(i.width))
        .unwrap_or(0),
      height: asset
        .image
        .as_ref()
        .map(|i| i.atlas.as_ref().map(|a| a.uncropped_size.height).unwrap_or(i.height))
        .unwrap_or(0),
      anchor: asset
        .animation_2d
        .as_ref()
        .map(|_| (0.5, 0.5))
        .or_else(|| {
          asset.image.as_ref().map(|i| {
            i.atlas.as_ref().map(|a| (a.anchor.x, a.anchor.y)).unwrap_or((i.anchor.x, i.anchor.y))
          })
        })
        .unwrap_or((0.5, 0.5)),
      sampling: asset
        .animation_2d
        .as_ref()
        .map(|block| block.sampling.clone())
        .or_else(|| asset.image.as_ref().map(|i| i.sampling.clone()))
        .unwrap_or_else(|| "linear".to_string()),
      triangles: asset.mesh.as_ref().and_then(|m| m.triangles),
      collision: asset
        .mesh
        .as_ref()
        .and_then(|m| m.collision.as_ref())
        .and_then(|c| crate::spawn::GameAssetCollisionDescriptor::from_manifest(c)),
      lod,
      rig: asset.rig.clone(),
      animation_2d,
      animation_3d,
    };
    self.entries.insert(id, entry);
  }

  pub fn get(&self, id: &GameAssetId) -> Option<&GameAssetEntry> {
    self.entries.get(id)
  }
}

/// Aggregate readiness of one asset: file loaded AND recursive
/// dependencies loaded. A bare Handle is NOT readiness (plan 15.2).
#[derive(Debug, Clone, Default, bevy::ecs::resource::Resource)]
pub struct GameAssetLoadStateTracker {
  pub states: HashMap<GameAssetId, GameAssetLoadState>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum GameAssetLoadState {
  #[default]
  NotLoaded,
  Loading,
  Loaded,
  Failed,
}

impl GameAssetLoadStateTracker {
  /// Refresh states from the asset server; call once per frame.
  pub fn update(&mut self, catalog: &GameAssetCatalog, asset_server: &AssetServer) {
    for (id, entry) in &catalog.entries {
      // Readiness = root asset loaded AND ALL recursive dependencies
      // loaded (direct-only dependency state would green-light a scene
      // whose textures are two levels deep, and misses root failures).
      let state = if let Some(handle) = &entry.image {
        match asset_server.load_state(handle) {
          LoadState::Loaded if entry.render_image.is_some() => GameAssetLoadState::Loaded,
          LoadState::Failed(_) => GameAssetLoadState::Failed,
          _ => GameAssetLoadState::Loading,
        }
      } else if let Some(animation) = &entry.animation_2d {
        // 2D animation readiness = atlas page loaded AND frames.json
        // parsed AND the arbitrary-rect layout built from it.
        let image_ready = animation
          .atlas_image
          .as_ref()
          .map(|handle| matches!(asset_server.load_state(handle), LoadState::Loaded))
          .unwrap_or(false);
        let image_failed = animation
          .atlas_image
          .as_ref()
          .map(|handle| matches!(asset_server.load_state(handle), LoadState::Failed(_)))
          .unwrap_or(false);
        let frames_failed = animation
          .frames_handle
          .as_ref()
          .map(|handle| matches!(asset_server.load_state(handle), LoadState::Failed(_)))
          .unwrap_or(false);
        if image_failed || frames_failed {
          GameAssetLoadState::Failed
        } else if image_ready && animation.table.is_some() && animation.layout.is_some() {
          GameAssetLoadState::Loaded
        } else {
          GameAssetLoadState::Loading
        }
      } else if let Some(animation) = &entry.animation_3d {
        // Single clip loaded AND the skeleton map (loop/duration owner)
        // parsed.
        let clip_ready = animation
          .clip
          .as_ref()
          .map(|handle| matches!(asset_server.load_state(handle), LoadState::Loaded))
          .unwrap_or(false);
        let clip_failed = animation
          .clip
          .as_ref()
          .map(|handle| matches!(asset_server.load_state(handle), LoadState::Failed(_)))
          .unwrap_or(false);
        let map_failed = animation
          .skeleton_map
          .as_ref()
          .map(|handle| matches!(asset_server.load_state(handle), LoadState::Failed(_)))
          .unwrap_or(false);
        let map_ready = animation
          .skeleton_map
          .as_ref()
          .map(|handle| matches!(asset_server.load_state(handle), LoadState::Loaded))
          .unwrap_or(false);
        if clip_failed || map_failed {
          GameAssetLoadState::Failed
        } else if clip_ready && map_ready && !animation.clip_name.is_empty() {
          GameAssetLoadState::Loaded
        } else {
          GameAssetLoadState::Loading
        }
      } else if let Some(handle) = &entry.scene {
        let main_state = match (
          asset_server.load_state(handle),
          asset_server.recursive_dependency_load_state(handle.id()),
        ) {
          (LoadState::Loaded, bevy::asset::RecursiveDependencyLoadState::Loaded) => true,
          _ => false,
        };
        let main_failed = matches!(asset_server.load_state(handle), LoadState::Failed(_))
          || matches!(
            asset_server.recursive_dependency_load_state(handle.id()),
            bevy::asset::RecursiveDependencyLoadState::Failed(_)
          );
        // LOD level scenes are part of the asset: readiness requires
        // every level loaded too (a failed level fails the asset —
        // spawn-at-level would otherwise hand out a stale/empty scene).
        let lod_ready = entry
          .lod
          .as_ref()
          .map(|chain| {
            chain.levels.iter().all(|level| {
              matches!(asset_server.load_state(&level.scene), LoadState::Loaded)
                && matches!(
                  asset_server.recursive_dependency_load_state(level.scene.id()),
                  bevy::asset::RecursiveDependencyLoadState::Loaded
                )
            })
          })
          .unwrap_or(true);
        let lod_failed = entry.lod.as_ref().is_some_and(|chain| {
          chain.levels.iter().any(|level| {
            matches!(asset_server.load_state(&level.scene), LoadState::Failed(_))
              || matches!(
                asset_server.recursive_dependency_load_state(level.scene.id()),
                bevy::asset::RecursiveDependencyLoadState::Failed(_)
              )
          })
        });
        if lod_failed || main_failed {
          GameAssetLoadState::Failed
        } else if main_state && lod_ready {
          GameAssetLoadState::Loaded
        } else {
          GameAssetLoadState::Loading
        }
      } else {
        GameAssetLoadState::Failed
      };
      self.states.insert(id.clone(), state);
    }
    // Refused assets overlay LAST: an id that is both in entries (stale
    // handle from a previous pack version) and in problems must report
    // Failed, never the stale entry's Loaded.
    for id in catalog.problems.keys() {
      self.states.insert(id.clone(), GameAssetLoadState::Failed);
    }
  }

  pub fn state(&self, id: &GameAssetId) -> GameAssetLoadState {
    self.states.get(id).copied().unwrap_or(GameAssetLoadState::NotLoaded)
  }
}

fn pack_path(root: &str, path: &str) -> String {
  if root.is_empty() {
    path.to_owned()
  } else {
    format!("{root}/{path}")
  }
}

/// Per-asset animation sampling (plan 12.2): explicit sampler on the
/// atlas page itself; single-mip pages never sample mips that do not
/// exist (cross-frame bleed / undefined mip filtering is closed off).
fn animation_sampler(sampling: &str, single_mip: bool) -> bevy::image::ImageSampler {
  let mut descriptor = if sampling == "nearest" {
    bevy::image::ImageSamplerDescriptor::nearest()
  } else {
    bevy::image::ImageSamplerDescriptor::linear()
  };
  if single_mip {
    descriptor.mipmap_filter = bevy::image::ImageFilterMode::Nearest;
  }
  bevy::image::ImageSampler::Descriptor(descriptor)
}

/// Validate the skeleton map's playback metadata and tie it to the rig
/// dependency this pack declared for the asset (plan 11.2: the map is
/// the ONLY source of clip loop/duration).
fn parse_skeleton_map(
  value: &serde_json::Value,
  dependency: Option<&ManifestDependency>,
) -> Result<(String, bool), String> {
  if value.get("schema_version").and_then(serde_json::Value::as_str)
    != Some("game.anim3d.skeleton_map.v1")
  {
    return Err("skeleton_map schema_version 不是 game.anim3d.skeleton_map.v1。".into());
  }
  let clip = value.get("clip").ok_or("skeleton_map 缺少 clip。")?;
  if clip.get("animation_index").and_then(serde_json::Value::as_u64) != Some(0) {
    return Err("skeleton_map 必须 animation_index=0（单 clip）。".into());
  }
  let duration = clip.get("duration_seconds").and_then(serde_json::Value::as_f64).unwrap_or(0.0);
  if !(duration.is_finite() && duration > 0.0) {
    return Err("skeleton_map clip 时长必须为正。".into());
  }
  let name = clip
    .get("name")
    .and_then(serde_json::Value::as_str)
    .filter(|name| !name.is_empty())
    .ok_or("skeleton_map 缺少 clip 名。")?
    .to_string();
  let looping = clip.get("loop").and_then(serde_json::Value::as_bool).unwrap_or(false);
  let mappings = value
    .get("mappings")
    .and_then(serde_json::Value::as_array)
    .filter(|mappings| !mappings.is_empty())
    .ok_or("skeleton_map 缺少 mappings。")?;
  for mapping in mappings {
    let animation_path = mapping.get("animation_node_path").and_then(serde_json::Value::as_array);
    let rig_path = mapping.get("rig_node_path").and_then(serde_json::Value::as_array);
    if animation_path.is_none() || animation_path != rig_path {
      return Err("skeleton_map 映射路径不一致。".into());
    }
  }
  if let Some(dependency) = dependency {
    let map_rig = value
      .get("rig_main_sha256")
      .and_then(serde_json::Value::as_str)
      .unwrap_or_default()
      .to_lowercase();
    if map_rig != dependency.rig_main_sha256.to_lowercase() {
      return Err("skeleton_map 的 rig_main_sha256 与依赖声明不一致。".into());
    }
  }
  Ok((name, looping))
}

/// Parse animation sidecars and build derived state (frames table,
/// arbitrary-rect atlas layout, clip loop metadata). Runs every frame
/// until each entry settles; parse/consistency failures are surfaced as
/// catalog problems (fail loudly, never silently drop).
pub fn prepare_animation_assets(
  mut catalog: ResMut<GameAssetCatalog>,
  server: Res<AssetServer>,
  json: Res<Assets<JsonAsset>>,
  mut layouts: ResMut<Assets<TextureAtlasLayout>>,
  mut images: ResMut<Assets<Image>>,
) {
  let mut problems = Vec::new();
  for (id, entry) in &mut catalog.entries {
    if let Some(animation) = &mut entry.animation_2d {
      if animation.table.is_none() {
        if let Some(handle) = &animation.frames_handle {
          if matches!(server.load_state(handle), LoadState::Loaded) {
            match json.get(handle).map(|asset| FrameTable::parse(&asset.0)) {
              Some(Ok(table)) => {
                entry.width = table.canvas.width;
                entry.height = table.canvas.height;
                entry.anchor = (table.anchor.x as f32, table.anchor.y as f32);
                animation.table = Some(table);
              },
              Some(Err(message)) => problems.push((id.clone(), message)),
              None => {},
            }
          }
        }
      }
      if animation.table.is_some() && animation.layout.is_none() {
        let Some(image_handle) = animation.atlas_image.clone() else { continue };
        if !matches!(server.load_state(&image_handle), LoadState::Loaded) {
          continue;
        }
          match images.get(&image_handle) {
            Some(image) => {
              let table = animation.table.as_ref().unwrap();
              if image.width() != table.atlas.width || image.height() != table.atlas.height {
                problems.push((
                  id.clone(),
                  "图集页尺寸与帧表声明不同。".to_string(),
                ));
              } else {
                let single_mip = image.texture_descriptor.mip_level_count <= 1;
                if let Some(mut image) = images.get_mut(&image_handle) {
                  image.sampler = animation_sampler(&animation.sampling, single_mip);
                }
                animation.layout =
                  Some(layouts.add(crate::animation_2d::atlas_layout(table)));
              }
            },
            None => {},
          }
      }
    }
    if let Some(animation) = &mut entry.animation_3d {
      if animation.clip_name.is_empty() {
        if let Some(handle) = &animation.skeleton_map {
          if matches!(server.load_state(handle), LoadState::Loaded) {
            let dependency = entry.dependencies.first();
            match json.get(handle).map(|asset| parse_skeleton_map(&asset.0, dependency)) {
              Some(Ok((name, looping))) => {
                animation.clip_name = name;
                animation.looping = looping;
              },
              Some(Err(message)) => problems.push((id.clone(), message)),
              None => {},
            }
          }
        }
      }
    }
  }
  for (id, message) in problems {
    catalog.problems.insert(id, message);
  }
}
