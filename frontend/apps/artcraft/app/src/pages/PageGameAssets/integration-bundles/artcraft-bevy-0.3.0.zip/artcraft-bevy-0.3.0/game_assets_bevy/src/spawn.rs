//! Spawning + collision descriptors (plan section 15.2).
//!
//! Anchors convert the platform's top-left normalized convention into a
//! Bevy custom Anchor; props spawn the glTF scene asset (WorldAsset) —
//! readiness is gated by the load-state tracker, so a bare Handle can
//! never be mistaken for an instance.

use bevy::ecs::entity::Entity;
use bevy::ecs::system::Commands;
use bevy::math::{Vec2, Vec3};
use bevy::prelude::*;
use bevy::sprite::Anchor;

use crate::animation_2d::GameAssetAnimation2d;
use crate::catalog::{GameAssetCatalog, GameAssetLoadStateTracker};
use crate::manifest::ManifestCollision;
use crate::{GameAssetId, GameAssetLoadState};

/// Engine-neutral collision description for physics adapters (plan
/// 13.5): the base crate only exposes it; actual physics lives behind a
/// consumer-chosen adapter feature.
#[derive(Debug, Clone, Component)]
pub struct GameAssetCollisionDescriptor {
  pub kind: CollisionKind,
  /// Meters, asset-local coordinates.
  pub center: [f32; 3],
  pub half_extents: [f32; 3],
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CollisionKind {
  None,
  Box,
}

impl GameAssetCollisionDescriptor {
  pub fn from_manifest(collision: &ManifestCollision) -> Option<Self> {
    let kind = match collision.kind.as_str() {
      "none" => CollisionKind::None,
      "box" => CollisionKind::Box,
      _ => return None,
    };
    Some(Self {
      kind,
      center: match &collision.center {
        Some(values) if values.len() == 3 => [values[0], values[1], values[2]],
        _ => [0.0; 3],
      },
      half_extents: match &collision.half_extents {
        Some(values) if values.len() == 3 => [values[0], values[1], values[2]],
        _ => [0.5; 3],
      },
    })
  }
}

/// Convert the platform's top-left normalized anchor to a Bevy Anchor.
/// Platform convention: x right, y down, values in [0,1]; Bevy sprite
/// anchors are normalized around the center with y up, hence the flip.
pub fn platform_anchor_to_bevy(x: f32, y: f32) -> Anchor {
  Anchor(Vec2::new(x - 0.5, 0.5 - y))
}

/// Spawn a 2D asset as a Sprite, applying the manifest anchor. Returns
/// None while the asset is anything but fully Loaded.
pub fn spawn_game_sprite(
  commands: &mut Commands,
  images: &mut bevy::asset::Assets<bevy::image::Image>,
  catalog: &GameAssetCatalog,
  tracker: &GameAssetLoadStateTracker,
  id: &GameAssetId,
  position: Vec2,
) -> Option<Entity> {
  if tracker.state(id) != GameAssetLoadState::Loaded {
    return None;
  }
  let entry = catalog.get(id)?;
  let image = entry.render_image.clone()?;
  // Per-asset sampling (plan 15.2): configure the image's own sampler;
  // consumer-wide ImagePlugin defaults are never touched.
  if let Some(mut asset) = images.get_mut(&image) {
    asset.sampler = match entry.sampling.as_str() {
      "nearest" => bevy::image::ImageSampler::nearest(),
      _ => bevy::image::ImageSampler::linear(),
    };
  }
  Some(
    commands
      .spawn((
        Name::new(entry.display_name.clone()),
        crate::GameAssetInstance {
          id: id.clone(),
          version: entry.version_id.clone(),
          lod_level: None,
          automatic_lod: false,
        },
        Sprite {
          image,
          custom_size: Some(
            Vec2::new(entry.width as f32, entry.height as f32) / entry.pixels_per_world_unit,
          ),
          ..default()
        },
        // Anchor is its own component in Bevy 0.20.
        platform_anchor_to_bevy(entry.anchor.0, entry.anchor.1),
        Transform::from_translation(position.extend(0.0)),
      ))
      .id(),
  )
}

/// Spawn a 2D animation instance (plan 12.2): atlas page + arbitrary-rect
/// TextureAtlasLayout from the frozen frame table, anchor converted from
/// the platform convention, render size `(W,H)/pixels_per_world_unit`.
/// Returns None until the asset (image + frames + layout) is Loaded.
pub fn spawn_game_animation_2d(
  commands: &mut Commands,
  catalog: &GameAssetCatalog,
  tracker: &GameAssetLoadStateTracker,
  id: &GameAssetId,
  position: Vec2,
) -> Option<Entity> {
  if tracker.state(id) != GameAssetLoadState::Loaded {
    return None;
  }
  let entry = catalog.get(id)?;
  let animation = entry.animation_2d.as_ref()?;
  let table = animation.table.as_ref()?;
  let image = animation.atlas_image.clone()?;
  let layout = animation.layout.clone()?;
  let frame = GameAssetAnimation2d {
    id: id.clone(),
    version: entry.version_id.clone(),
    direction: 0,
    playing: true,
    elapsed: 0.0,
  };
  let index = frame.texture_index(table)?;
  Some(
    commands
      .spawn((
        Name::new(entry.display_name.clone()),
        crate::GameAssetInstance {
          id: id.clone(),
          version: entry.version_id.clone(),
          lod_level: None,
          automatic_lod: false,
        },
        frame,
        Sprite {
          image,
          texture_atlas: Some(TextureAtlas { layout, index }),
          custom_size: Some(
            Vec2::new(entry.width as f32, entry.height as f32) / entry.pixels_per_world_unit,
          ),
          ..default()
        },
        platform_anchor_to_bevy(entry.anchor.0, entry.anchor.1),
        Transform::from_translation(position.extend(0.0)),
      ))
      .id(),
  )
}

/// Spawn a 3D asset's glTF scene. Returns None while recursive
/// dependencies are not fully Loaded.
pub fn spawn_game_prop(
  commands: &mut Commands,
  catalog: &GameAssetCatalog,
  tracker: &GameAssetLoadStateTracker,
  id: &GameAssetId,
  position: Vec3,
) -> Option<Entity> {
  if tracker.state(id) != GameAssetLoadState::Loaded {
    return None;
  }
  let entry = catalog.get(id)?;
  let scene = entry.scene.clone()?;
  Some(
    commands
      .spawn((
        Name::new(entry.display_name.clone()),
        crate::GameAssetInstance {
          id: id.clone(),
          version: entry.version_id.clone(),
          lod_level: None,
          automatic_lod: true,
        },
        WorldAssetRoot(scene),
        Transform::from_translation(position),
      ))
      .id(),
  )
}

/// Spawn a specific LOD level of a 3D asset (plan 13.5: the chain —
/// not glTF — carries LOD behavior; `level` matches the manifest's
/// level numbers). `None` level spawns the main (finest) scene.
pub fn spawn_game_prop_at_lod_level(
  commands: &mut Commands,
  catalog: &GameAssetCatalog,
  tracker: &GameAssetLoadStateTracker,
  id: &GameAssetId,
  position: Vec3,
  level: Option<u32>,
) -> Option<Entity> {
  if tracker.state(id) != GameAssetLoadState::Loaded {
    return None;
  }
  let entry = catalog.get(id)?;
  let scene = match level {
    Some(level) => entry.lod.as_ref()?.scene_for_level(level)?.clone(),
    None => entry.scene.clone()?,
  };
  Some(
    commands
      .spawn((
        Name::new(entry.display_name.clone()),
        crate::GameAssetInstance {
          id: id.clone(),
          version: entry.version_id.clone(),
          lod_level: level,
          automatic_lod: false,
        },
        WorldAssetRoot(scene),
        Transform::from_translation(position),
      ))
      .id(),
  )
}
