extends Control
## The exported preview application has its own entry; release templates do not
## permit overriding the main scene with a command-line resource path.

const InstalledPacks := preload("res://addons/game_assets/installed_packs.gd")
var _packs: Array[Dictionary] = []
var _choice: OptionButton
var _status: Label

func _ready() -> void:
	_packs = InstalledPacks.list_packs()
	var layout := VBoxContainer.new(); add_child(layout)
	layout.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	layout.offset_left = 30; layout.offset_top = 150; layout.offset_right = -30; layout.offset_bottom = -30
	var heading := Label.new(); heading.text = "选择已安装的资源并查看实际效果"; layout.add_child(heading)
	_choice = OptionButton.new(); _choice.fit_to_longest_item = false; _choice.accessibility_name = "选择要预览的已安装资源"; layout.add_child(_choice)
	var previous := String(ProjectSettings.get_setting("game_assets/session_preview_namespace", ""))
	for index in _packs.size():
		_choice.add_item(String(_packs[index].label))
		if _packs[index].namespace == previous: _choice.select(index)
	var open := Button.new(); open.text = "打开这份安装的资产预览"; open.pressed.connect(_open_selected); layout.add_child(open)
	_status = Label.new(); _status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; layout.add_child(_status)
	_choice.disabled = _packs.is_empty(); open.disabled = _packs.is_empty()
	_status.text = "这个预览程序尚未包含资产。请先在 Godot 编辑器中导入资源，再重新导出。" if _packs.is_empty() else "总览包含本次和此前保留的资产。运行报告只记录最新交付包；适合自己游戏的判断仍需单独确认。"
	var args := OS.get_cmdline_user_args(); var index := args.find("--preview-installation")
	if index >= 0 and not bool(ProjectSettings.get_setting("game_assets/startup_preview_consumed", false)):
		ProjectSettings.set_setting("game_assets/startup_preview_consumed", true)
		if index + 1 < args.size():
			for selected in _packs.size():
				if _packs[selected].namespace == args[index + 1]: _choice.select(selected); call_deferred("_open_selected"); return
		push_error("未找到指定的已安装资源，请从预览程序的列表选择有效安装。")
		get_tree().quit(2)

func _open_selected() -> void:
	if _choice.selected < 0 or _choice.selected >= _packs.size(): return
	var path := String(_packs[_choice.selected].root).path_join("preview.tscn")
	if not ResourceLoader.exists(path, "PackedScene"):
		_status.text = "预览场景缺失，请在编辑器中重新导入并再次导出。"
		if OS.get_cmdline_user_args().has("--exit-after-report"): get_tree().quit(1)
		return
	var error := get_tree().change_scene_to_file(path)
	if error != OK:
		_status.text = "无法打开这份安装的预览，请检查导入结果。"
		if OS.get_cmdline_user_args().has("--exit-after-report"): get_tree().quit(1)
