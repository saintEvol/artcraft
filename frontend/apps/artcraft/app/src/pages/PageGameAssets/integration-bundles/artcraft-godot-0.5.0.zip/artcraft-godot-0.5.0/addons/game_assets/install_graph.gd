@tool
extends RefCounted
## §12.1 final install graph. Before any managed file is written, the
## plugin builds the FINAL installation (everything retained from the
## journal plus everything this pack delivers) and re-checks the rig
## dependencies that bind anim_3d clips to character rigs: the target must
## exist, be a rigged character, match the dependency version, and its
## main-file hash must equal rig_main_sha256. Retained rigs are re-verified
## against the actual bytes on disk; incoming clips additionally have their
## skeleton_map.json matched to the dependency. Any failure rejects the
## whole update before staging — files, manifest, journal and derived
## resources stay untouched (the directory transaction restores them).

const Journal := preload("res://addons/game_assets/journal.gd")
const Binding := preload("res://addons/game_assets/animation_binding.gd")

var problems: PackedStringArray = PackedStringArray()

## `journal_entries`: current installation (may be empty for a fresh
## namespace); `manifest_assets`: assets of the incoming pack (1.x or 2.0);
## `managed_root` / `pack_root`: res:// or absolute roots for byte checks.
## Returns {"ok": bool, "entries": {asset_id: normalized entry}}.
func build(journal_entries: Dictionary, manifest_assets: Array, managed_root: String, pack_root: String) -> Dictionary:
	problems = PackedStringArray()
	var recorder := Journal.new()
	var incoming_ids := {}
	for asset in manifest_assets:
		if asset is Dictionary:
			recorder.record(asset)
			incoming_ids[String(asset.get("asset_id", ""))] = true
	var final_entries := {}
	for asset_id in journal_entries:
		final_entries[String(asset_id)] = journal_entries[asset_id]
	for asset_id in incoming_ids:
		final_entries[asset_id] = recorder.entries[asset_id]

	for asset_id in final_entries:
		var entry: Dictionary = final_entries[asset_id]
		var dependencies := dependencies_of(entry)
		if String(kind_of(entry)) != "anim_3d":
			if not dependencies.is_empty():
				problems.append("资产 %s 不应携带依赖。" % String(entry.get("stable_key", asset_id)))
			continue
		if dependencies.size() != 1:
			problems.append("动画 %s 必须恰好依赖一个 rig。" % String(entry.get("stable_key", asset_id)))
			continue
		_check_rig_dependency(String(asset_id), entry, dependencies[0] as Dictionary, final_entries, incoming_ids, managed_root, pack_root)
	return {"ok": problems.is_empty(), "entries": final_entries}

func _check_rig_dependency(asset_id: String, entry: Dictionary, dependency: Dictionary, final_entries: Dictionary, incoming_ids: Dictionary, managed_root: String, pack_root: String) -> void:
	var stable_key := String(entry.get("stable_key", asset_id))
	var target_id := String(dependency.get("asset_id", ""))
	var target: Dictionary = final_entries.get(target_id, {}) as Dictionary
	if target.is_empty():
		problems.append("动画 %s 依赖的角色 %s 不在本次安装中；请连同角色一起导入。" % [stable_key, target_id])
		return
	if String(kind_of(target)) != "character_3d" or String(stage_of(target)) != "rigged":
		problems.append("动画 %s 依赖的 %s 不是已安装的绑定角色。" % [stable_key, target_id])
		return
	if String(target.get("version_id", "")) != String(dependency.get("version_id", "")) or String(main_sha_of(target)) != String(dependency.get("rig_main_sha256", "")):
		problems.append("动画 %s 依赖 %s 版本 %s，与最终安装中的角色（版本 %s）不一致；请同步更新角色和动画。" % [stable_key, target_id, String(dependency.get("version_id", "")), String(target.get("version_id", ""))])
		return
	if not incoming_ids.has(target_id):
		# Retained rig: its bytes are what the graph is built on, so verify
		# the main file on disk instead of trusting the journal record.
		var main_path := _main_path(target)
		var disk := managed_root.path_join(main_path)
		if main_path.is_empty() or not FileAccess.file_exists(disk) or FileAccess.get_sha256(disk) != String(main_sha_of(target)).to_lower():
			problems.append("已安装角色 %s 的主文件与记录不一致，动画 %s 的绑定无法确认。" % [target_id, stable_key])
	if incoming_ids.has(asset_id):
		_check_skeleton_map(stable_key, dependency, entry, pack_root)

func _check_skeleton_map(stable_key: String, dependency: Dictionary, entry: Dictionary, pack_root: String) -> void:
	var map_path := ""
	for file in entry.get("files", []) as Array:
		if file is Dictionary and String(file.get("role", "")) == "skeleton_map":
			map_path = String(file.get("path", ""))
			break
	if map_path.is_empty():
		problems.append("动画 %s 缺少 skeleton_map 文件。" % stable_key)
		return
	var map_problems := PackedStringArray()
	var skeleton_map := Binding.parse_skeleton_map(FileAccess.get_file_as_string(pack_root.path_join(map_path)), map_problems)
	if skeleton_map.is_empty():
		problems.append("动画 %s 的 skeleton_map 无法读取：%s" % [stable_key, "; ".join(map_problems)])
		return
	if String(skeleton_map.get("rig_main_sha256", "")) != String(dependency.get("rig_main_sha256", "")) or String(skeleton_map.get("rig_version_token", "")) != String(dependency.get("version_id", "")):
		problems.append("动画 %s 的 skeleton_map 指向另一个 rig 版本。" % stable_key)

func _main_path(entry: Dictionary) -> String:
	for file in entry.get("files", []) as Array:
		if file is Dictionary and String(file.get("role", "")) == "main":
			return String(file.get("path", ""))
	return ""

## Retained entries may come from a legacy v1 journal without the v2
## fields; normalize on read so the graph logic has one shape.

static func kind_of(entry: Dictionary) -> String:
	return String(entry.get("kind", ""))

static func stage_of(entry: Dictionary) -> String:
	var stage := String(entry.get("stage", ""))
	if not stage.is_empty():
		return stage
	match kind_of(entry):
		"character_3d": return "rigged"
		"anim_2d", "anim_3d": return "animation"
	return "asset"

static func dependencies_of(entry: Dictionary) -> Array:
	return entry.get("dependencies", []) as Array

static func main_sha_of(entry: Dictionary) -> String:
	var recorded := String(entry.get("main_sha256", ""))
	if not recorded.is_empty():
		return recorded
	for file in entry.get("files", []) as Array:
		if file is Dictionary and String(file.get("role", "")) == "main":
			return String(file.get("sha256", ""))
	return ""
