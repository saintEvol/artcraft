extends RefCounted

const COMPONENT_VERSION := "0.2.0"

static func create(manifest: Dictionary, operation: String, status: String, assets: Array, problems: Array = []) -> Dictionary:
	var version := Engine.get_version_info()
	return {
		"schema_version": "game-assets-engine-report.v1", "pack_id": manifest.get("pack_id", ""),
		"engine": "godot", "engine_version": "%s.%s.%s" % [version.major, version.minor, version.patch],
		"importer_version": "game_assets_addon_1@" + COMPONENT_VERSION,
		"operation": operation, "status": status, "assets": assets, "problems": problems,
		"created_at": Time.get_datetime_string_from_system(true), "rendered": false,
	}

static func save(report: Dictionary, path: String) -> bool:
	if DirAccess.make_dir_recursive_absolute(path.get_base_dir()) != OK:
		return false
	var file := FileAccess.open(path, FileAccess.WRITE)
	if file == null:
		return false
	file.store_string(JSON.stringify(report, "\t"))
	file.flush()
	return true
