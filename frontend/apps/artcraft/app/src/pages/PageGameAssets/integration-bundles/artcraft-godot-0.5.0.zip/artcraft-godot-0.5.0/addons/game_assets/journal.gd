@tool
class_name GameAssetImportJournal
extends RefCounted
## Append-only record of what the plugin imported into the managed
## directory (plan 15.1: stable identity, update without breaking user
## scenes). Stored at res://game_assets/<namespace>/import_journal.json.
##
## Version 2 (manifest 2.0, §12.1): every entry also carries the final
## version, its rig dependencies and the VERIFIED main-file hash, and the
## whole installation is sealed with install_state_hash — a content digest
## over the final versions, dependencies and managed/derived file digests.
## It is recomputed on every save, so a copied namespace or a hand-edited
## journal is detected instead of silently drifting. Version 1 journals
## are still read safely and upgrade to v2 on the next save; a missing,
## corrupt or unknown-format journal stops updates of an existing
## installation.

const FORMAT_VERSION := 2
const LEGACY_VERSION := 1

## entry: {stable_key, display_name, kind, stage, version_id, main_sha256,
##         dependencies: [{role, asset_id, version_id, rig_main_sha256}],
##         files: [{role, path, sha256}]}

var entries: Dictionary = {}
var generated_files: Array = []
var format_version := LEGACY_VERSION
var problem := ""

static func journal_path(for_namespace: String) -> String:
	return "res://game_assets/%s/import_journal.json" % for_namespace

func load_from(for_namespace: String) -> bool:
	problem = ""
	var path := journal_path(for_namespace)
	if not FileAccess.file_exists(path):
		problem = "journal file is absent"
		return false
	var file := FileAccess.open(path, FileAccess.READ)
	if file == null or file.get_length() > 4 * 1024 * 1024:
		problem = "journal cannot be opened or exceeds 4 MiB"
		return false
	var parsed: Variant = JSON.parse_string(file.get_as_text())
	if not (parsed is Dictionary) or not (parsed.get("entries", {}) is Dictionary):
		problem = "journal is not a recognizable object"
		return false
	var version := int(parsed.get("version", 0))
	if version != LEGACY_VERSION and version != FORMAT_VERSION:
		problem = "journal version %d is unknown to this addon" % version
		return false
	format_version = version
	var candidate: Dictionary = parsed.get("entries", {})
	var safe_check := preload("res://addons/game_assets/manifest.gd")
	# Entries are keyed by asset_id; equal stable keys across kinds are part
	# of the 2.0 contract (each kind delivers under its own directory), so
	# stable_key uniqueness is NOT required here — scene path safety is
	# enforced by the manifest validator and the importer.
	for asset_id in candidate:
		var entry: Variant = candidate[asset_id]
		if not (asset_id is String) or asset_id.is_empty() or not (entry is Dictionary) or not (entry.get("files") is Array) or not (entry.get("stable_key") is String) or not safe_check.safe_name(entry.stable_key) or not (entry.get("version_id") is String) or entry.version_id.is_empty():
			problem = "journal entry for %s is malformed" % String(asset_id)
			return false
		for item in entry.files:
			if not (item is Dictionary) or not safe_check.safe_path(String(item.get("path", ""))):
				problem = "journal file record is malformed in %s" % String(asset_id)
				return false
		if version == FORMAT_VERSION:
			# v2-only fields; also enforced for entries a v2 save must carry.
			if not (entry.get("dependencies", []) is Array) or not (String(entry.get("main_sha256", "")) is String):
				problem = "journal v2 entry for %s is malformed" % String(asset_id)
				return false
	var extra: Variant = parsed.get("generated_files", [])
	if not (extra is Array):
		problem = "journal generated_files is malformed"
		return false
	for item in extra:
		if not (item is Dictionary) or not safe_check.safe_path(String(item.get("path", ""))) or not (item.get("sha256") is String):
			problem = "journal generated file record is malformed"
			return false
	entries = candidate
	generated_files = extra
	if version == FORMAT_VERSION:
		var recorded := String(parsed.get("install_state_hash", ""))
		if recorded != install_state_hash():
			problem = "journal install_state_hash does not match its content"
			return false
	return true

## The serialized v2 document; `save` writes it to the live namespace and
## the importer writes the same document into the staged tree so a commit
## swaps both atomically.
func document() -> Dictionary:
	format_version = FORMAT_VERSION
	return {
		"version": FORMAT_VERSION,
		"entries": entries,
		"generated_files": generated_files,
		"install_state_hash": install_state_hash(),
	}

func save(for_namespace: String) -> bool:
	return preload("res://addons/game_assets/engine_report.gd").save(document(), journal_path(for_namespace))

## Content digest over the final versions, dependencies and managed file
## digests (§12.1). Deterministic: sorted keys, sorted file lists.
func install_state_hash() -> String:
	var context := HashingContext.new()
	if context.start(HashingContext.HASH_SHA256) != OK:
		return ""
	var signature := _state_signature()
	if context.update(signature.to_utf8_buffer()) != OK:
		return ""
	return context.finish().hex_encode()

func _state_signature() -> String:
	var lines: PackedStringArray = PackedStringArray()
	for asset_id in entries.keys():
		lines.append(_entry_signature(String(asset_id), entries[asset_id]))
	lines.sort()
	var generated: PackedStringArray = PackedStringArray()
	for file in generated_files:
		generated.append("%s=%s" % [String(file.get("path", "")), String(file.get("sha256", ""))])
	generated.sort()
	return "\n".join(lines) + "\n#" + "\n".join(generated)

func _entry_signature(asset_id: String, entry: Dictionary) -> String:
	var dependencies: PackedStringArray = PackedStringArray()
	for dependency in entry.get("dependencies", []) as Array:
		dependencies.append("%s:%s:%s:%s" % [String(dependency.get("role", "")), String(dependency.get("asset_id", "")), String(dependency.get("version_id", "")), String(dependency.get("rig_main_sha256", ""))])
	dependencies.sort()
	var files: PackedStringArray = PackedStringArray()
	for file in entry.get("files", []) as Array:
		files.append("%s:%s:%s" % [String(file.get("role", "")), String(file.get("path", "")), String(file.get("sha256", ""))])
	files.sort()
	return "%s|%s|%s|%s|%s|%s|%s|%s" % [asset_id, String(entry.get("stable_key", "")), String(entry.get("version_id", "")), String(entry.get("kind", "")), String(entry.get("stage", "")), String(entry.get("main_sha256", "")), ",".join(dependencies), ",".join(files)]

func record(asset: Dictionary) -> void:
	var files: Array = []
	for f in asset.get("files", []) as Array:
		if f is Dictionary:
			files.append({
				"role": f.get("role", ""),
				"path": f.get("path", ""),
				"sha256": f.get("sha256", ""),
			})
	entries[String(asset.get("asset_id", ""))] = {
		"stable_key": asset.get("stable_key", ""),
		"display_name": asset.get("display_name", asset.get("stable_key", "")),
		"kind": asset.get("kind", ""),
		"stage": asset.get("stage", _stage_for_kind(String(asset.get("kind", "")))),
		"version_id": asset.get("version_id", ""),
		"main_sha256": _main_sha256(asset.get("files", []) as Array),
		"dependencies": _normalized_dependencies(asset),
		"files": files,
	}

func _normalized_dependencies(asset: Dictionary) -> Array:
	var dependencies: Array = []
	for dependency in asset.get("dependencies", []) as Array:
		if dependency is Dictionary:
			dependencies.append({
				"role": dependency.get("role", ""),
				"asset_id": dependency.get("asset_id", ""),
				"version_id": dependency.get("version_id", ""),
				"rig_main_sha256": dependency.get("rig_main_sha256", ""),
			})
	return dependencies

func _main_sha256(files: Array) -> String:
	for file in files:
		if file is Dictionary and String(file.get("role", "")) == "main" and int(file.get("ordinal", 0)) == 0:
			return String(file.get("sha256", ""))
	for file in files:
		if file is Dictionary and String(file.get("role", "")) == "main":
			return String(file.get("sha256", ""))
	return ""

func _stage_for_kind(kind: String) -> String:
	match kind:
		"character_3d": return "rigged"
		"anim_2d", "anim_3d": return "animation"
	return "asset"

func known_paths() -> PackedStringArray:
	var paths := PackedStringArray()
	for entry in entries.values():
		if entry is Dictionary:
			for f in entry.get("files", []) as Array:
				if f is Dictionary:
					paths.append(String(f.get("path", "")))
	for file in generated_files:
		paths.append(String(file.path))
	return paths

## Update plan (plan 14.4, GA-018 两引擎更新与冲突处理): compare an
## incoming pack against the journal + the managed files on disk.
## Returns {new: [], updated: [], unchanged: [], conflicts: [], missing: []}
## keyed by stable_key:
##   new        - asset not in the journal yet;
##   updated    - journal knows it AND the file set/hash changed;
##   unchanged  - journal knows it and nothing changed;
##   conflicts  - the managed file on disk no longer matches the
##                journal's recorded hash (manual modification): the
##                user's content wins and must be resolved explicitly,
##                never overwritten silently;
##   missing    - in the journal but not in the incoming pack (NOT
##                deleted: plan 14.4, deletion is explicit and
##                reviewable).
## `managed_root` is the absolute or res:// root the files live under.
func plan_update(manifest_assets: Array, managed_root: String) -> Dictionary:
	var plan := {"new": [], "updated": [], "unchanged": [], "conflicts": [], "missing": []}
	var by_asset_id := {}
	for asset_id in entries:
		if entries[asset_id] is Dictionary:
			by_asset_id[String(asset_id)] = entries[asset_id]

	var incoming := {}
	for asset in manifest_assets:
		if asset is Dictionary:
			incoming[String(asset.get("asset_id", ""))] = asset

	for asset_id in incoming:
		var asset: Dictionary = incoming[asset_id]
		var recorded: Dictionary = by_asset_id.get(asset_id, {}) as Dictionary
		if recorded.is_empty():
			plan["new"].append(asset_id)
			continue
		var incoming_files: Array = asset.get("files", []) as Array
		var recorded_files: Array = recorded.get("files", []) as Array
		var incoming_hashes := {}
		for f in incoming_files:
			if f is Dictionary:
				incoming_hashes[String(f.get("path", ""))] = String(f.get("sha256", ""))
		var recorded_hashes := {}
		for f in recorded_files:
			if f is Dictionary:
				recorded_hashes[String(f.get("path", ""))] = String(f.get("sha256", ""))
		var recorded_payload := recorded_hashes.duplicate()
		if incoming_hashes == recorded_payload and asset.get("version_id") == recorded.get("version_id"):
			plan["unchanged"].append(asset_id)
		else:
			plan["updated"].append(asset_id)
		# Manual modification check: the disk file drifted from what the
		# journal recorded at import time.
		for path in recorded_hashes:
			var disk := managed_root.path_join(path)
			if not FileAccess.file_exists(disk):
				# A journal-recorded file missing on disk leaves the
				# managed set broken; surface it as a conflict instead of
				# planning "unchanged" and silently keeping it broken.
				if not (asset_id in plan["conflicts"]):
					plan["conflicts"].append(asset_id)
				continue
			if FileAccess.get_sha256(disk) != String(recorded_hashes[path]).to_lower():
				if not (asset_id in plan["conflicts"]):
					plan["conflicts"].append(asset_id)

	for asset_id in by_asset_id:
		if not incoming.has(asset_id):
			plan["missing"].append(asset_id)
	for file in generated_files:
		if FileAccess.get_sha256(managed_root.path_join(String(file.path))) != String(file.sha256):
			plan.conflicts.append("工程索引或预览（本地修改）")
	return plan
