//! Supported real-pack viewer. No fixtures or hard-coded asset identities.
use std::{
  fs,
  io::Read,
  path::PathBuf,
  time::{Duration, Instant, SystemTime, UNIX_EPOCH},
};
use bevy::prelude::*;
use bevy::log::LogPlugin;
use bevy::render::view::screenshot::{Screenshot, ScreenshotCaptured};
use bevy::text::FontSize;
use sha2::{Digest, Sha256};
use game_assets_bevy::{
  GameAssetCatalog, GameAssetId, GameAssetLoadState, GameAssetLoadStateTracker,
  GameAssetPackManifest, GameAssetPackPlugin, spawn_game_prop, verify_pack_files,
};
use game_assets_bevy::install::report;
use game_assets_bevy::manifest::MAX_MANIFEST_BYTES;

#[derive(Resource)]
struct Pack {
  manifest: GameAssetPackManifest,
  raw: serde_json::Value,
  asset_root: String,
  pack_root: String,
  started: Instant,
  spawned: bool,
  frames: u32,
  saved: bool,
  exit_after: bool,
}
#[derive(Resource, Default)]
struct RenderCapture {
  requested: bool,
  maybe_frame: Option<serde_json::Value>,
  maybe_problem: Option<String>,
}
#[derive(Resource)]
struct View {
  yaw: f32,
  pitch: f32,
  distance: f32,
  center: Vec3,
}
#[derive(Resource)]
struct PreviewFont(Handle<Font>);
#[derive(Component)]
struct PreviewCamera;
#[derive(Component)]
struct PreviewStatus;
#[derive(Component)]
struct PreviewProp;
#[derive(Component)]
struct PropLabelAnchor(Vec3);

fn main() -> AppExit {
  let mut app = App::new();
  app.add_plugins(LogPlugin::default());
  let pack = match read_pack() {
    Ok(pack) => pack,
    Err(problem) => {
      error!("预览未开始：{problem}");
      return AppExit::error();
    },
  };
  let asset_root = pack.asset_root.clone();
  app
    .insert_resource(pack)
    .add_plugins(
      DefaultPlugins
        .build()
        .disable::<LogPlugin>()
        .set(WindowPlugin {
          primary_window: Some(Window {
            title: "Artcraft · Bevy 真实资产预览".into(),
            resolution: (1280, 800).into(),
            ..default()
          }),
          ..default()
        })
        .set(AssetPlugin { file_path: asset_root, ..default() }),
    )
    .add_plugins(GameAssetPackPlugin)
    .init_resource::<RenderCapture>()
    .add_systems(Startup, setup)
    .add_systems(
      Update,
      (load_and_spawn, update_view, update_prop_labels, save_report)
        .chain()
        .run_if(resource_exists::<Pack>),
    )
    .run()
}
fn read_pack() -> Result<Pack, String> {
  let input = PathBuf::from(
    std::env::args()
      .nth(1)
      .ok_or("用法：preview_pack <已安装的 assets/game_assets/项目目录> [--exit-after-report]")?,
  );
  let path =
    input.canonicalize().map_err(|e| format!("无法打开资源包目录 {}：{e}", input.display()))?;
  if !path.is_dir() {
    return Err("请选择包含 manifest.json 的资源包目录，而非某一个文件。".into());
  }
  let mut text = String::new();
  fs::File::open(path.join("manifest.json"))
    .and_then(|file| file.take((MAX_MANIFEST_BYTES + 1) as u64).read_to_string(&mut text))
    .map_err(|e| format!("无法读取包清单 {}：{e}", path.join("manifest.json").display()))?;
  let manifest = GameAssetPackManifest::parse_and_validate(&text)
    .map_err(|p| p.iter().map(|p| p.message.clone()).collect::<Vec<_>>().join(";"))?;
  let failures = verify_pack_files(&manifest, &path.to_string_lossy());
  if !failures.is_empty() {
    return Err(failures.iter().map(|p| p.message.clone()).collect::<Vec<_>>().join(";"));
  }
  let raw = serde_json::from_str(&text).map_err(|e| e.to_string())?;
  Ok(Pack {
    manifest,
    raw,
    asset_root: path
      .parent()
      .ok_or("不能把文件系统根目录作为资源包目录。")?
      .to_string_lossy()
      .into_owned(),
    pack_root: path.file_name().ok_or("资源包目录缺少名称。")?.to_string_lossy().into_owned(),
    started: Instant::now(),
    spawned: false,
    frames: 0,
    saved: false,
    exit_after: std::env::args().any(|a| a == "--exit-after-report"),
  })
}
fn setup(
  mut commands: Commands,
  pack: Res<Pack>,
  server: Res<AssetServer>,
  mut catalog: ResMut<GameAssetCatalog>,
  mut fonts: ResMut<Assets<Font>>,
) {
  catalog.load_pack(&server, &pack.manifest, &pack.pack_root);
  let font = fonts.add(Font::from_bytes(include_bytes!("../assets/fonts/NotoSansSC.ttf").to_vec()));
  commands.spawn((
    Camera3d::default(),
    Transform::from_xyz(3., 2.5, 6.).looking_at(Vec3::Y, Vec3::Y),
    PreviewCamera,
  ));
  commands.spawn((
    DirectionalLight { shadow_maps_enabled: true, ..default() },
    Transform::from_xyz(2., 5., 3.).looking_at(Vec3::ZERO, Vec3::Y),
  ));
  commands.insert_resource(PreviewFont(font.clone()));
  commands.spawn((
    Text::new("工作台资源 · Bevy 实际运行\n图标 64px；模型保持米制\n方向键旋转，+/- 缩放"),
    TextFont { font: font.clone().into(), font_size: FontSize::Px(18.), ..default() },
    Node {
      position_type: PositionType::Absolute,
      top: Val::Px(14.),
      left: Val::Px(20.),
      ..default()
    },
  ));
  commands.spawn((
    Text::new("等待资源、依赖与场景实例完成…"),
    TextFont { font: font.into(), font_size: FontSize::Px(16.), ..default() },
    Node {
      position_type: PositionType::Absolute,
      bottom: Val::Px(16.),
      left: Val::Px(20.),
      ..default()
    },
    PreviewStatus,
  ));
  commands.insert_resource(View {
    yaw: 0.4,
    pitch: 0.3,
    distance: 6.,
    center: Vec3::new(1., 0.8, 0.),
  });
}
fn load_and_spawn(
  mut commands: Commands,
  pack: Option<ResMut<Pack>>,
  catalog: Res<GameAssetCatalog>,
  tracker: Res<GameAssetLoadStateTracker>,
  mut view: ResMut<View>,
  mut meshes: ResMut<Assets<Mesh>>,
  mut materials: ResMut<Assets<StandardMaterial>>,
  font: Res<PreviewFont>,
) {
  let Some(mut pack) = pack else {
    return;
  };
  if pack.spawned {
    return;
  }
  if catalog.entries.len() != pack.manifest.assets.len()
    || catalog.entries.keys().any(|id| tracker.state(id) != GameAssetLoadState::Loaded)
  {
    return;
  }
  let mut lane = 0.;
  let mut tallest = 1.7f32;
  let mut icon = 0;
  for asset in &pack.manifest.assets {
    let id = GameAssetId::new(&catalog.namespace, &asset.stable_key);
    let entry = &catalog.entries[&id];
    if let Some(image) = &entry.render_image {
      commands.spawn((
        ImageNode::new(image.clone()),
        Node {
          position_type: PositionType::Absolute,
          left: Val::Px(20. + (icon % 3) as f32 * 90.),
          top: Val::Px(120. + (icon / 3) as f32 * 90.),
          width: Val::Px(64.),
          height: Val::Px(64.),
          ..default()
        },
      ));
      commands.spawn((
        Text::new(entry.display_name.clone()),
        TextFont { font: font.0.clone().into(), font_size: FontSize::Px(13.), ..default() },
        Node {
          position_type: PositionType::Absolute,
          left: Val::Px(20. + (icon % 3) as f32 * 90.),
          top: Val::Px(185. + (icon / 3) as f32 * 90.),
          ..default()
        },
      ));
      icon += 1;
    } else {
      let dimensions = pack.raw["assets"]
        .as_array()
        .and_then(|assets| {
          assets.iter().find(|row| row["asset_id"].as_str() == Some(asset.asset_id.as_str()))
        })
        .and_then(|row| row.pointer("/mesh/measured_dimensions_m"));
      let width = dimensions
        .and_then(|value| value["x"].as_f64())
        .filter(|value| value.is_finite() && *value > 0.)
        .unwrap_or(1.) as f32;
      let height = dimensions
        .and_then(|value| value["y"].as_f64())
        .filter(|value| value.is_finite() && *value > 0.)
        .map(|value| value as f32);
      let x = lane + width / 2.;
      if let Some(entity) =
        spawn_game_prop(&mut commands, &catalog, &tracker, &id, Vec3::new(x, 0., 0.))
      {
        commands.entity(entity).insert(PreviewProp);
        let caption = height
          .map(|height| format!("{} · 清单高度 {height:.2}m", entry.display_name))
          .unwrap_or_else(|| entry.display_name.clone());
        spawn_prop_label(
          &mut commands,
          &font.0,
          caption,
          Vec3::new(x, height.unwrap_or(1.) + 0.15, 0.),
        );
        tallest = tallest.max(height.unwrap_or(1.));
        lane += width + 0.8;
      }
    }
  }
  if lane > 0. {
    commands.spawn((
      Mesh3d(meshes.add(Plane3d::default().mesh().size((lane + 8.).max(12.), 12.))),
      MeshMaterial3d(materials.add(StandardMaterial {
        base_color: Color::srgb(0.18, 0.2, 0.23),
        perceptual_roughness: 1.,
        ..default()
      })),
      Transform::from_xyz(lane / 2., -0.005, 0.),
    ));
    commands.spawn((
      Mesh3d(meshes.add(Cuboid::new(0.4, 1.7, 0.25))),
      MeshMaterial3d(materials.add(Color::srgb(0.45, 0.55, 0.7))),
      Transform::from_xyz(lane, 0.85, 0.),
    ));
    spawn_prop_label(
      &mut commands,
      &font.0,
      "1.70m 尺度参照（非交付资产）".into(),
      Vec3::new(lane, 1.85, 0.),
    );
    view.center = Vec3::new(lane / 2., tallest / 2., 0.);
    view.distance = (lane * 1.5).max(tallest * 1.8).max(5.);
  }
  pack.spawned = true;
}
fn update_view(
  keys: Res<ButtonInput<KeyCode>>,
  time: Res<Time>,
  mut view: ResMut<View>,
  mut camera: Query<&mut Transform, With<PreviewCamera>>,
) {
  let step = time.delta_secs().min(0.1) * 1.2;
  if keys.pressed(KeyCode::ArrowLeft) {
    view.yaw -= step;
  }
  if keys.pressed(KeyCode::ArrowRight) {
    view.yaw += step;
  }
  if keys.pressed(KeyCode::ArrowUp) {
    view.pitch = (view.pitch + step).min(1.2);
  }
  if keys.pressed(KeyCode::ArrowDown) {
    view.pitch = (view.pitch - step).max(-1.2);
  }
  if keys.pressed(KeyCode::Equal) {
    view.distance = (view.distance * (-step).exp()).max(0.5);
  }
  if keys.pressed(KeyCode::Minus) {
    view.distance *= step.exp();
  }
  for mut transform in &mut camera {
    transform.translation = view.center
      + Vec3::new(
        view.yaw.sin() * view.pitch.cos(),
        view.pitch.sin(),
        view.yaw.cos() * view.pitch.cos(),
      ) * view.distance;
    transform.look_at(view.center, Vec3::Y);
  }
}
fn spawn_prop_label(commands: &mut Commands, font: &Handle<Font>, caption: String, anchor: Vec3) {
  commands.spawn((
    Text::new(caption),
    TextFont { font: font.clone().into(), font_size: FontSize::Px(14.), ..default() },
    Node {
      position_type: PositionType::Absolute,
      padding: UiRect::all(Val::Px(4.)),
      max_width: Val::Px(220.),
      ..default()
    },
    BackgroundColor(Color::srgba(0., 0., 0., 0.7)),
    Visibility::Visible,
    PropLabelAnchor(anchor),
  ));
}
fn update_prop_labels(
  camera: Query<(&Camera, &Transform), With<PreviewCamera>>,
  mut labels: Query<(&PropLabelAnchor, &mut Node, &mut Visibility)>,
) {
  let Ok((camera, transform)) = camera.single() else {
    return;
  };
  let world = GlobalTransform::from(*transform);
  let viewport = camera.logical_viewport_size().unwrap_or(Vec2::new(1280., 800.));
  for (anchor, mut node, mut visibility) in &mut labels {
    if let Ok(point) = camera.world_to_viewport(&world, anchor.0) {
      node.left = Val::Px((point.x - 70.).clamp(8., (viewport.x - 228.).max(8.)));
      node.top = Val::Px((point.y - 28.).clamp(8., (viewport.y - 50.).max(8.)));
      *visibility = Visibility::Visible;
    } else {
      *visibility = Visibility::Hidden;
    }
  }
}
fn save_report(
  mut commands: Commands,
  pack: Option<ResMut<Pack>>,
  mut capture: ResMut<RenderCapture>,
  catalog: Res<GameAssetCatalog>,
  tracker: Res<GameAssetLoadStateTracker>,
  meshes: Query<Entity, With<Mesh3d>>,
  roots: Query<Entity, With<PreviewProp>>,
  children: Query<&Children>,
  mut status: Query<&mut Text, With<PreviewStatus>>,
  mut exit: MessageWriter<AppExit>,
) {
  let Some(mut pack) = pack else {
    return;
  };
  pack.frames += 1;
  if pack.saved {
    return;
  }
  let failed = !catalog.problems.is_empty()
    || catalog.entries.keys().any(|id| tracker.state(id) == GameAssetLoadState::Failed);
  let expected_props = pack.manifest.assets.iter().filter(|asset| asset.kind == "prop_3d").count();
  let pending_scene = roots.iter().count() != expected_props
    || roots.iter().any(|root| !has_mesh(root, &children, &meshes));
  if !failed && (pack.frames < 30 || !pack.spawned || pending_scene) {
    if pack.started.elapsed() < Duration::from_secs(90) {
      return;
    }
  }
  let resources_ready = pack.spawned && !failed && !pending_scene;
  if resources_ready && !capture.requested {
    capture.requested = true;
    commands.spawn(Screenshot::primary_window()).observe(capture_rendered_frame);
    for mut text in &mut status {
      text.0 = "资产已就绪，正在保存实际渲染画面与报告…".into();
    }
    return;
  }
  if resources_ready
    && capture.maybe_frame.is_none()
    && capture.maybe_problem.is_none()
    && pack.started.elapsed() < Duration::from_secs(90)
  {
    return;
  }
  let succeeded = resources_ready && capture.maybe_frame.is_some();
  let assets=pack.manifest.assets.iter().filter(|a|pack.raw.get("delivered_asset_ids").and_then(serde_json::Value::as_array).is_none_or(|ids|ids.iter().any(|id|id.as_str()==Some(a.asset_id.as_str())))).map(|a|serde_json::json!({"asset_id":a.asset_id,"version_id":a.version_id,"status":if succeeded{"loaded"}else{"failed"}})).collect();
  let mut value = report(
    &pack.raw,
    "runtime",
    if succeeded { "succeeded" } else { "failed" },
    assets,
    serde_json::json!({"frames":pack.frames,"instantiated_prop_roots":roots.iter().count(),"asset_root":pack.asset_root,"frame_capture":capture.maybe_frame}),
  );
  value["rendered"] = serde_json::json!(succeeded);
  let mut problems = catalog.problems.values().cloned().collect::<Vec<_>>();
  if let Some(problem) = &capture.maybe_problem {
    problems.push(problem.clone());
  }
  if !succeeded && problems.is_empty() {
    problems.push("资源、场景或实际渲染画面尚未完成；检查原生窗口及加载错误后重新运行预览，已有资产无需重新生成。".into());
  }
  value["problems"] = serde_json::json!(problems);
  let result = (|| -> Result<PathBuf, String> {
    let folder = PathBuf::from("game_assets_reports");
    fs::create_dir_all(&folder).map_err(|e| e.to_string())?;
    let path = folder.join(format!(
      "runtime-{}.json",
      SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_nanos()
    ));
    fs::write(&path, serde_json::to_vec_pretty(&value).map_err(|e| e.to_string())?)
      .map_err(|e| e.to_string())?;
    Ok(path)
  })();
  match result {
    Ok(path) => {
      info!("实际运行报告：{}", path.display());
      for mut text in &mut status {
        text.0 = format!(
          "{} · 报告：{}",
          if succeeded { "已加载、实例化并渲染" } else { "未完成，请查看报告" },
          path.display()
        );
      }
    },
    Err(problem) => {
      error!("报告未保存：{problem}");
      exit.write(AppExit::error());
      pack.saved = true;
      return;
    },
  }
  pack.saved = true;
  if pack.exit_after {
    exit.write(if succeeded { AppExit::Success } else { AppExit::error() });
  }
}
fn capture_rendered_frame(event: On<ScreenshotCaptured>, mut capture: ResMut<RenderCapture>) {
  let result = (|| -> Result<serde_json::Value, String> {
    let image =
      event.image.clone().try_into_dynamic().map_err(|e| format!("渲染画面无法读取：{e}"))?;
    if image.width() == 0 || image.height() == 0 {
      return Err("渲染器返回了空画面。".into());
    }
    let folder = PathBuf::from("game_assets_reports");
    fs::create_dir_all(&folder).map_err(|e| format!("画面目录无法保存：{e}"))?;
    let path = folder.join(format!(
      "runtime-frame-{}.png",
      SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_nanos()
    ));
    image.save(&path).map_err(|e| format!("运行画面无法保存：{e}"))?;
    let digest = Sha256::digest(fs::read(&path).map_err(|e| e.to_string())?);
    Ok(
      serde_json::json!({"path":path,"width":image.width(),"height":image.height(),"sha256":hex::encode(digest)}),
    )
  })();
  match result {
    Ok(frame) => capture.maybe_frame = Some(frame),
    Err(problem) => capture.maybe_problem = Some(problem),
  }
}
fn has_mesh(
  root: Entity,
  children: &Query<&Children>,
  meshes: &Query<Entity, With<Mesh3d>>,
) -> bool {
  let mut stack = vec![root];
  while let Some(entity) = stack.pop() {
    if meshes.contains(entity) {
      return true;
    }
    if let Ok(list) = children.get(entity) {
      stack.extend(list.iter());
    }
  }
  false
}
