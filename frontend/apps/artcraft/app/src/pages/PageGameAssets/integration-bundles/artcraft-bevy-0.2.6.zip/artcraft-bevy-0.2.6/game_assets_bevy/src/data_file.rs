use std::{fs::File, io::Read, path::Path};
use serde_json::Value;

const MAX_IMAGE_EDGE: u32 = 8192;
const MAX_IMAGE_PIXELS: u64 = 36_000_000;
const MAX_GLB_JSON: u32 = 8 * 1024 * 1024;

/// Data packs cannot cause the game loader to fetch network or external files.
pub(crate) fn validate_data_file(path: &Path, mime: &str) -> Result<(), String> {
  let mut file = File::open(path).map_err(|e| e.to_string())?;
  match mime {
    "image/png" => {
      let mut header = [0u8; 24];
      file.read_exact(&mut header).map_err(|_| "PNG 文件头不完整。")?;
      if &header[..8] != b"\x89PNG\r\n\x1a\n" || &header[8..16] != b"\0\0\0\rIHDR" {
        return Err("PNG 文件头无效。".into());
      }
      let width = u32::from_be_bytes(header[16..20].try_into().unwrap());
      let height = u32::from_be_bytes(header[20..24].try_into().unwrap());
      if width == 0
        || height == 0
        || width > MAX_IMAGE_EDGE
        || height > MAX_IMAGE_EDGE
        || u64::from(width) * u64::from(height) > MAX_IMAGE_PIXELS
      {
        return Err("PNG 超出可用图像尺寸预算。".into());
      }
    },
    "model/gltf-binary" => {
      let mut header = [0u8; 20];
      file.read_exact(&mut header).map_err(|_| "GLB 文件头不完整。")?;
      let declared = u32::from_le_bytes(header[8..12].try_into().unwrap());
      let json_length = u32::from_le_bytes(header[12..16].try_into().unwrap());
      if &header[..4] != b"glTF"
        || header[4..8] != 2u32.to_le_bytes()
        || u64::from(declared) != file.metadata().map_err(|e| e.to_string())?.len()
        || json_length > MAX_GLB_JSON
        || u64::from(json_length) + 20 > u64::from(declared)
        || &header[16..20] != b"JSON"
      {
        return Err("GLB 头、版本或 JSON 区块无效。".into());
      }
      let mut bytes = vec![0; json_length as usize];
      file.read_exact(&mut bytes).map_err(|_| "GLB JSON 区块不完整。")?;
      let document: Value = serde_json::from_slice(&bytes).map_err(|_| "GLB JSON 无法读取。")?;
      if !document.is_object()
        || document.get("scene").is_some_and(|scene| scene.as_u64() != Some(0))
      {
        return Err("此组件要求 GLB 默认场景为场景 0。".into());
      }
      for field in ["buffers", "images"] {
        if let Some(entries) = document.get(field) {
          let entries = entries.as_array().ok_or("GLB 的资源索引类型无效。")?;
          for entry in entries {
            if !entry.is_object() {
              return Err("GLB 的资源条目无效。".into());
            }
            if let Some(uri) = entry.get("uri") {
              let uri = uri.as_str().ok_or("GLB 的资源地址类型无效。")?;
              let allowed = if field == "buffers" {
                uri.starts_with("data:application/octet-stream;base64,")
              } else {
                uri.starts_with("data:image/png;base64,")
                  || uri.starts_with("data:image/jpeg;base64,")
              };
              if !allowed {
                return Err("GLB 包含外部文件或网络引用，未进入游戏资源目录。".into());
              }
            }
          }
        }
      }
    },
    "application/json" => {},
    _ => return Err("资源类型不受此组件支持。".into()),
  }
  Ok(())
}

#[cfg(test)]
mod tests {
  use super::*;
  use std::{
    fs,
    time::{SystemTime, UNIX_EPOCH},
  };

  #[test]
  fn refuses_external_glb_dependencies_and_excessive_png_dimensions() {
    use crate::manifest::{GameAssetPackManifest, verify_pack_files};
    use sha2::{Digest, Sha256};
    let root = std::env::temp_dir().join(format!(
      "artcraft-data-boundary-{}",
      SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_nanos()
    ));
    fs::create_dir_all(&root).unwrap();
    for document in [
      serde_json::json!({"asset":{"version":"2.0"}, "images":[{"uri":"https://example.com/image.png"}]}),
      serde_json::json!({"buffers":[{"uri":"../../outside.bin"}]}),
      serde_json::json!({"scene":1}),
    ] {
      let mut json = document.to_string().into_bytes();
      while json.len() % 4 != 0 {
        json.push(b' ');
      }
      let mut bytes = b"glTF".to_vec();
      bytes.extend(2u32.to_le_bytes());
      bytes.extend(((json.len() + 20) as u32).to_le_bytes());
      bytes.extend((json.len() as u32).to_le_bytes());
      bytes.extend(b"JSON");
      bytes.extend(json);
      fs::write(root.join("main.glb"), bytes).unwrap();
      assert!(validate_data_file(&root.join("main.glb"), "model/gltf-binary").is_err());
    }
    let mut png = b"\x89PNG\r\n\x1a\n\0\0\0\rIHDR".to_vec();
    png.extend(9000u32.to_be_bytes());
    png.extend(10u32.to_be_bytes());
    fs::write(root.join("main.png"), png).unwrap();
    assert!(validate_data_file(&root.join("main.png"), "image/png").is_err());
    fs::create_dir_all(root.join("assets")).unwrap();
    fs::rename(root.join("main.png"), root.join("assets/main.png")).unwrap();
    let png = fs::read(root.join("assets/main.png")).unwrap();
    let raw = serde_json::json!({
      "schema_version":"1.1", "pack_id":"p", "project_id":"qa", "export_id":"e",
      "engine_profiles":[{"id":"bevy", "engine":"bevy", "engine_version":"0.20.0"}],
      "assets":[{"asset_id":"a", "stable_key":"a", "version_id":"v1", "kind":"icon_2d",
        "image":{"width":1,"height":1,"sampling":"linear"},
        "files":[{"role":"main","path":"assets/main.png","mime":"image/png","byte_length":png.len(),"sha256":hex::encode(Sha256::digest(&png))}]}]
    });
    let manifest = GameAssetPackManifest::parse_and_validate(&raw.to_string()).unwrap();
    let failures = verify_pack_files(&manifest, root.to_str().unwrap());
    assert!(
      failures.iter().any(|failure| failure.message.contains("尺寸预算")),
      "matching SHA must still pass the shared decoding boundary"
    );
    fs::remove_dir_all(root).unwrap();
  }
}
