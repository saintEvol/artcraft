@tool
extends VBoxContainer
## Named asset browsing, independent of download folders and opaque scene filenames.

signal selection_changed(installation: Dictionary)
signal preview_requested(path: String)
var _collections: OptionButton
var _search: LineEdit
var _assets: OptionButton
var _message: Label
var _packs: Array[Dictionary] = []
var _filtered: Array[Dictionary] = []
var _actions: Array[Button] = []

func _ready() -> void:
	var title := Label.new(); title.text = "工程中已安装的资产"; add_child(title)
	_collections = OptionButton.new(); _collections.fit_to_longest_item = false; _collections.accessibility_name = "选择已安装集合"; add_child(_collections)
	_collections.item_selected.connect(func(_index: int) -> void: _select_collection())
	var preview := Button.new(); preview.text = "查看这份安装的全部资产"; preview.pressed.connect(_preview); add_child(preview)
	var title_assets := Label.new(); title_assets.text = "选择要放进游戏的资产"; add_child(title_assets)
	_search = LineEdit.new(); _search.placeholder_text = "按资产名称查找"; _search.accessibility_name = "按名称查找已安装资产"; _search.clear_button_enabled = true; _search.text_changed.connect(func(_text: String) -> void: _filter_assets()); add_child(_search)
	_assets = OptionButton.new(); _assets.fit_to_longest_item = false; _assets.accessibility_name = "选择已安装资产"; add_child(_assets)
	var open := Button.new(); open.text = "在编辑器中打开这个资产"; open.pressed.connect(_open_asset); add_child(open)
	var locate := Button.new(); locate.text = "定位这个资产文件"; locate.pressed.connect(_locate_asset); add_child(locate)
	var copy := Button.new(); copy.text = "复制这个资产的场景路径"; copy.pressed.connect(_copy_path); add_child(copy)
	_actions = [open, locate, copy]
	_message = Label.new(); _message.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; add_child(_message)

func refresh(packs: Array[Dictionary], preferred: String) -> void:
	_packs = packs; _collections.clear()
	for index in _packs.size():
		_collections.add_item(_packs[index].label)
		if _packs[index].namespace == preferred: _collections.select(index)
	_collections.disabled = _packs.is_empty()
	_search.editable = not _packs.is_empty()
	_select_collection()

func _select_collection() -> void:
	_filter_assets()
	selection_changed.emit(_selected())

func _selected() -> Dictionary:
	return _packs[_collections.selected] if _collections.selected >= 0 and _collections.selected < _packs.size() else {}

func _filter_assets() -> void:
	_filtered.clear(); _assets.clear()
	var pack := _selected()
	if not pack.is_empty():
		var incoming := {}
		for asset in pack.manifest.assets: incoming[String(asset.asset_id)] = true
		for asset in pack.catalog.assets:
			if not String(asset.display_name).to_lower().contains(_search.text.strip_edges().to_lower()): continue
			_filtered.append(asset)
			_assets.add_item(String(asset.display_name) + (" · 3D" if asset.get("kind") == "prop_3d" else " · 2D") + (" · 此前保留" if not incoming.has(String(asset.asset_id)) else ""))
	_assets.disabled = _filtered.is_empty()
	for button in _actions: button.disabled = _filtered.is_empty()
	_message.text = "尚未安装资产。请切换到“导入或更新”，选择下载后解压的资源包。" if pack.is_empty() else "找到 %d 项。打开对应场景后，可将它实例化到自己的游戏场景；以后更新继续使用同一路径。" % _filtered.size()

func _asset_path() -> String:
	if _assets.selected < 0 or _assets.selected >= _filtered.size(): return ""
	return String(_selected().root).path_join("scenes/" + String(_filtered[_assets.selected].stable_key) + ".tscn")

func _open_asset() -> void:
	var path := _asset_path()
	if path.is_empty(): return
	if not FileAccess.file_exists(path): _message.text = "这个资产的场景文件缺失，请从原包重新导入以修复。"; return
	EditorInterface.open_scene_from_path(path)

func _locate_asset() -> void:
	var path := _asset_path()
	if not path.is_empty(): EditorInterface.get_file_system_dock().navigate_to_path(path)

func _copy_path() -> void:
	var path := _asset_path()
	if not path.is_empty(): DisplayServer.clipboard_set(path); _message.text = "场景路径已复制。可在自己的场景或脚本中引用这个资产。"

func _preview() -> void:
	var pack := _selected()
	if pack.is_empty(): _message.text = "先在“导入或更新”中安装一份资源包。"; return
	var path := String(pack.root).path_join("preview.tscn")
	if not FileAccess.file_exists(path): _message.text = "这份安装缺少总览场景，请重新导入以修复。"; return
	preview_requested.emit(path)
