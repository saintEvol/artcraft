/**
 * Artcraft 2D 帧动画运行时组件（§12.2 运行时切片方案，见 PROBES.md 与
 * cocos_creator_integration.md）。
 *
 * 该脚本由 artcraft-cocos 扩展作为托管文件安装到
 * assets/game_assets/<namespace>/runtime/ 下，属于工程脚本（编辑器负责编译），
 * 不依赖扩展、不依赖编辑器 API。换算规则与 src/core/playback.ts 逐条对齐：
 * - 统一采样 frameAt：循环 floor(t*fps) mod N；非循环 min(floor(t*fps), N-1)；
 * - 暂停保相位、切方向保帧号、停止回第 0 帧；
 * - 平台锚点 (x,y) → 节点归一化 anchor (0.5-x, 0.5-y)；
 * - 1 平台世界单位 = 100 设计像素，节点 scale = 100 / pixels_per_world_unit
 *   （cocos 契约固定 100，属性留作显式表达）；
 * - 采样 filterMode 按 spec sampling（nearest/linear，默认 nearest）。
 *
 * 用法：把组件挂到带 Sprite 的 2D 节点上，指定图集 Texture2D 与 frames
 * JsonAsset（anim_2d 资产的 main/frames 两个文件）：
 *   const player = node.addComponent(GameAssetAnimation2d);
 *   player.atlas = texture2D; player.frameTableAsset = jsonAsset;
 *   player.play();
 */

import {
  _decorator,
  CCBoolean,
  CCFloat,
  CCInteger,
  Component,
  JsonAsset,
  Rect,
  Sprite,
  SpriteFrame,
  Texture2D,
} from "cc";

const { ccclass, property } = _decorator;

/** 与 core/playback.ts frameAt 一致（运行时自包含副本，契约冻结）。 */
export function artcraftFrameAt(time: number, fps: number, count: number, looping: boolean): number {
  const duration = count / fps;
  const phase = looping ? time % duration : Math.min(time, duration);
  return Math.min(Math.floor(phase * fps), count - 1);
}

interface FrameRectJson { x: number; y: number; width: number; height: number }
interface FrameTableJson {
  schema_version: string;
  clip_name: string;
  canvas: { width: number; height: number };
  anchor: { origin: string; x: number; y: number };
  atlas: { width: number; height: number; extrude_px: number };
  fps: number;
  loop: boolean;
  directions: { name: string; frames: FrameRectJson[] }[];
}

@ccclass("GameAssetAnimation2d")
export class GameAssetAnimation2d extends Component {
  /** 图集 Texture2D（anim_2d 的 main PNG，经 asset-db 导入后拖入）。 */
  @property(Texture2D)
  atlas: Texture2D | null = null;

  /** frames.json（anim_2d 的 frames 文件，JsonAsset）。 */
  @property(JsonAsset)
  frameTableAsset: JsonAsset | null = null;

  /** 方向行号（1/4/8 方向表的行下标）。 */
  @property(CCInteger)
  direction = 0;

  /** spec 的 pixels_per_world_unit（cocos 契约固定 100）。 */
  @property(CCFloat)
  pixelsPerWorldUnit = 100;

  /** spec sampling：nearest（默认，像素风防渗色）/ linear。 */
  @property({ type: CCBoolean })
  linearFilter = false;

  @property(CCBoolean)
  playOnStart = true;

  private table: FrameTableJson | null = null;
  private sprite: Sprite | null = null;
  private frameSprites: SpriteFrame[][] = [];
  private elapsed = 0;
  private playing = false;
  private lastFrame = -1;
  private lastDirection = -1;

  start(): void {
    this.sprite = this.getComponent(Sprite);
    this.reload();
    if (this.playOnStart) {
      this.play();
    }
  }

  /** 重新读取帧表并重建切片（atlas / frameTable 变更后调用）。 */
  reload(): void {
    this.table = null;
    this.frameSprites = [];
    this.lastFrame = -1;
    if (this.atlas === null || this.frameTableAsset === null) {
      return;
    }
    const raw = this.frameTableAsset.json as FrameTableJson | null;
    if (raw === null || raw.schema_version !== "game.anim2d.frames.v1") {
      return;
    }
    this.table = raw;
    const filter = this.linearFilter ? Texture2D.Filter.LINEAR : Texture2D.Filter.NEAREST;
    this.atlas.setFilters(filter, filter);
    this.frameSprites = raw.directions.map((direction) => direction.frames.map((rect) => {
      // 运行时切片：任意 rect（非等分格）。帧表 rect 以图集左上为原点；
      // SpriteFrame.rect 以纹理左下为原点，换轴一次。
      const flipY = this.atlas!.height - rect.y - rect.height;
      const spriteFrame = new SpriteFrame();
      spriteFrame.texture = this.atlas!;
      spriteFrame.rect = new Rect(rect.x, flipY, rect.width, rect.height);
      return spriteFrame;
    }));
    if (this.sprite !== null && this.frameSprites.length > 0 && this.frameSprites[0].length > 0) {
      // Sprite 尺寸 = 画布尺寸；世界单位经节点 scale 表达（worldUnitScale）。
      this.sprite.sizeMode = Sprite.SizeMode.CUSTOM;
      this.node.setContentSize(raw.canvas.width, raw.canvas.height);
      const scale = this.worldUnitScale();
      this.node.setScale(scale, scale, 1);
      this.sprite.spriteFrame = this.frameSprites[0][0];
    }
    this.applyAnchor();
  }

  play(): void {
    if (this.table === null) {
      return;
    }
    this.playing = true;
  }

  pause(): void {
    this.playing = false;
  }

  stop(): void {
    this.playing = false;
    this.elapsed = 0;
    this.lastFrame = -1;
    this.applyFrame();
  }

  /** 切方向行：帧号/相位保持（core Animation2dPlayback.setDirection）。 */
  setDirection(direction: number): void {
    if (this.table === null || direction < 0 || direction >= this.frameSprites.length) {
      return;
    }
    this.direction = direction;
    this.lastFrame = -1;
    this.applyFrame();
  }

  update(deltaTime: number): void {
    if (!this.playing || this.table === null) {
      return;
    }
    // 暂停保相位：不 playing 就不推进 elapsed；负/NaN 忽略。
    if (Number.isFinite(deltaTime) && deltaTime > 0) {
      this.elapsed += deltaTime;
    }
    this.applyFrame();
  }

  /** 当前方向行内的帧号（统一采样规则）。 */
  currentFrame(): number {
    if (this.table === null) {
      return 0;
    }
    const frames = this.table.directions[this.direction]?.frames.length ?? 0;
    if (frames === 0) {
      return 0;
    }
    return artcraftFrameAt(this.elapsed, this.table.fps, frames, this.table.loop);
  }

  /** 节点 scale：100 / pixels_per_world_unit（1 世界单位 = 100 设计像素）。 */
  worldUnitScale(): number {
    return this.pixelsPerWorldUnit > 0 ? 100 / this.pixelsPerWorldUnit : 1;
  }

  private applyFrame(): void {
    if (this.sprite === null || this.table === null) {
      return;
    }
    const index = this.currentFrame();
    if (index === this.lastFrame && this.direction === this.lastDirection) {
      return;
    }
    const frames = this.frameSprites[this.direction];
    if (frames === undefined || frames.length === 0) {
      return;
    }
    this.lastFrame = index;
    this.lastDirection = this.direction;
    this.sprite.spriteFrame = frames[Math.min(index, frames.length - 1)];
  }

  private applyAnchor(): void {
    if (this.table === null) {
      return;
    }
    // 平台 anchor（origin=top_left）→ Cocos 归一化 anchor：(0.5-x, 0.5-y)。
    this.node.setAnchorPoint(0.5 - this.table.anchor.x, 0.5 - this.table.anchor.y);
  }
}
