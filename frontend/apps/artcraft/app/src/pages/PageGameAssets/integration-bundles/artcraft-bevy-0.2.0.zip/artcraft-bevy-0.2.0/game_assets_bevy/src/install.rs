//! Transactional local-pack installation for the supported developer command.
use std::collections::HashMap;
use std::fs;
use std::io::Read;
use std::sync::atomic::{AtomicU64, Ordering};
use std::path::{Component, Path};
use std::time::{SystemTime, UNIX_EPOCH};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use crate::manifest::{verify_pack_files, GameAssetPackManifest};

pub const IMPORTER_VERSION: &str = "game_assets_bevy_1@0.2.0";
static NONCE_COUNTER: AtomicU64 = AtomicU64::new(0);

#[derive(Clone, Copy, PartialEq, Eq)]
pub enum ConflictDecision {
  Stop,
  Keep,
  Copy,
  Replace,
}

pub fn install_pack(
  source: &Path,
  assets_root: &Path,
  decision: ConflictDecision,
) -> Result<Value, String> {
  no_links(source, "manifest.json")?;
  let mut text = String::new();
  fs::File::open(source.join("manifest.json"))
    .and_then(|file| file.take(4 * 1024 * 1024 + 1).read_to_string(&mut text))
    .map_err(|e| format!("无法读取资源包清单：{e}"))?;
  if text.len() > 4 * 1024 * 1024 {
    return Err("清单超过 4 MiB。".into());
  }
  let manifest = GameAssetPackManifest::parse_and_validate(&text)
    .map_err(|p| p.into_iter().map(|p| p.message).collect::<Vec<_>>().join("; "))?;
  if manifest.assets.len() > 500 {
    return Err("每份包最多导入 500 项资产，请分批交付。".into());
  }
  if !manifest.engine_profiles.iter().any(|p| p.engine == "bevy" && p.engine_version == "0.20.0") {
    return Err("此组件要求包内 Bevy profile 为 0.20.0。".into());
  }
  let mut raw: Value = serde_json::from_str(&text).map_err(|e| e.to_string())?;
  let incoming = raw.clone();
  let mut namespace = manifest.project_namespace();
  if !safe_namespace(&namespace) {
    return Err("项目命名空间不安全。".into());
  }
  let mut total = 0u64;
  let mut paths = HashMap::new();
  for asset in &manifest.assets {
    for file in &asset.files {
      check_relative(&file.path)?;
      if !file.path.starts_with("assets/") {
        return Err("资源文件必须位于 assets 目录，不能覆盖导入状态。".into());
      }
      no_links(source, &file.path)?;
      let allowed = match file.mime.as_str() {
        "image/png" => "png",
        "model/gltf-binary" => "glb",
        "application/json" => "json",
        _ => return Err("包内只接受 PNG、GLB 和 JSON 数据。".into()),
      };
      if Path::new(&file.path).extension().and_then(|v| v.to_str()) != Some(allowed) {
        return Err(format!("扩展名与文件类型不同：{}", file.path));
      }
      if file.byte_length > 250 * 1024 * 1024 {
        return Err("单文件超过 250 MiB。".into());
      }
      if let Some(old) = paths.insert(file.path.clone(), file.sha256.clone()) {
        if old != file.sha256 {
          return Err("同一路径声明了不同内容。".into());
        }
      } else {
        total = total.checked_add(file.byte_length).ok_or("文件大小溢出")?;
      }
    }
  }
  if total > 1024 * 1024 * 1024 {
    return Err("包数据超过 1 GiB。".into());
  }
  let integrity = verify_pack_files(&manifest, &source.to_string_lossy());
  if !integrity.is_empty() {
    return Err(integrity.iter().map(|p| p.message.clone()).collect::<Vec<_>>().join("; "));
  }
  fs::create_dir_all(assets_root).map_err(|e| e.to_string())?;
  no_links(assets_root, "game_assets")?;
  let parent = assets_root.join("game_assets");
  fs::create_dir_all(&parent).map_err(|e| e.to_string())?;
  if decision == ConflictDecision::Copy {
    namespace = format!(
      "{}_copy_{}",
      namespace.chars().take(40).collect::<String>(),
      &hex::encode(Sha256::digest(nonce().as_bytes()))[..16]
    );
  }
  let lock_name = format!(".artcraft-lock-{namespace}");
  no_links(&parent, &lock_name)?;
  let lock = fs::OpenOptions::new()
    .create(true)
    .read(true)
    .write(true)
    .open(parent.join(lock_name))
    .map_err(|e| e.to_string())?;
  lock.try_lock().map_err(|_| "同一项目还有导入正在进行，请稍后再试。")?;
  let destination = parent.join(&namespace);
  no_links(&parent, &namespace)?;
  let marker = parent.join(format!(".artcraft-pending-{namespace}.json"));
  recover(&destination, &marker)?;
  let existed = destination.exists();
  let journal_path = destination.join("import_journal.json");
  let journal: Value = if journal_path.exists() {
    serde_json::from_slice(&fs::read(&journal_path).map_err(|e| e.to_string())?)
      .map_err(|_| "已有导入记录损坏，未覆盖当前文件。")?
  } else {
    json!({"files":{}})
  };
  let recorded = journal.get("files").and_then(Value::as_object).ok_or("导入记录格式无效。")?;
  let mut conflicts = Vec::new();
  for (path, expected) in &paths {
    no_links(&destination, path)?;
    let file = destination.join(path);
    if file.exists()
      && (recorded.get(path).and_then(Value::as_str).is_none()
        || sha(&file)? != recorded[path].as_str().unwrap_or(""))
    {
      conflicts.push(path.clone());
    }
    if let Some(old) = recorded.get(path) {
      if !file.exists() && old.as_str() != Some(expected) {
        conflicts.push(path.clone());
      }
    }
  }
  if !conflicts.is_empty() && decision == ConflictDecision::Stop {
    return Ok(report(
      &raw,
      "update",
      "conflicts",
      vec![],
      json!({"conflicts":conflicts,"message":"发现本地修改，未写入当前资源；可保留、另存或备份后替换。"}),
    ));
  }
  if !conflicts.is_empty() && decision == ConflictDecision::Keep {
    return Ok(report(
      &raw,
      "update",
      "partial",
      vec![],
      json!({"conflicts":conflicts,"message":"已保留当前全部版本，没有应用本次更新。"}),
    ));
  }
  let delivered =
    manifest.assets.iter().map(|a| a.asset_id.clone()).collect::<std::collections::HashSet<_>>();
  if destination.join("manifest.json").exists() {
    let old: Value = serde_json::from_slice(
      &fs::read(destination.join("manifest.json")).map_err(|e| e.to_string())?,
    )
    .map_err(|_| "旧清单无效，未替换当前资源。")?;
    if let Some(assets) = old.get("assets").and_then(Value::as_array) {
      for asset in assets {
        if asset.get("asset_id").and_then(Value::as_str).is_some_and(|id| !delivered.contains(id)) {
          raw["assets"].as_array_mut().ok_or("清单格式无效")?.push(asset.clone());
        }
      }
    }
  }
  if decision == ConflictDecision::Copy {
    raw["source_project_id"] = raw["project_id"].clone();
    raw["project_id"] = json!(namespace);
  }
  raw["delivered_asset_ids"] =
    json!(manifest.assets.iter().map(|a| a.asset_id.clone()).collect::<Vec<_>>());
  GameAssetPackManifest::parse_and_validate(&raw.to_string())
    .map_err(|_| "合并后的受管理清单无效，未覆盖当前文件。")?;
  let mut retained_files = recorded.clone();
  for (path, hash) in &paths {
    retained_files.insert(path.clone(), json!(hash));
  }
  let stamp = nonce();
  let stage = parent.join(format!(".artcraft-stage-{stamp}"));
  let backup = parent.join(format!(".artcraft-backup-{stamp}"));
  fs::create_dir(&stage).map_err(|e| e.to_string())?;
  if existed {
    copy_tree(&destination, &stage)?;
  }
  for asset in &manifest.assets {
    for file in &asset.files {
      let target = stage.join(&file.path);
      fs::create_dir_all(target.parent().ok_or("目标目录缺失")?).map_err(|e| e.to_string())?;
      fs::copy(source.join(&file.path), &target).map_err(|e| e.to_string())?;
      if sha(&target)? != file.sha256.to_lowercase() {
        return Err("准备后的文件校验不一致，未替换当前资源。".into());
      }
    }
  }
  fs::write(
    stage.join("manifest.json"),
    serde_json::to_vec_pretty(&raw).map_err(|e| e.to_string())?,
  )
  .map_err(|e| e.to_string())?;
  fs::write(
    stage.join("import_journal.json"),
    serde_json::to_vec_pretty(&json!({"format":"artcraft-bevy-install.v1","files":retained_files}))
      .map_err(|e| e.to_string())?,
  )
  .map_err(|e| e.to_string())?;
  let pending = json!({"format":"artcraft-bevy-transaction.v1","stage":stage.file_name().unwrap().to_string_lossy(),"backup":backup.file_name().unwrap().to_string_lossy(),"committed":false});
  fs::write(&marker, serde_json::to_vec(&pending).unwrap()).map_err(|e| e.to_string())?;
  if existed {
    fs::rename(&destination, &backup).map_err(|e| e.to_string())?;
  }
  if let Err(error) = fs::rename(&stage, &destination) {
    recover(&destination, &marker)?;
    return Err(format!("替换未完成，已请求恢复：{error}"));
  }
  let mut committed = pending;
  committed["committed"] = json!(true);
  fs::write(&marker, serde_json::to_vec(&committed).unwrap()).map_err(|e| e.to_string())?;
  fs::remove_file(&marker).map_err(|e| e.to_string())?;
  let assets = manifest
    .assets
    .iter()
    .map(|a| json!({"asset_id":a.asset_id,"version_id":a.version_id,"status":"imported"}))
    .collect();
  Ok(report(
    &incoming,
    if existed { "update" } else { "import" },
    "succeeded",
    assets,
    json!({"managed_root":destination,"previous_files":if existed {Some(backup)} else {None},"missing_files_are_retained":true}),
  ))
}

pub fn report(
  manifest: &Value,
  operation: &str,
  status: &str,
  assets: Vec<Value>,
  detail: Value,
) -> Value {
  json!({"schema_version":"game-assets-engine-report.v1","pack_id":manifest.get("pack_id"),"engine":"bevy","engine_version":"0.20.0","importer_version":IMPORTER_VERSION,"operation":operation,"status":status,"rendered":false,"assets":assets,"detail":detail})
}

fn recover(destination: &Path, marker: &Path) -> Result<(), String> {
  if !marker.exists() {
    return Ok(());
  }
  let data: Value = serde_json::from_slice(&fs::read(marker).map_err(|e| e.to_string())?)
    .map_err(|_| "恢复记录无效，保留当前内容。")?;
  if data["format"] != "artcraft-bevy-transaction.v1" {
    return Err("恢复记录不属于此组件。".into());
  }
  let parent = destination.parent().ok_or("恢复目录无效")?;
  let stage_name = data["stage"].as_str().ok_or("恢复记录缺少工作目录")?;
  let backup_name = data["backup"].as_str().ok_or("恢复记录缺少备份目录")?;
  for name in [stage_name, backup_name] {
    check_relative(name)?;
    if name.contains('/') || !name.starts_with(".artcraft-") {
      return Err("恢复目录不属于组件。".into());
    }
  }
  let stage = parent.join(stage_name);
  let backup = parent.join(backup_name);
  if data["committed"] != true {
    if destination.exists() && stage.exists() && !backup.exists() {
      return fs::remove_file(marker).map_err(|e| e.to_string());
    }
    if destination.exists() {
      if stage.exists() {
        return Err("工作目录冲突，请保留当前文件并核对恢复记录。".into());
      }
      fs::rename(destination, &stage).map_err(|e| e.to_string())?;
    }
    if backup.exists() {
      fs::rename(backup, destination).map_err(|e| e.to_string())?;
    }
  }
  fs::remove_file(marker).map_err(|e| e.to_string())
}

fn safe_namespace(value: &str) -> bool {
  !value.is_empty()
    && value.len() <= 64
    && value.bytes().all(|b| b.is_ascii_lowercase() || b.is_ascii_digit() || b == b'_')
    && value.as_bytes()[0].is_ascii_lowercase()
}
fn check_relative(value: &str) -> Result<(), String> {
  if value.is_empty()
    || value.contains(['\\', ':'])
    || Path::new(value).components().any(|c| !matches!(c, Component::Normal(_)))
  {
    Err(format!("不安全的相对路径：{value}"))
  } else {
    Ok(())
  }
}
fn no_links(root: &Path, relative: &str) -> Result<(), String> {
  check_relative(relative)?;
  let mut path = root.to_path_buf();
  for part in Path::new(relative).components() {
    path.push(part);
    if let Ok(meta) = fs::symlink_metadata(&path) {
      if meta.file_type().is_symlink() {
        return Err("资源路径不能经过符号链接。".into());
      }
    }
  }
  Ok(())
}
fn sha(path: &Path) -> Result<String, String> {
  Ok(hex::encode(Sha256::digest(fs::read(path).map_err(|e| e.to_string())?)))
}
fn nonce() -> String {
  format!(
    "{}-{}-{}",
    std::process::id(),
    SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_nanos(),
    NONCE_COUNTER.fetch_add(1, Ordering::Relaxed)
  )
}
fn copy_tree(source: &Path, destination: &Path) -> Result<(), String> {
  for entry in fs::read_dir(source).map_err(|e| e.to_string())? {
    let entry = entry.map_err(|e| e.to_string())?;
    let meta = entry.file_type().map_err(|e| e.to_string())?;
    let target = destination.join(entry.file_name());
    if meta.is_symlink() {
      return Err("已有目录包含符号链接，未替换当前资源。".into());
    }
    if meta.is_dir() {
      fs::create_dir_all(&target).map_err(|e| e.to_string())?;
      copy_tree(&entry.path(), &target)?;
    } else {
      fs::copy(entry.path(), target).map_err(|e| e.to_string())?;
    }
  }
  Ok(())
}

#[cfg(test)]
mod tests {
  use super::*;
  use std::path::PathBuf;

  struct Sandbox(PathBuf);
  impl Sandbox {
    fn new() -> Self {
      let p = std::env::temp_dir().join(format!("artcraft-install-test-{}", nonce()));
      fs::create_dir(&p).unwrap();
      Self(p)
    }
  }
  impl Drop for Sandbox {
    fn drop(&mut self) {
      let _ = fs::remove_dir_all(&self.0);
    }
  }

  #[test]
  fn conflict_choices_keep_original_and_copy_uses_a_different_identity_domain() {
    let sandbox = Sandbox::new();
    let source = sandbox.0.join("source");
    let assets = sandbox.0.join("assets");
    write_fixture(&source, &[("a", "v1")]);
    let first = install_pack(&source, &assets, ConflictDecision::Stop).unwrap();
    assert_eq!(first["status"], "succeeded");
    let destination = assets.join("game_assets/qa_game");
    let file = destination.join("assets/a/main.png");
    fs::write(&file, b"my local change").unwrap();
    write_fixture(&source, &[("a", "v2")]);
    assert_eq!(
      install_pack(&source, &assets, ConflictDecision::Stop).unwrap()["status"],
      "conflicts"
    );
    assert_eq!(
      install_pack(&source, &assets, ConflictDecision::Keep).unwrap()["status"],
      "partial"
    );
    assert_eq!(fs::read(&file).unwrap(), b"my local change");
    let copy = install_pack(&source, &assets, ConflictDecision::Copy).unwrap();
    let root = PathBuf::from(copy["detail"]["managed_root"].as_str().unwrap());
    assert_ne!(root, destination);
    let managed: Value =
      serde_json::from_slice(&fs::read(root.join("manifest.json")).unwrap()).unwrap();
    assert_ne!(managed["project_id"], "qa_game");
    assert_eq!(fs::read(&file).unwrap(), b"my local change");
    let replaced = install_pack(&source, &assets, ConflictDecision::Replace).unwrap();
    let backup = PathBuf::from(replaced["detail"]["previous_files"].as_str().unwrap());
    assert_eq!(fs::read(backup.join("assets/a/main.png")).unwrap(), b"my local change");
  }

  #[test]
  fn partial_update_retains_old_catalog_ids_files_and_expected_hashes() {
    let sandbox = Sandbox::new();
    let source = sandbox.0.join("source");
    let assets = sandbox.0.join("assets");
    write_fixture(&source, &[("a", "v1"), ("b", "v1")]);
    install_pack(&source, &assets, ConflictDecision::Stop).unwrap();
    write_fixture(&source, &[("a", "v2")]);
    let update = install_pack(&source, &assets, ConflictDecision::Stop).unwrap();
    assert_eq!(update["status"], "succeeded");
    assert_eq!(update["assets"].as_array().unwrap().len(), 1);
    let destination = assets.join("game_assets/qa_game");
    let managed: Value =
      serde_json::from_slice(&fs::read(destination.join("manifest.json")).unwrap()).unwrap();
    assert_eq!(managed["assets"].as_array().unwrap().len(), 2);
    assert!(destination.join("assets/b/main.png").exists());
    let journal: Value =
      serde_json::from_slice(&fs::read(destination.join("import_journal.json")).unwrap()).unwrap();
    assert!(journal["files"].get("assets/b/main.png").is_some());
  }

  #[test]
  fn interrupted_swap_recovers_before_or_after_directory_rename() {
    let sandbox = Sandbox::new();
    let root = sandbox.0.join("current");
    let stage = sandbox.0.join(".artcraft-stage-test");
    let backup = sandbox.0.join(".artcraft-backup-test");
    let marker = sandbox.0.join("pending.json");
    fs::create_dir(&root).unwrap();
    fs::write(root.join("original"), b"keep").unwrap();
    fs::create_dir(&stage).unwrap();
    fs::write(stage.join("new"), b"new").unwrap();
    let pending = json!({"format":"artcraft-bevy-transaction.v1","stage":".artcraft-stage-test","backup":".artcraft-backup-test","committed":false});
    fs::write(&marker, pending.to_string()).unwrap();
    recover(&root, &marker).unwrap();
    assert!(root.join("original").exists());
    fs::rename(&root, &backup).unwrap();
    fs::rename(&stage, &root).unwrap();
    fs::write(&marker, pending.to_string()).unwrap();
    recover(&root, &marker).unwrap();
    assert!(root.join("original").exists());
    assert!(!root.join("new").exists());
  }

  fn write_fixture(root: &Path, assets: &[(&str, &str)]) {
    let bytes=hex::decode("89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000a49444154789c63000100000500010d0a2db40000000049454e44ae426082").unwrap();
    let items=assets.iter().map(|(id,version)|{let path=format!("assets/{id}/main.png");fs::create_dir_all(root.join(format!("assets/{id}"))).unwrap();fs::write(root.join(&path),&bytes).unwrap();json!({"asset_id":id,"stable_key":id,"version_id":version,"kind":"icon_2d","files":[{"role":"main","path":path,"sha256":hex::encode(Sha256::digest(&bytes)),"byte_length":bytes.len(),"mime":"image/png"}],"image":{"width":1,"height":1,"sampling":"linear"}})}).collect::<Vec<_>>();
    fs::write(root.join("manifest.json"),json!({"schema_version":"1.1","pack_id":"p","project_id":"qa_game","export_id":"export","engine_profiles":[{"id":"bevy","engine":"bevy","engine_version":"0.20.0"}],"assets":items}).to_string()).unwrap();
  }
}
