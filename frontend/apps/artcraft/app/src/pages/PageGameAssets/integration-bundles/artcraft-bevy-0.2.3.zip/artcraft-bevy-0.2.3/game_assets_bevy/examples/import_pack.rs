use std::{
  fs,
  io::Read,
  path::PathBuf,
  time::{SystemTime, UNIX_EPOCH},
};
use bevy::{log::LogPlugin, prelude::*};
use game_assets_bevy::install::{install_pack, report as make_report, ConflictDecision};

fn main() -> AppExit {
  App::new()
    .add_plugins(MinimalPlugins)
    .add_plugins(LogPlugin::default())
    .add_systems(Startup, run)
    .run()
}
fn run(mut exit: MessageWriter<AppExit>) {
  let args = std::env::args().skip(1).collect::<Vec<_>>();
  let result = (|| -> Result<bool, String> {
    if args.len() < 2 {
      return Err(
        "用法：import_pack <解压后的资源包> <游戏 assets 目录> [cancel|keep|copy|replace]".into(),
      );
    }
    let decision = match args.get(2).map(String::as_str).unwrap_or("cancel") {
      "cancel" => ConflictDecision::Stop,
      "keep" => ConflictDecision::Keep,
      "copy" => ConflictDecision::Copy,
      "replace" => ConflictDecision::Replace,
      _ => return Err("未知冲突处理方式。".into()),
    };
    let report = match install_pack(&PathBuf::from(&args[0]), &PathBuf::from(&args[1]), decision) {
      Ok(report) => report,
      Err(problem) => {
        let mut text = String::new();
        let manifest = fs::File::open(PathBuf::from(&args[0]).join("manifest.json"))
          .and_then(|file| file.take(4 * 1024 * 1024 + 1).read_to_string(&mut text))
          .ok()
          .filter(|_| text.len() <= 4 * 1024 * 1024)
          .and_then(|_| serde_json::from_str::<serde_json::Value>(&text).ok())
          .filter(|manifest| {
            manifest
              .get("pack_id")
              .and_then(serde_json::Value::as_str)
              .is_some_and(|id| !id.is_empty())
          });
        let Some(manifest) = manifest else {
          return Err(format!("{problem}；清单无法识别资源包身份，没有生成可上传的报告。"));
        };
        error!("导入未完成：{problem}");
        let mut report = make_report(
          &manifest,
          "import",
          "failed",
          vec![],
          serde_json::json!({"message":problem}),
        );
        report["problems"] = serde_json::json!([problem]);
        report
      },
    };
    let root = PathBuf::from("game_assets_reports");
    fs::create_dir_all(&root).map_err(|e| e.to_string())?;
    let path = root.join(format!(
      "import-{}.json",
      SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_nanos()
    ));
    fs::write(&path, serde_json::to_vec_pretty(&report).map_err(|e| e.to_string())?)
      .map_err(|e| e.to_string())?;
    info!("资产导入结果：{}；报告：{}", report["status"], path.display());
    if let Some(destination) = report.pointer("/detail/managed_root") {
      info!("运行预览时使用目录：{destination}");
    }
    Ok(report["status"] == "succeeded" || report["status"] == "partial")
  })();
  match result {
    Ok(true) => {
      exit.write(AppExit::Success);
    },
    Ok(false) => {
      exit.write(AppExit::error());
    },
    Err(problem) => {
      error!("导入未完成：{problem}");
      exit.write(AppExit::error());
    },
  }
}
