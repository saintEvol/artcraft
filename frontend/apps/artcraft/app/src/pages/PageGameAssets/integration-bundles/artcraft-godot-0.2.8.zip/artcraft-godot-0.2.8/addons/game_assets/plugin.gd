@tool
extends EditorPlugin

const GAME_ASSETS_PANEL := preload("res://addons/game_assets/panel.tscn")

var _panel: Control

func _enter_tree() -> void:
	# The CLI owns import/recovery and has no dock to display or retain at shutdown.
	if OS.get_cmdline_args().has("--script") and OS.get_cmdline_args().has("res://addons/game_assets/import_cli.gd"):
		return
	_panel = GAME_ASSETS_PANEL.instantiate()
	_panel.name = "GameAssets"
	add_control_to_dock(DOCK_SLOT_RIGHT_BL, _panel)

func _exit_tree() -> void:
	if _panel:
		remove_control_from_docks(_panel)
		_panel.queue_free()
