extends SceneTree
## Compatibility launcher: run without --editor. The child uses Godot's normal
## editor main loop; --editor + --script in 4.7.2 leaks the overwritten SceneTree.

func _init() -> void:
	call_deferred("_run")

func _run() -> void:
	if Engine.is_editor_hint():
		push_error("请改用：godot --headless --editor --path 工程 -- --game-assets-import 资源包目录。使用 --script 兼容入口时请移除 --editor。")
		quit(2); return
	var output: Array = []
	var arguments := PackedStringArray(["--headless", "--editor", "--path", ProjectSettings.globalize_path("res://"), "--", "--game-assets-import"])
	arguments.append_array(OS.get_cmdline_user_args())
	var status := OS.execute(OS.get_executable_path(), arguments, output, true)
	for chunk in output: print(chunk)
	quit(status if status >= 0 else 1)

