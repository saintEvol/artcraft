//! Catalog + load-state tracking (plan section 15.2).

use std::collections::HashMap;

use bevy::asset::{AssetServer, Handle, LoadState};
use bevy::prelude::*;

use crate::lod::GameAssetLodChain;
use crate::manifest::{GameAssetPackManifest, ManifestAsset};
use crate::GameAssetId;

/// One catalogued asset: identity + version + loaded handles + spec.
#[derive(Debug, Clone)]
pub struct GameAssetEntry {
  pub id: GameAssetId,
  pub version_id: String,
  pub display_name: String,
  pub kind: String,
  /// Handles to every file role, by role name.
  pub image: Option<Handle<Image>>,
  pub render_image: Option<Handle<Image>>,
  pub atlas: Option<crate::manifest::ManifestAtlas>,
  pub pixels_per_world_unit: f32,
  pub scene: Option<Handle<WorldAsset>>,
  pub width: u32,
  pub height: u32,
  pub anchor: (f32, f32),
  pub sampling: String,
  pub triangles: Option<u64>,
  pub collision: Option<crate::spawn::GameAssetCollisionDescriptor>,
  /// Explicit LOD chain (plan 13.5): None when the asset ships main-only.
  pub lod: Option<GameAssetLodChain>,
}

/// The catalog maps stable IDs to versions/handles. Re-importing a pack
/// with updated content UPDATES entries in place; [`GameAssetId`]s stay
/// valid, which is the update-without-losing-references guarantee.
#[derive(Debug, Clone, Default, Resource)]
pub struct GameAssetCatalog {
  pub namespace: String,
  pub pack_id: Option<String>,
  pub entries: HashMap<GameAssetId, GameAssetEntry>,
  /// Assets the pack lists but the catalog refused (e.g. no main file):
  /// surfaced as Failed load states with the reason, never silently
  /// dropped (plan 15.3: missing/damaged resources must fail loudly).
  pub problems: HashMap<GameAssetId, String>,
}

impl GameAssetCatalog {
  /// Load every pack file through the AssetServer and catalogue handles.
  /// Files load asynchronously; readiness is tracked by
  /// [`crate::state::GameAssetLoadState`].
  pub fn load_pack(
    &mut self,
    asset_server: &AssetServer,
    manifest: &GameAssetPackManifest,
    pack_root: &str,
  ) {
    self.namespace = manifest.project_namespace();
    self.pack_id = Some(manifest.pack_id.clone());
    self.problems.clear();
    for asset in &manifest.assets {
      self.load_asset(asset_server, asset, pack_root);
    }
  }

  /// Explicit resource reload after a verified local installation. Existing
  /// helper-spawned roots keep their entity ids and game transforms.
  pub fn reload_pack(
    &mut self,
    server: &AssetServer,
    manifest: &GameAssetPackManifest,
    pack_root: &str,
  ) {
    for asset in &manifest.assets {
      for file in &asset.files {
        if ["main", "lod", "atlas_page"].contains(&file.role.as_str()) {
          server.reload(pack_path(pack_root, &file.path));
        }
      }
    }
    self.load_pack(server, manifest, pack_root);
  }

  fn load_asset(&mut self, asset_server: &AssetServer, asset: &ManifestAsset, pack_root: &str) {
    let id = GameAssetId::new(&self.namespace, &asset.stable_key);
    let main_file = asset
      .image
      .as_ref()
      .and_then(|image| image.atlas.as_ref())
      .and_then(|atlas| asset.files.get(atlas.page_file_index))
      .or_else(|| asset.files.iter().find(|file| file.role == "main"));
    let Some(main_file) = main_file else {
      self.problems.insert(id, "asset lists no main file".to_string());
      return;
    };
    let main_path = pack_path(pack_root, &main_file.path);

    let (image, scene, lod) = match asset.kind.as_str() {
      "icon_2d" | "sprite_2d" => {
        (Some(asset_server.load::<bevy::image::Image>(&main_path)), None, None)
      },
      "prop_3d" => {
        let scene = asset_server.load(
          bevy::gltf::GltfAssetLabel::Scene(
            asset.mesh.as_ref().map(|m| m.scene_index).unwrap_or(0),
          )
          .from_asset(main_path.clone()),
        );
        // Load every lod file's scene into the chain skeleton (plan
        // 13.5: the chain, not glTF, carries LOD behavior).
        let lod = asset.mesh.as_ref().and_then(|mesh| mesh.lod.as_ref()).map(|block| {
          let mut chain = GameAssetLodChain::from_manifest(block);
          for level in chain.levels.iter_mut() {
            let Some(manifest_level) = block.levels.iter().find(|l| l.level == level.level) else {
              continue;
            };
            let Some(file) = asset.files.get(manifest_level.file_index) else {
              continue;
            };
            let path = pack_path(pack_root, &file.path);
            level.scene = asset_server
              .load(bevy::gltf::GltfAssetLabel::Scene(manifest_level.scene_index).from_asset(path));
          }
          chain
        });
        (None, Some(scene), lod)
      },
      _ => (None, None, None),
    };

    let entry = GameAssetEntry {
      id: id.clone(),
      version_id: asset.version_id.clone(),
      display_name: if asset.display_name.trim().is_empty() {
        asset.stable_key.clone()
      } else {
        asset.display_name.clone()
      },
      kind: asset.kind.clone(),
      image,
      render_image: None,
      atlas: asset.image.as_ref().and_then(|i| i.atlas.clone()),
      pixels_per_world_unit: asset.image.as_ref().map(|i| i.pixels_per_world_unit).unwrap_or(100.0),
      scene,
      width: asset
        .image
        .as_ref()
        .map(|i| i.atlas.as_ref().map(|a| a.uncropped_size.width).unwrap_or(i.width))
        .unwrap_or(0),
      height: asset
        .image
        .as_ref()
        .map(|i| i.atlas.as_ref().map(|a| a.uncropped_size.height).unwrap_or(i.height))
        .unwrap_or(0),
      anchor: asset
        .image
        .as_ref()
        .map(|i| {
          i.atlas.as_ref().map(|a| (a.anchor.x, a.anchor.y)).unwrap_or((i.anchor.x, i.anchor.y))
        })
        .unwrap_or((0.5, 0.5)),
      sampling: asset
        .image
        .as_ref()
        .map(|i| i.sampling.clone())
        .unwrap_or_else(|| "linear".to_string()),
      triangles: asset.mesh.as_ref().and_then(|m| m.triangles),
      collision: asset
        .mesh
        .as_ref()
        .and_then(|m| m.collision.as_ref())
        .and_then(|c| crate::spawn::GameAssetCollisionDescriptor::from_manifest(c)),
      lod,
    };
    self.entries.insert(id, entry);
  }

  pub fn get(&self, id: &GameAssetId) -> Option<&GameAssetEntry> {
    self.entries.get(id)
  }
}

/// Aggregate readiness of one asset: file loaded AND recursive
/// dependencies loaded. A bare Handle is NOT readiness (plan 15.2).
#[derive(Debug, Clone, Default, bevy::ecs::resource::Resource)]
pub struct GameAssetLoadStateTracker {
  pub states: HashMap<GameAssetId, GameAssetLoadState>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum GameAssetLoadState {
  #[default]
  NotLoaded,
  Loading,
  Loaded,
  Failed,
}

impl GameAssetLoadStateTracker {
  /// Refresh states from the asset server; call once per frame.
  pub fn update(&mut self, catalog: &GameAssetCatalog, asset_server: &AssetServer) {
    for (id, entry) in &catalog.entries {
      // Readiness = root asset loaded AND ALL recursive dependencies
      // loaded (direct-only dependency state would green-light a scene
      // whose textures are two levels deep, and misses root failures).
      let state = if let Some(handle) = &entry.image {
        match asset_server.load_state(handle) {
          LoadState::Loaded if entry.render_image.is_some() => GameAssetLoadState::Loaded,
          LoadState::Failed(_) => GameAssetLoadState::Failed,
          _ => GameAssetLoadState::Loading,
        }
      } else if let Some(handle) = &entry.scene {
        let main_state = match (
          asset_server.load_state(handle),
          asset_server.recursive_dependency_load_state(handle.id()),
        ) {
          (LoadState::Loaded, bevy::asset::RecursiveDependencyLoadState::Loaded) => true,
          _ => false,
        };
        let main_failed = matches!(asset_server.load_state(handle), LoadState::Failed(_))
          || matches!(
            asset_server.recursive_dependency_load_state(handle.id()),
            bevy::asset::RecursiveDependencyLoadState::Failed(_)
          );
        // LOD level scenes are part of the asset: readiness requires
        // every level loaded too (a failed level fails the asset —
        // spawn-at-level would otherwise hand out a stale/empty scene).
        let lod_ready = entry
          .lod
          .as_ref()
          .map(|chain| {
            chain.levels.iter().all(|level| {
              matches!(asset_server.load_state(&level.scene), LoadState::Loaded)
                && matches!(
                  asset_server.recursive_dependency_load_state(level.scene.id()),
                  bevy::asset::RecursiveDependencyLoadState::Loaded
                )
            })
          })
          .unwrap_or(true);
        let lod_failed = entry.lod.as_ref().is_some_and(|chain| {
          chain.levels.iter().any(|level| {
            matches!(asset_server.load_state(&level.scene), LoadState::Failed(_))
              || matches!(
                asset_server.recursive_dependency_load_state(level.scene.id()),
                bevy::asset::RecursiveDependencyLoadState::Failed(_)
              )
          })
        });
        if lod_failed || main_failed {
          GameAssetLoadState::Failed
        } else if main_state && lod_ready {
          GameAssetLoadState::Loaded
        } else {
          GameAssetLoadState::Loading
        }
      } else {
        GameAssetLoadState::Failed
      };
      self.states.insert(id.clone(), state);
    }
    // Refused assets overlay LAST: an id that is both in entries (stale
    // handle from a previous pack version) and in problems must report
    // Failed, never the stale entry's Loaded.
    for id in catalog.problems.keys() {
      self.states.insert(id.clone(), GameAssetLoadState::Failed);
    }
  }

  pub fn state(&self, id: &GameAssetId) -> GameAssetLoadState {
    self.states.get(id).copied().unwrap_or(GameAssetLoadState::NotLoaded)
  }
}

fn pack_path(root: &str, path: &str) -> String {
  if root.is_empty() {
    path.to_owned()
  } else {
    format!("{root}/{path}")
  }
}
