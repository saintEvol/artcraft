@tool
extends RefCounted
## 1 = live, 0 = exited, -1 = not reliably known.

static func state(pid: int) -> int:
	if pid <= 0: return -1
	if pid == OS.get_process_id(): return 1
	var output: Array = []
	if OS.get_name() in ["macOS", "Linux", "FreeBSD", "NetBSD", "OpenBSD"]:
		var status := OS.execute("/bin/ps", PackedStringArray(["-p", str(pid), "-o", "pid="]), output)
		var text := "".join(output).strip_edges()
		if status == 0 and text == str(pid): return 1
		if status == 1 and text.is_empty(): return 0
	elif OS.get_name() == "Windows":
		var executable := OS.get_environment("SystemRoot").path_join("System32/tasklist.exe")
		var status := OS.execute(executable, PackedStringArray(["/FI", "PID eq " + str(pid), "/FO", "CSV", "/NH"]), output)
		if status == 0:
			var pattern := RegEx.new(); pattern.compile('^"[^"]*","' + str(pid) + '",')
			for line in "".join(output).split("\n"):
				if pattern.search(line.strip_edges()) != null: return 1
			return 0
	return -1
