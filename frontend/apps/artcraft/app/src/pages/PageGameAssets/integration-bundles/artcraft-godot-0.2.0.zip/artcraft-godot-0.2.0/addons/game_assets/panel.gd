@tool
extends Control

const Importer := preload("res://addons/game_assets/importer.gd")
const Builder := preload("res://addons/game_assets/resource_builder.gd")
const Report := preload("res://addons/game_assets/engine_report.gd")

var _path: LineEdit
var _log: RichTextLabel
var _decision: OptionButton
var _importer
var _preview := ""
var _last_report: Dictionary = {}
var _busy := false

func _ready() -> void:
	var layout := VBoxContainer.new(); add_child(layout)
	var title := Label.new(); title.text = "游戏资产 · 导入与更新"; layout.add_child(title)
	_path = LineEdit.new(); _path.placeholder_text = "解压后包含 manifest.json 的目录"; layout.add_child(_path)
	var browse := Button.new(); browse.text = "选择资源包目录"; browse.pressed.connect(_browse); layout.add_child(browse)
	var preflight := Button.new(); preflight.text = "核对清单与更新差异"; preflight.pressed.connect(_preflight); layout.add_child(preflight)
	_decision = OptionButton.new()
	_decision.add_item("发现冲突时停止，不改动当前文件", 0)
	_decision.add_item("保留工程当前版本，不应用本次更新", 1)
	_decision.add_item("另存整包副本，原有引用保持原样", 2)
	_decision.add_item("保留完整备份后替换当前受管理文件", 3)
	layout.add_child(_decision)
	var apply := Button.new(); apply.text = "导入这份包 / 应用更新"; apply.pressed.connect(_import); layout.add_child(apply)
	var preview := Button.new(); preview.text = "打开资产预览"; preview.pressed.connect(_open_preview); layout.add_child(preview)
	var save := Button.new(); save.text = "保存导入报告"; save.pressed.connect(_save_report); layout.add_child(save)
	_log = RichTextLabel.new(); _log.bbcode_enabled = false; _log.size_flags_vertical = Control.SIZE_EXPAND_FILL; layout.add_child(_log)
	_log.text = "先核对包，再导入。场景写入 game_assets 管理目录，自定义游戏节点请放在自己的场景中。"

func _browse() -> void:
	var dialog := FileDialog.new(); dialog.file_mode = FileDialog.FILE_MODE_OPEN_DIR; dialog.access = FileDialog.ACCESS_FILESYSTEM
	dialog.dir_selected.connect(func(path: String) -> void: _path.text = path; dialog.queue_free())
	add_child(dialog); dialog.popup_centered(Vector2i(900, 600))

func _preflight() -> void:
	if _busy: return
	_importer = Importer.new()
	var ok: bool = _importer.preflight(_path.text.strip_edges())
	_log.clear()
	if not ok:
		_log.text = "核对未通过：\n" + "\n".join(_importer.report); return
	var plan: Dictionary = _importer.plan
	for kind in ["new", "updated", "unchanged", "conflicts", "missing"]:
		_log.append_text("%s：%s\n" % [{"new":"新增", "updated":"更新", "unchanged":"保持", "conflicts":"本地修改冲突", "missing":"本次未包含，保留原文件"}[kind], ", ".join(plan[kind])])

func _import() -> void:
	if _busy: return
	_busy = true; _log.text = "正在核对并准备资源…"
	_importer = Importer.new()
	var decisions := ["cancel", "keep", "copy", "replace"]
	if not _importer.import_pack(_path.text.strip_edges(), decisions[_decision.selected]):
		_log.text = "导入未完成：\n" + "\n".join(_importer.report); _busy = false; return
	if _importer.result.get("kept_current", false):
		_last_report = _importer.result; _log.text = "已保留工程当前全部版本，没有应用本次更新。"; _busy = false; return
	var filesystem := EditorInterface.get_resource_filesystem()
	filesystem.scan()
	for tick in 600:
		await get_tree().process_frame
		if not filesystem.is_scanning() and not filesystem.is_importing(): break
	var files: PackedStringArray = []
	for asset in _importer.manifest_data.assets:
		for entry in asset.files:
			if String(entry.path).get_extension() in ["png", "glb"]:
				files.append(_importer.managed_root.path_join(String(entry.path)))
	filesystem.reimport_files(files)
	for tick in 600:
		await get_tree().process_frame
		if not filesystem.is_scanning() and not filesystem.is_importing(): break
	var builder := Builder.new()
	if not builder.build(_importer.manifest_data, _importer.managed_root, _importer.managed_namespace):
		_importer.rollback(); _log.text = "引擎导入或场景生成失败，已请求恢复上一份：\n" + "\n".join(builder.problems); _busy = false; return
	if not _importer.finish_import():
		_log.text = "完成记录未保存，请重新核对：\n" + "\n".join(_importer.report); _busy = false; return
	_preview = builder.preview_path; _last_report = _importer.result
	filesystem.scan()
	_log.text = "已完成。资产场景位于 %s/scenes，可拖进自己的场景。\n点击打开资产预览，实际运行后再保存运行报告。" % _importer.managed_root
	_busy = false

func _open_preview() -> void:
	if _busy: return
	if _preview.is_empty(): _log.text = "请先成功导入本次资源包。"; return
	EditorInterface.open_scene_from_path(_preview)
	EditorInterface.play_custom_scene(_preview)

func _save_report() -> void:
	if _last_report.is_empty(): _log.text = "先核对并导入一份资源包，才能保存其结果。"; return
	var dialog := FileDialog.new(); dialog.file_mode = FileDialog.FILE_MODE_SAVE_FILE; dialog.access = FileDialog.ACCESS_FILESYSTEM
	dialog.add_filter("*.json", "引擎报告"); dialog.current_file = "game-assets-import-report.json"
	dialog.file_selected.connect(func(path: String) -> void: _log.text = "报告已保存。" if Report.save(_last_report, path) else "报告未保存，请重试。"; dialog.queue_free())
	add_child(dialog); dialog.popup_centered(Vector2i(900, 600))
