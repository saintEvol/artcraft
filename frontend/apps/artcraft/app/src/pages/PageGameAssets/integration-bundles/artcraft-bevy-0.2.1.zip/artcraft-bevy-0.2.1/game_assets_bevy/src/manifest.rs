//! Pack manifest model + validation (plan sections 14.2/14.3).
//!
//! Mirrors the M0 frozen JSON Schema (`asset_pack_manifest.schema.json`);
//! unknown schema MAJOR versions are rejected outright, same-major
//! unknown fields are tolerated per the contract.

use serde::Deserialize;

pub const SUPPORTED_SCHEMA_MAJOR: u64 = 1;

/// Consumer-side validation note: this parser is deliberately a subset of
/// the exporter schema — the exporter (artcraft-services) remains the
/// strict gate. Known leniencies: schema_version without a minor part and
/// uppercase-hex sha256 are accepted here;
/// exporters must not emit them.
#[derive(Debug, Clone, Deserialize)]
pub struct GameAssetPackManifest {
  /// "1.0"-style major.minor; major must be 1.
  pub schema_version: String,
  pub pack_id: String,
  pub project_id: String,
  pub export_id: String,
  pub engine_profiles: Vec<EngineProfile>,
  pub assets: Vec<ManifestAsset>,
}

#[derive(Debug, Clone, Deserialize)]
pub struct EngineProfile {
  pub id: String,
  pub engine: String,
  pub engine_version: String,
  #[serde(default)]
  pub validation_status: String,
  #[serde(default)]
  pub required_features: Option<Vec<String>>,
}

#[derive(Debug, Clone, Deserialize)]
pub struct ManifestAsset {
  pub asset_id: String,
  pub stable_key: String,
  #[serde(default)]
  pub display_name: String,
  pub version_id: String,
  /// icon_2d | sprite_2d | prop_3d.
  pub kind: String,
  pub files: Vec<ManifestFile>,
  #[serde(default)]
  pub image: Option<ManifestImage>,
  #[serde(default)]
  pub mesh: Option<ManifestMesh>,
}

#[derive(Debug, Clone, Deserialize)]
pub struct ManifestFile {
  pub role: String,
  /// Pack-relative POSIX path.
  pub path: String,
  pub sha256: String,
  pub byte_length: u64,
  pub mime: String,
}

#[derive(Debug, Clone, Deserialize)]
pub struct ManifestImage {
  pub width: u32,
  pub height: u32,
  #[serde(default = "default_anchor")]
  pub anchor: ManifestAnchor,
  /// linear | nearest (plan 15.2: per-asset sampling, never global
  /// ImagePlugin defaults).
  pub sampling: String,
  #[serde(default = "default_ppu")]
  pub pixels_per_world_unit: f32,
  #[serde(default)]
  pub atlas: Option<ManifestAtlas>,
}

fn default_ppu() -> f32 {
  100.0
}

#[derive(Debug, Clone, Deserialize)]
pub struct ManifestAtlas {
  pub page_file_index: usize,
  pub rect: AtlasRect,
  pub uncropped_size: AtlasSize,
  pub crop_offset: AtlasOffset,
  pub anchor: ManifestAnchor,
}
#[derive(Debug, Clone, Deserialize)]
pub struct AtlasRect {
  pub x: u32,
  pub y: u32,
  pub width: u32,
  pub height: u32,
}
#[derive(Debug, Clone, Deserialize)]
pub struct AtlasSize {
  pub width: u32,
  pub height: u32,
}
#[derive(Debug, Clone, Deserialize)]
pub struct AtlasOffset {
  pub x: u32,
  pub y: u32,
}

#[derive(Debug, Clone, Deserialize)]
pub struct ManifestAnchor {
  pub x: f32,
  pub y: f32,
  /// "top_left" (platform convention, Y down, [0,1]).
  #[serde(default = "default_origin")]
  pub origin: String,
}

#[derive(Debug, Clone, Deserialize)]
pub struct ManifestMesh {
  pub scene_index: usize,
  #[serde(default)]
  pub triangles: Option<u64>,
  #[serde(default)]
  pub collision: Option<ManifestCollision>,
  #[serde(default)]
  pub lod: Option<ManifestLod>,
}

#[derive(Debug, Clone, Deserialize)]
pub struct ManifestCollision {
  pub kind: String,
  #[serde(default)]
  pub center: Option<Vec<f32>>,
  #[serde(default)]
  pub half_extents: Option<Vec<f32>>,
}

/// LOD block (plan 14.2): ordered explicit levels, each referencing a
/// listed+hashed file by index into the SAME asset's files array.
#[derive(Debug, Clone, Deserialize)]
pub struct ManifestLod {
  pub levels: Vec<ManifestLodLevel>,
}

#[derive(Debug, Clone, Deserialize)]
pub struct ManifestLodLevel {
  pub level: u32,
  pub file_index: usize,
  pub scene_index: usize,
  pub triangles: u64,
  pub switch_distance_m: f32,
  #[serde(default)]
  pub hysteresis_m: f32,
}

/// Pack paths must be relative, traversal-free and non-empty-segmented.
/// Shared by validation and disk verification (verify_pack_files reads
/// from this predicate too, so a validated manifest can never point the
/// verifier outside the pack root).
pub fn path_escapes(path: &str) -> bool {
  path.starts_with('/')
    || path.contains(['\\', ':', '#'])
    || path.len() > 240
    || path.split('/').any(|segment| segment == "." || segment == ".." || segment.is_empty())
}

fn default_anchor() -> ManifestAnchor {
  ManifestAnchor { x: 0.5, y: 0.5, origin: default_origin() }
}

fn default_origin() -> String {
  "top_left".to_string()
}

#[derive(Debug, Clone)]
pub struct ManifestProblem {
  pub message: String,
}

impl GameAssetPackManifest {
  /// Parse + contract-check. `problems` returns every reason the pack is
  /// not importable; an empty vec means importable.
  pub fn parse_and_validate(json: &str) -> Result<Self, Vec<ManifestProblem>> {
    let mut problems = Vec::new();
    let manifest: GameAssetPackManifest = match serde_json::from_str(json) {
      Ok(manifest) => manifest,
      Err(error) => {
        return Err(vec![ManifestProblem {
          message: format!("manifest JSON parse error: {error}"),
        }]);
      },
    };

    let major = manifest.schema_version.split('.').next().and_then(|part| part.parse::<u64>().ok());
    match major {
      Some(major) if major == SUPPORTED_SCHEMA_MAJOR => {},
      Some(_major) => {
        return Err(vec![ManifestProblem {
          message: format!(
            "unsupported manifest schema_version {} (crate supports major {SUPPORTED_SCHEMA_MAJOR})",
            manifest.schema_version
          ),
        }]);
      },
      None => {
        return Err(vec![ManifestProblem {
          message: format!("malformed schema_version {}", manifest.schema_version),
        }]);
      },
    }

    if !manifest.engine_profiles.iter().any(|profile| profile.engine == "bevy") {
      problems.push(ManifestProblem { message: "no bevy engine_profile in the pack".to_string() });
    } else {
      // Plan 14.2: unsupported REQUIRED features must fail the import.
      // This crate's M2 feature set supports none, so any requirement
      // errors; later versions grow the supported set here.
      for profile in &manifest.engine_profiles {
        if profile.engine == "bevy" {
          if let Some(required) = profile.required_features.as_ref() {
            if !required.is_empty() {
              problems.push(ManifestProblem {
                message: format!(
                  "bevy profile requires unsupported features: {required:?} (this crate supports none yet)"
                ),
              });
            }
          }
        }
      }
    }
    if manifest.assets.is_empty() {
      problems.push(ManifestProblem { message: "manifest carries no assets".to_string() });
    }
    for asset in &manifest.assets {
      if let Some(image) = &asset.image {
        if !image.pixels_per_world_unit.is_finite() || image.pixels_per_world_unit <= 0.0 {
          problems
            .push(ManifestProblem { message: "pixels_per_world_unit must be positive".into() });
        }
        if let Some(atlas) = &image.atlas {
          if atlas.page_file_index >= asset.files.len()
            || atlas.rect.width == 0
            || atlas.rect.height == 0
            || atlas.uncropped_size.width == 0
            || atlas.uncropped_size.height == 0
            || atlas.uncropped_size.width > 8192
            || atlas.uncropped_size.height > 8192
          {
            problems
              .push(ManifestProblem { message: "atlas mapping or dimensions are invalid".into() });
          }
        }
      }
      if asset.stable_key.is_empty() {
        problems
          .push(ManifestProblem { message: format!("asset {} has no stable_key", asset.asset_id) });
      }
      if asset.files.is_empty() {
        problems
          .push(ManifestProblem { message: format!("asset {} lists no files", asset.stable_key) });
      }
      for file in &asset.files {
        if path_escapes(&file.path) {
          problems.push(ManifestProblem {
            message: format!(
              "asset {} file path escapes the pack: {}",
              asset.stable_key, file.path
            ),
          });
        }
        if file.sha256.len() != 64 || !file.sha256.chars().all(|c| c.is_ascii_hexdigit()) {
          problems.push(ManifestProblem {
            message: format!(
              "asset {} file {} has a malformed sha256",
              asset.stable_key, file.path
            ),
          });
        }
      }
      match asset.kind.as_str() {
        "icon_2d" | "sprite_2d" => {
          if asset.image.is_none() {
            problems.push(ManifestProblem {
              message: format!("2D asset {} has no image block", asset.stable_key),
            });
          }
        },
        "prop_3d" => {
          if asset.mesh.is_none() {
            problems.push(ManifestProblem {
              message: format!("prop_3d asset {} has no mesh block", asset.stable_key),
            });
          }
          // LOD contract (plan 14.2/13.5): enabled but incomplete or
          // inconsistent mapping is rejected at import, never degraded.
          if let Some(lod) = asset.mesh.as_ref().and_then(|mesh| mesh.lod.as_ref()) {
            if lod.levels.is_empty() {
              problems.push(ManifestProblem {
                message: format!("asset {} has an empty lod block", asset.stable_key),
              });
            }
            let mut previous_level: Option<u32> = None;
            let mut previous_switch: Option<f32> = None;
            for level in &lod.levels {
              if level.level < 1 {
                // Main is the implicit finest level (rank 0 in both
                // engines' selectors); explicit levels are 1-based.
                problems.push(ManifestProblem {
                  message: format!(
                    "asset {} lod level {} is invalid: explicit levels start at 1",
                    asset.stable_key, level.level
                  ),
                });
              }
              if level.file_index >= asset.files.len() {
                problems.push(ManifestProblem {
                  message: format!(
                    "asset {} lod level {} references file_index {} outside its files",
                    asset.stable_key, level.level, level.file_index
                  ),
                });
              }
              if let Some(previous) = previous_level {
                if level.level <= previous {
                  problems.push(ManifestProblem {
                    message: format!(
                      "asset {} lod levels must be ascending: {} after {}",
                      asset.stable_key, level.level, previous
                    ),
                  });
                }
              }
              if !(level.switch_distance_m.is_finite() && level.switch_distance_m > 0.0) {
                problems.push(ManifestProblem {
                  message: format!(
                    "asset {} lod level {} has a non-positive switch distance",
                    asset.stable_key, level.level
                  ),
                });
              }
              if let Some(previous) = previous_switch {
                if level.switch_distance_m <= previous {
                  problems.push(ManifestProblem {
                    message: format!(
                      "asset {} lod switch distances must increase: {} after {}",
                      asset.stable_key, level.switch_distance_m, previous
                    ),
                  });
                }
              }
              if !(level.hysteresis_m.is_finite() && level.hysteresis_m >= 0.0) {
                problems.push(ManifestProblem {
                  message: format!(
                    "asset {} lod level {} has a negative hysteresis",
                    asset.stable_key, level.level
                  ),
                });
              } else if level.hysteresis_m > level.switch_distance_m {
                // A band wider than its threshold can never be left.
                problems.push(ManifestProblem {
                  message: format!(
                    "asset {} lod level {} hysteresis {} exceeds its switch distance {}",
                    asset.stable_key, level.level, level.hysteresis_m, level.switch_distance_m
                  ),
                });
              }
              previous_level = Some(level.level);
              previous_switch = Some(level.switch_distance_m);
            }
          }
        },
        other => {
          problems.push(ManifestProblem { message: format!("unknown asset kind {other}") });
        },
      }
    }

    if problems.is_empty() {
      Ok(manifest)
    } else {
      Err(problems)
    }
  }

  /// Managed resource namespace derived from immutable project identity
  /// (plan 15.2: assets/game_assets/{project_namespace}/).
  pub fn project_namespace(&self) -> String {
    self.project_id.to_lowercase()
  }

  pub fn find_asset(&self, stable_key: &str) -> Option<&ManifestAsset> {
    self.assets.iter().find(|asset| asset.stable_key == stable_key)
  }
}

#[cfg(test)]
mod tests {
  use super::*;

  /// Minimal valid manifest JSON with an optional lod block on the
  /// single prop_3d asset (two files: main + one lod).
  fn manifest_json(lod_json: &str) -> String {
    format!(
      r#"{{
  "schema_version": "1.0",
  "pack_id": "pk1", "project_id": "proj1", "export_id": "ex1", "generated_at": "2026-10-23T00:00:00Z",
  "engine_profiles": [{{"id": "p1", "engine": "bevy", "engine_version": "0.20.0", "renderer_backend": "wgpu", "importer_version": "1", "coordinate_conversion": "y-up", "required_features": [], "validation_status": "verified"}}],
  "assets": [{{
    "asset_id": "a1", "stable_key": "crate", "version_id": "v1", "kind": "prop_3d", "spec_hash": "{}",
    "files": [
      {{"role": "main", "path": "models/crate.glb", "sha256": "{}", "byte_length": 10, "mime": "model/gltf-binary"}},
      {{"role": "lod", "path": "models/crate_lod1.glb", "sha256": "{}", "byte_length": 10, "mime": "model/gltf-binary"}}
    ],
    "mesh": {{
      "scene_index": 0, "unit": "meter", "up_axis": "+Y", "visual_forward": "+Z", "origin": "bottom_center",
      "measured_dimensions_m": {{"x": 1, "y": 1, "z": 1}}, "triangles": 12,
      "material_workflow": "gltf_metallic_roughness",
      "collision": {{"kind": "none", "unit": "meter"}}, {lod_json}
    }},
    "quality": {{"technical_check": {{"status": "passed", "validator_version": "t"}}, "human_review": {{"status": "passed"}}}}
  }}]
}}"#,
      "a".repeat(64),
      "b".repeat(64),
      "c".repeat(64),
    )
  }

  #[test]
  fn lod_accepts_a_valid_chain() {
    let lod = r#""lod": {"levels": [
      {"level": 1, "file_index": 1, "scene_index": 0, "triangles": 8, "switch_distance_m": 10.0, "hysteresis_m": 1.0}
    ]}"#;
    let manifest = GameAssetPackManifest::parse_and_validate(&manifest_json(lod)).expect("valid");
    let mesh = manifest.assets[0].mesh.as_ref().unwrap();
    let lod = mesh.lod.as_ref().expect("lod parsed");
    assert_eq!(lod.levels.len(), 1);
    assert_eq!(lod.levels[0].triangles, 8);
  }

  #[test]
  fn lod_rejects_out_of_range_file_index() {
    let lod = r#""lod": {"levels": [
      {"level": 1, "file_index": 5, "scene_index": 0, "triangles": 8, "switch_distance_m": 10.0, "hysteresis_m": 1.0}
    ]}"#;
    let problems = GameAssetPackManifest::parse_and_validate(&manifest_json(lod)).unwrap_err();
    assert!(problems.iter().any(|p| p.message.contains("file_index 5 outside")), "{problems:?}");
  }

  #[test]
  fn lod_rejects_descending_levels_or_distances() {
    let descending = r#""lod": {"levels": [
      {"level": 2, "file_index": 1, "scene_index": 0, "triangles": 4, "switch_distance_m": 25.0, "hysteresis_m": 0.0},
      {"level": 1, "file_index": 1, "scene_index": 0, "triangles": 8, "switch_distance_m": 10.0, "hysteresis_m": 0.0}
    ]}"#;
    let problems =
      GameAssetPackManifest::parse_and_validate(&manifest_json(descending)).unwrap_err();
    assert!(problems.iter().any(|p| p.message.contains("ascending")), "{problems:?}");

    let flat_distances = r#""lod": {"levels": [
      {"level": 1, "file_index": 1, "scene_index": 0, "triangles": 8, "switch_distance_m": 10.0, "hysteresis_m": 0.0},
      {"level": 2, "file_index": 1, "scene_index": 0, "triangles": 4, "switch_distance_m": 10.0, "hysteresis_m": 0.0}
    ]}"#;
    let problems =
      GameAssetPackManifest::parse_and_validate(&manifest_json(flat_distances)).unwrap_err();
    assert!(
      problems.iter().any(|p| p.message.contains("switch distances must increase")),
      "{problems:?}"
    );
  }

  #[test]
  fn lod_rejects_level_zero_and_oversized_hysteresis() {
    let level_zero = r#""lod": {"levels": [
      {"level": 0, "file_index": 1, "scene_index": 0, "triangles": 8, "switch_distance_m": 10.0, "hysteresis_m": 1.0}
    ]}"#;
    let problems =
      GameAssetPackManifest::parse_and_validate(&manifest_json(level_zero)).unwrap_err();
    assert!(problems.iter().any(|p| p.message.contains("start at 1")), "{problems:?}");

    let sticky = r#""lod": {"levels": [
      {"level": 1, "file_index": 1, "scene_index": 0, "triangles": 8, "switch_distance_m": 10.0, "hysteresis_m": 11.0}
    ]}"#;
    let problems = GameAssetPackManifest::parse_and_validate(&manifest_json(sticky)).unwrap_err();
    assert!(
      problems.iter().any(|p| p.message.contains("exceeds its switch distance")),
      "{problems:?}"
    );
  }

  #[test]
  fn lod_rejects_empty_block_and_bad_thresholds() {
    let empty = r#""lod": {"levels": []}"#;
    let problems = GameAssetPackManifest::parse_and_validate(&manifest_json(empty)).unwrap_err();
    assert!(problems.iter().any(|p| p.message.contains("empty lod block")), "{problems:?}");

    let zero_distance = r#""lod": {"levels": [
      {"level": 1, "file_index": 1, "scene_index": 0, "triangles": 8, "switch_distance_m": 0.0, "hysteresis_m": 0.0}
    ]}"#;
    let problems =
      GameAssetPackManifest::parse_and_validate(&manifest_json(zero_distance)).unwrap_err();
    assert!(
      problems.iter().any(|p| p.message.contains("non-positive switch distance")),
      "{problems:?}"
    );
  }
}

/// Verify every listed pack file's bytes against the manifest's sha256,
/// reading from an absolute pack root on disk. The consumer calls this
/// before/alongside catalog loading (the AssetServer itself does not
/// verify content). Returns one problem per mismatch/missing file; an
/// empty vec means the pack is byte-intact.
pub fn verify_pack_files(
  manifest: &GameAssetPackManifest,
  pack_root_abs: &str,
) -> Vec<ManifestProblem> {
  let mut problems = Vec::new();
  let mut seen = std::collections::HashSet::new();
  let mut total = 0u64;
  if manifest.assets.len() > 500 {
    return vec![ManifestProblem { message: "每份包最多接受 500 项资产。".into() }];
  }
  for asset in &manifest.assets {
    for file in &asset.files {
      if seen.insert(file.path.clone()) {
        total = total.saturating_add(file.byte_length);
        if total > 1024 * 1024 * 1024 {
          problems.push(ManifestProblem { message: "包数据超过 1 GiB。".into() });
          return problems;
        }
      }
      if let Err(problem) = verify_pack_file(pack_root_abs, file) {
        problems.push(ManifestProblem { message: format!("{}：{problem}", file.path) });
      }
    }
  }
  problems
}

fn verify_pack_file(root: &str, file: &ManifestFile) -> Result<(), String> {
  use std::io::Read;
  use sha2::{Digest, Sha256};

  if path_escapes(&file.path) || !file.path.starts_with("assets/") {
    return Err("资源路径不在包的 assets 目录。".into());
  }
  if file.byte_length == 0 || file.byte_length > 250 * 1024 * 1024 {
    return Err("资源文件为空或超过 250 MiB。".into());
  }
  let mut path = std::path::PathBuf::from(root);
  for part in file.path.split('/') {
    path.push(part);
    let metadata = std::fs::symlink_metadata(&path).map_err(|e| format!("资源无法读取：{e}"))?;
    if metadata.file_type().is_symlink() {
      return Err("资源路径包含符号链接。".into());
    }
  }
  let expected_extension = match file.mime.as_str() {
    "image/png" => "png",
    "model/gltf-binary" => "glb",
    "application/json" => "json",
    _ => return Err("只接受 PNG、GLB 和 JSON 资源数据。".into()),
  };
  if path.extension().and_then(|ext| ext.to_str()) != Some(expected_extension) {
    return Err("扩展名与资源类型不同。".into());
  }
  let metadata = std::fs::metadata(&path).map_err(|e| e.to_string())?;
  if !metadata.is_file() || metadata.len() != file.byte_length {
    return Err("文件类型或字节数与交付清单不同。".into());
  }
  crate::data_file::validate_data_file(&path, &file.mime)?;
  let mut reader = std::fs::File::open(path).map_err(|e| e.to_string())?;
  let mut digest = Sha256::new();
  let mut count = 0u64;
  let mut buffer = [0u8; 65536];
  loop {
    let length = reader.read(&mut buffer).map_err(|e| e.to_string())?;
    if length == 0 {
      break;
    }
    count += length as u64;
    if count > file.byte_length {
      return Err("校验过程中资源大小发生变化。".into());
    }
    digest.update(&buffer[..length]);
  }
  if count != file.byte_length || hex::encode(digest.finalize()) != file.sha256.to_lowercase() {
    return Err("文件内容与交付清单的 SHA-256 不同。".into());
  }
  Ok(())
}
