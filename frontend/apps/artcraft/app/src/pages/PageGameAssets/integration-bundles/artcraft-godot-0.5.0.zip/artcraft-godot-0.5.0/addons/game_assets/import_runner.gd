@tool
extends Node
## Shared import operation run inside Godot's normal editor main loop.
signal completed(exit_code: int)
const ImportLock := preload("res://addons/game_assets/import_lock.gd")
const Importer := preload("res://addons/game_assets/importer.gd")
const Builder := preload("res://addons/game_assets/resource_builder.gd")
const Report := preload("res://addons/game_assets/engine_report.gd")
const EditorResources := preload("res://addons/game_assets/editor_resources.gd")

func run(args: PackedStringArray) -> void:
	if args.has("--recover-lock"):
		var recovery := ImportLock.new()
		if not recovery.recover_abandoned(): push_error(recovery.problem); completed.emit(1); return
		args.erase("--recover-lock")
	if args.size() < 1 or args.size() > 3:
		push_error("用法：godot --headless --editor --path /path/to/project -- --game-assets-import /path/to/unpacked-pack [cancel|keep|copy|replace] [安装目录名] [--recover-lock]")
		completed.emit(2); return
	var filesystem := EditorInterface.get_resource_filesystem()
	if not await EditorResources.scan(filesystem, get_tree()):
		push_error("编辑器初始化扫描超时，尚未写入资产。"); completed.emit(1); return
	var importer := Importer.new()
	importer.before_mutation = EditorResources.guard_managed_changes
	var ok := importer.import_pack(args[0], args[1] if args.size() > 1 else "cancel", args[2] if args.size() > 2 else "")
	if not ok:
		var failure := importer.failure_report()
		if not String(failure.get("pack_id", "")).is_empty(): _save_result(failure, importer.managed_namespace)
		push_error("\n".join(importer.report)); completed.emit(1); return
	if importer.result.get("kept_current", false):
		completed.emit(0 if _save_result(importer.result, importer.managed_namespace) else 1); return
	if not await EditorResources.scan(filesystem, get_tree(), EditorResources.expected_data(importer.manifest_data, importer.managed_root)):
		importer.rollback(); _save_result(importer.failure_report(["资源扫描超时，已请求恢复原文件。"]), importer.managed_namespace); push_error("资源扫描超时。"); completed.emit(1); return
	if not importer.check_before_mutation():
		importer.rollback(); _save_result(importer.failure_report(), importer.managed_namespace); push_error("\n".join(importer.report)); completed.emit(1); return
	var builder := Builder.new()
	if not builder.build(importer.manifest_data, importer.managed_root, importer.managed_namespace, importer.plan.unchanged.filter(func(key: String) -> bool: return not importer.plan.conflicts.has(key))) or not importer.finish_import():
		importer.rollback(); _save_result(importer.failure_report(builder.problems), importer.managed_namespace); push_error("\n".join(importer.report)); completed.emit(1); return
	var reload_problems := EditorResources.reload_changed_open_scenes(importer.managed_root, String(importer.result.get("previous_files", "")))
	if not reload_problems.is_empty():
		push_error("资源已导入，但部分打开的场景尚未重载：" + "\n".join(reload_problems)); completed.emit(1); return
	if not _save_result(importer.result, importer.managed_namespace):
		push_error("无法保存导入报告。"); completed.emit(1); return
	print("ARTCRAFT_IMPORT_OK ", builder.preview_path)
	completed.emit(0)

func _save_result(value: Dictionary, for_namespace: String = "") -> bool:
	if String(value.get("pack_id", "")).is_empty():
		push_error("本次操作未取得有效的资源包身份，没有生成可上传的报告。")
		return false
	var report_path := "user://game_assets_reports/%s-import-%s-%s.json" % [String(value.pack_id).validate_filename(), Time.get_unix_time_from_system(), Crypto.new().generate_random_bytes(4).hex_encode()]
	if not Report.save(value, report_path): return false
	var settings := EditorInterface.get_editor_settings()
	settings.set_project_metadata("game_assets", "last_report", report_path)
	if not for_namespace.is_empty():
		settings.set_project_metadata("game_assets", "report_" + for_namespace, report_path)
		settings.set_project_metadata("game_assets", "report_" + for_namespace + "_" + String(value.pack_id), report_path)
	print("ARTCRAFT_IMPORT_REPORT ", ProjectSettings.globalize_path(report_path))
	return true
