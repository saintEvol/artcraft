@tool
class_name GameAssetPackImporter
extends RefCounted
## Only verified data enters the managed tree. Previous contents remain recoverable.

signal progress(message: String)

const Manifest := preload("res://addons/game_assets/manifest.gd")
const Journal := preload("res://addons/game_assets/journal.gd")
const Transaction := preload("res://addons/game_assets/file_transaction.gd")
const EditorPresence := preload("res://addons/game_assets/editor_presence.gd")
const ImportLock := preload("res://addons/game_assets/import_lock.gd")
const Report := preload("res://addons/game_assets/engine_report.gd")
const InstallGraph := preload("res://addons/game_assets/install_graph.gd")
const Animation2D := preload("res://addons/game_assets/animation_2d_resources.gd")

var report: PackedStringArray = []
var result: Dictionary = {}
var plan: Dictionary = {}
var manifest_data: Dictionary = {}
var managed_root := ""
var managed_namespace := ""
var transaction
var before_mutation: Callable = Callable()
var _lock

func preflight(pack_dir: String, target_namespace: String = "") -> bool:
	if not _claim_lock(): return false
	var ok := _preflight_locked(pack_dir, target_namespace)
	_lock.release()
	return ok

func _preflight_locked(pack_dir: String, target_namespace: String) -> bool:
	report = PackedStringArray()
	result = {}; manifest_data = {}; plan = {}; managed_root = ""; managed_namespace = ""; transaction = null
	var manifest := Manifest.new()
	var valid := manifest.load_from_file(pack_dir.path_join("manifest.json"))
	manifest_data = manifest.data.duplicate(true)
	if not manifest_data.is_empty(): result = Report.create(manifest_data, "import", "failed", [])
	if not valid:
		report.append_array(manifest.problems); return false
	managed_namespace = manifest.project_namespace()
	var custom_target := not target_namespace.is_empty() and target_namespace != managed_namespace
	if custom_target:
		var pattern := RegEx.new(); pattern.compile("^[a-z0-9][a-z0-9_-]{0,127}$")
		if pattern.search(target_namespace) == null:
			report.append("所选安装位置不合法，未改动工程。"); return false
		managed_namespace = target_namespace
	managed_root = "res://game_assets/" + managed_namespace
	if not _safe_components("res://", "game_assets/" + managed_namespace):
		report.append("受管理目录位于符号链接下，导入已停止。"); return false
	# A crash can leave the old tree in backup with no root at all. Restore the
	# selected installation before trying to read its project identity.
	var recovery := Transaction.new()
	if FileAccess.file_exists(managed_root + ".pending.json") and not check_before_mutation(): return false
	if not recovery.recover(managed_root):
		report.append_array(recovery.problems); return false
	if custom_target:
		var installed := FileAccess.open(managed_root.path_join("manifest.json"), FileAccess.READ)
		if installed == null or installed.get_length() > 4 * 1024 * 1024:
			report.append("所选安装位置缺少有效清单。"); return false
		var prior: Variant = JSON.parse_string(installed.get_as_text())
		if not (prior is Dictionary) or prior.get("project_id") != manifest_data.get("project_id"):
			report.append("所选安装位置属于另一个项目，未覆盖它的资产。"); return false
	var journal := Journal.new()
	if FileAccess.file_exists(Journal.journal_path(managed_namespace)) and not journal.load_from(managed_namespace):
		report.append("已有导入记录无法读取，当前文件已保留，请先恢复有效记录。")
		return false
	if FileAccess.file_exists(managed_root.path_join("manifest.json")) and not FileAccess.file_exists(Journal.journal_path(managed_namespace)):
		report.append("已安装目录缺少导入记录，无法安全更新；请先恢复记录或重新完整导入。")
		return false
	for asset in manifest.assets:
		for asset_id in journal.entries:
			var old: Dictionary = journal.entries[asset_id]
			# 2.0 kinds share stable keys across kind directories; within one
			# kind the asset/stable-key pairing must stay stable.
			var same_kind := String(old.get("kind", "")) == String(asset.kind)
			if (asset_id == asset.asset_id and old.stable_key != asset.stable_key) or (asset_id != asset.asset_id and same_kind and old.stable_key == asset.stable_key):
				report.append("资产身份与已安装的稳定路径不一致，未替换任何资产。"); return false
	plan = journal.plan_update(manifest.assets, managed_root)
	var known := journal.known_paths()
	for asset in manifest.assets:
		for entry in asset.files:
			var relative := String(entry.path)
			if not _safe_components(pack_dir, relative) or not _safe_components(managed_root, relative):
				report.append("资源路径含符号链接或无法安全读取：" + relative)
				return false
			var source := pack_dir.path_join(relative)
			var file := FileAccess.open(source, FileAccess.READ)
			if file == null or file.get_length() != int(entry.byte_length) or FileAccess.get_sha256(source) != String(entry.sha256).to_lower():
				report.append("文件缺失或内容校验不匹配：" + relative)
				return false
			if not _valid_data_file(source, String(entry.mime)):
				return false
			if String(entry.role) == "frames":
				var frame_problems := PackedStringArray()
				if Animation2D.parse_frames(FileAccess.get_file_as_string(source), frame_problems).is_empty():
					report.append_array(frame_problems)
					return false
			if not known.has(relative) and FileAccess.file_exists(managed_root.path_join(relative)):
				if not plan.conflicts.has(asset.stable_key):
					plan.conflicts.append(asset.stable_key)
		var scene_path := Manifest.scene_relpath(asset)
		if not _safe_components(managed_root, scene_path):
			report.append("资产场景目录含符号链接，未覆盖工程文件。")
			return false
		if not known.has(scene_path) and FileAccess.file_exists(managed_root.path_join(scene_path)) and not plan.conflicts.has(asset.stable_key):
			plan.conflicts.append(asset.stable_key)
	if not _safe_components(managed_root, "preview.tscn"):
		report.append("资产预览路径含符号链接，未覆盖工程文件。")
		return false
	if not known.has("preview.tscn") and FileAccess.file_exists(managed_root.path_join("preview.tscn")):
		plan.conflicts.append("整组预览（已有本地文件）")
	# §12.1: verify the FINAL installation graph (retained + incoming)
	# before anything is staged; a failed closure leaves all files, the
	# journal and derived resources untouched.
	var graph := InstallGraph.new()
	if not graph.build(journal.entries, manifest.assets, managed_root, pack_dir).ok:
		report.append_array(graph.problems)
		return false
	result = Report.create(manifest_data, "import", "conflicts" if not plan.conflicts.is_empty() else "loaded", [])
	return true

## decision: cancel | keep | replace | copy. Replace always retains a full backup.
func import_pack(pack_dir: String, decision: String = "cancel", target_namespace: String = "") -> bool:
	if not _claim_lock(): return false
	var ok := _import_locked(pack_dir, decision, target_namespace)
	if not ok: rollback()
	elif result.get("kept_current", false): _lock.release()
	return ok

func _import_locked(pack_dir: String, decision: String, target_namespace: String) -> bool:
	if not _preflight_locked(pack_dir, target_namespace):
		return false
	if not plan.conflicts.is_empty() and decision == "cancel":
		report.append("发现本地改动：%s。请选择保留、另存副本或备份后替换。" % ", ".join(plan.conflicts))
		return false
	if decision not in ["cancel", "keep", "replace", "copy"]:
		report.append("无法识别的冲突处理方式。")
		return false
	if decision == "copy":
		managed_namespace += "_copy_" + Crypto.new().generate_random_bytes(4).hex_encode()
		managed_root = "res://game_assets/" + managed_namespace
	if decision == "keep":
		var preserved: Array = []
		var current := Journal.new(); current.load_from(managed_namespace)
		for asset in manifest_data.assets:
			var installed: Dictionary = current.entries.get(String(asset.asset_id), {})
			preserved.append({"asset_id": asset.asset_id, "version_id": installed.get("version_id", asset.version_id), "status": "missing" if installed.is_empty() else "kept_local"})
		result = Report.create(manifest_data, "update", "partial", preserved, ["已保留工程当前全部版本，没有应用本次更新。"])
		result["kept_current"] = true
		return true
	var journal := Journal.new()
	if FileAccess.file_exists(Journal.journal_path(managed_namespace)):
		journal.load_from(managed_namespace)
	# The final namespace (a copy target has no retained state): re-check
	# the graph so a clip whose rig is only retained is never copied out
	# without it.
	var graph := InstallGraph.new()
	if not graph.build(journal.entries, manifest_data.assets, managed_root, pack_dir).ok:
		report.append_array(graph.problems)
		return false
	if not check_before_mutation(): return false
	transaction = Transaction.new()
	if not transaction.prepare(managed_root):
		report.append_array(transaction.problems)
		return false
	var had_existing_assets := not journal.entries.is_empty()
	var assets: Array = []
	var outcomes: Array = []
	for asset in manifest_data.assets:
		for entry in asset.files:
			var destination: String = transaction.stage.path_join(String(entry.path))
			if FileAccess.file_exists(destination) and FileAccess.get_sha256(destination) == String(entry.sha256).to_lower(): continue
			if DirAccess.make_dir_recursive_absolute(destination.get_base_dir()) != OK or DirAccess.copy_absolute(pack_dir.path_join(String(entry.path)), destination) != OK:
				report.append("无法准备文件；当前资源未替换：" + String(entry.path))
				return false
			if FileAccess.get_sha256(destination) != String(entry.sha256).to_lower():
				report.append("准备后的文件校验失败，未提交。")
				return false
		assets.append(asset)
		journal.record(asset)
		outcomes.append({"asset_id": asset.asset_id, "version_id": asset.version_id, "status": "imported"})
	manifest_data["assets"] = assets
	if not Report.save(manifest_data, transaction.stage.path_join("manifest.json")) or not Report.save(journal.document(), transaction.stage.path_join("import_journal.json")):
		report.append("无法保存清单或导入记录，当前资源未替换。")
		return false
	if not check_before_mutation(): return false
	if not transaction.commit_files():
		report.append_array(transaction.problems)
		return false
	result = Report.create(manifest_data, "update" if had_existing_assets else "import", "loaded", outcomes)
	result["managed_root"] = managed_root
	result["previous_files"] = transaction.backup
	report.append("文件已核对并写入，下一步完成 Godot 导入与资产场景生成。")
	return true

func finish_import() -> bool:
	if transaction == null or not transaction.finish():
		if transaction != null:
			report.append_array(transaction.problems)
		return false
	if result.status != "partial":
		result.status = "succeeded"
	report.append("已完成引擎资源导入，可打开资产预览。")
	_lock.release()
	return true

func rollback() -> bool:
	if transaction != null:
		var restored: bool = transaction.recover(managed_root)
		if not restored: report.append_array(transaction.problems)
		if _lock != null: _lock.release()
		return restored
	if _lock != null: _lock.release()
	return true

func failure_report(extra: PackedStringArray = []) -> Dictionary:
	report.append_array(extra)
	var status := "conflicts" if result.get("status") == "conflicts" and transaction == null else "failed"
	result = Report.create(manifest_data, String(result.get("operation", "import")), status, [], Array(report))
	return result

func _safe_components(base: String, relative: String) -> bool:
	var current := ProjectSettings.globalize_path(base)
	for part in relative.split("/"):
		var directory := DirAccess.open(current)
		if directory == null:
			return true # Remaining destination directories do not exist yet.
		if directory.is_link(part):
			return false
		current = current.path_join(part)
	return true

func _valid_data_file(path: String, mime: String) -> bool:
	var file := FileAccess.open(path, FileAccess.READ)
	if file == null: return false
	if mime == "image/png":
		if file.get_buffer(8) != PackedByteArray([137,80,78,71,13,10,26,10]):
			report.append("PNG 文件头无效：" + path); return false
		file.big_endian = true
		if file.get_32() != 13 or file.get_buffer(4).get_string_from_ascii() != "IHDR":
			report.append("PNG 缺少尺寸头。"); return false
		var width := file.get_32(); var height := file.get_32()
		if width < 1 or height < 1 or width > 8192 or height > 8192 or width * height > 36000000:
			report.append("PNG 超出可用图像尺寸预算。"); return false
	elif mime == "model/gltf-binary":
		file.big_endian = false
		if file.get_buffer(4).get_string_from_ascii() != "glTF" or file.get_32() != 2 or file.get_32() != file.get_length():
			report.append("GLB 头或版本无效。"); return false
		var size := file.get_32()
		if size > 8 * 1024 * 1024 or size + 20 > file.get_length() or file.get_32() != 0x4e4f534a:
			report.append("GLB 的 JSON 区块无效或过大。"); return false
		var json: Variant = JSON.parse_string(file.get_buffer(size).get_string_from_utf8())
		if not (json is Dictionary): report.append("GLB JSON 无法读取。"); return false
		if json.get("scene", 0) != 0:
			report.append("此组件使用 GLB 场景 0，文件默认场景不同；请重新导出场景 0。")
			return false
		for field in ["buffers", "images"]:
			if not (json.get(field, []) is Array): report.append("GLB 索引类型无效。"); return false
			for entry in json.get(field, []):
				if not (entry is Dictionary): report.append("GLB 条目无效。"); return false
				if entry.has("uri"):
					var uri := String(entry.uri)
					var allowed := uri.begins_with("data:application/octet-stream;base64,") if field == "buffers" else uri.begins_with("data:image/png;base64,") or uri.begins_with("data:image/jpeg;base64,")
					if not allowed: report.append("GLB 不是自包含资源，拒绝外部文件或网络引用。"); return false
	return true

func _claim_lock() -> bool:
	var owners := EditorPresence.other_editors()
	if not owners.is_empty(): report = owners; return false
	if _lock != null and _lock.is_held():
		report = PackedStringArray(["当前导入尚未结束，请先完成或回滚，再重新核对。"]); return false
	_lock = ImportLock.new()
	if not _lock.acquire():
		report = PackedStringArray([_lock.problem]); return false
	return true

func check_before_mutation() -> bool:
	var owners := EditorPresence.other_editors()
	if not owners.is_empty(): report.append_array(owners); result["status"] = "conflicts"; return false
	if not before_mutation.is_valid(): return true
	var issues: PackedStringArray = before_mutation.call(managed_root)
	if issues.is_empty(): return true
	report.append_array(issues)
	result["status"] = "conflicts"
	return false
