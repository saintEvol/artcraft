//! Each asset owns its sampling/atlas variant; shared source handles stay unchanged.
use bevy::prelude::*;
use bevy::asset::LoadState;
use bevy::image::ImageSampler;
use bevy::render::render_resource::TextureFormat;
use crate::catalog::GameAssetCatalog;
use crate::manifest::ManifestAtlas;

pub fn prepare_sprite_images(
  mut catalog: ResMut<GameAssetCatalog>,
  mut images: ResMut<Assets<Image>>,
  server: Res<AssetServer>,
) {
  let mut problems = Vec::new();
  for (id, entry) in &mut catalog.entries {
    if entry.render_image.is_some() {
      continue;
    }
    let Some(source) = &entry.image else {
      continue;
    };
    if !matches!(server.load_state(source), LoadState::Loaded) {
      continue;
    }
    let Some(image) = images.get(source) else {
      continue;
    };
    match image_variant(image, entry.atlas.as_ref(), &entry.sampling) {
      Ok(image) => entry.render_image = Some(images.add(image)),
      Err(message) => problems.push((id.clone(), message)),
    }
  }
  for (id, message) in problems {
    catalog.problems.insert(id, message);
  }
}

fn image_variant(
  source: &Image,
  atlas: Option<&ManifestAtlas>,
  sampling: &str,
) -> Result<Image, String> {
  let mut image = source.clone();
  if let Some(atlas) = atlas {
    if !matches!(
      source.texture_descriptor.format,
      TextureFormat::Rgba8Unorm | TextureFormat::Rgba8UnormSrgb
    ) {
      return Err("atlas requires decoded RGBA8 pixels".into());
    }
    let data = source.data.as_ref().ok_or("atlas source has no CPU pixels")?;
    let width = source.width();
    let height = source.height();
    let r = &atlas.rect;
    if r.x.checked_add(r.width).is_none_or(|x| x > width)
      || r.y.checked_add(r.height).is_none_or(|y| y > height)
      || atlas.crop_offset.x.checked_add(r.width).is_none_or(|x| x > atlas.uncropped_size.width)
      || atlas.crop_offset.y.checked_add(r.height).is_none_or(|y| y > atlas.uncropped_size.height)
    {
      return Err("atlas rect or crop offset exceeds its image".into());
    }
    let count = u64::from(atlas.uncropped_size.width) * u64::from(atlas.uncropped_size.height) * 4;
    if count > 256 * 1024 * 1024 {
      return Err("atlas sprite exceeds the memory limit".into());
    }
    let mut pixels = vec![0; count as usize];
    for row in 0..r.height {
      let start = ((r.y + row) as usize * width as usize + r.x as usize) * 4;
      let size = r.width as usize * 4;
      let target = ((atlas.crop_offset.y + row) as usize * atlas.uncropped_size.width as usize
        + atlas.crop_offset.x as usize)
        * 4;
      let slice = data.get(start..start + size).ok_or("atlas source pixels are incomplete")?;
      pixels[target..target + size].copy_from_slice(slice);
    }
    image.texture_descriptor.size.width = atlas.uncropped_size.width;
    image.texture_descriptor.size.height = atlas.uncropped_size.height;
    image.data = Some(pixels);
  }
  image.sampler =
    if sampling == "nearest" { ImageSampler::nearest() } else { ImageSampler::linear() };
  Ok(image)
}

/// A source reload invalidates variants even when a producer reuses its version id.
pub fn invalidate_source_images(
  mut events: MessageReader<bevy::asset::AssetEvent<Image>>,
  mut catalog: ResMut<GameAssetCatalog>,
) {
  for event in events.read() {
    if let bevy::asset::AssetEvent::Modified { id } = event {
      for entry in catalog.entries.values_mut() {
        if entry.image.as_ref().is_some_and(|image| image.id() == *id) {
          entry.render_image = None;
        }
      }
    }
  }
}

#[cfg(test)]
mod tests {
  use super::*;
  use bevy::asset::RenderAssetUsages;
  use bevy::render::render_resource::{Extent3d, TextureDimension};
  use crate::manifest::{AtlasRect, AtlasOffset, AtlasSize, ManifestAnchor};

  #[test]
  fn atlas_restores_uncropped_canvas_and_each_sampling_policy_has_its_own_image() {
    let mut source = Image::new_fill(
      Extent3d { width: 3, height: 2, depth_or_array_layers: 1 },
      TextureDimension::D2,
      &[1, 2, 3, 255],
      TextureFormat::Rgba8UnormSrgb,
      RenderAssetUsages::default(),
    );
    source.data.as_mut().unwrap()[4..8].copy_from_slice(&[5, 6, 7, 128]);
    let atlas = ManifestAtlas {
      page_file_index: 0,
      rect: AtlasRect { x: 1, y: 0, width: 1, height: 1 },
      uncropped_size: AtlasSize { width: 3, height: 3 },
      crop_offset: AtlasOffset { x: 1, y: 2 },
      anchor: ManifestAnchor { x: 0.5, y: 1., origin: "top_left".into() },
    };
    let nearest = image_variant(&source, Some(&atlas), "nearest").unwrap();
    let linear = image_variant(&source, Some(&atlas), "linear").unwrap();
    assert_eq!((nearest.width(), nearest.height()), (3, 3));
    let data = nearest.data.as_ref().unwrap();
    assert_eq!(&data[28..32], &[5, 6, 7, 128]);
    assert!(data[..28].iter().all(|b| *b == 0));
    assert!(data[32..].iter().all(|b| *b == 0));
    assert!(matches!(source.sampler, ImageSampler::Default));
    let (ImageSampler::Descriptor(a), ImageSampler::Descriptor(b)) =
      (nearest.sampler, linear.sampler)
    else {
      panic!("per-asset sampler was not explicit")
    };
    assert_ne!(a.mag_filter, b.mag_filter);
  }
}
