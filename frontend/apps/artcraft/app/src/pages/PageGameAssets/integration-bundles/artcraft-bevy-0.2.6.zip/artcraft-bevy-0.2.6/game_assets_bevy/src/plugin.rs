//! Plugin wiring (plan 15.2): registers resources and the state-refresh
//! system. Deliberately minimal — no global renderer/plugin defaults are
//! touched (per-asset sampling instead of ImagePlugin changes).

use bevy::prelude::*;

use crate::catalog::{GameAssetCatalog, GameAssetLoadStateTracker};

pub struct GameAssetPackPlugin;

impl Plugin for GameAssetPackPlugin {
  fn build(&self, app: &mut App) {
    app
      .init_resource::<GameAssetCatalog>()
      .init_resource::<GameAssetLoadStateTracker>()
      .add_systems(
        PreUpdate,
        (
          crate::sprite_images::invalidate_source_images,
          crate::sprite_images::prepare_sprite_images,
          refresh_load_states,
          crate::instances::sync_instances,
        )
          .chain(),
      );
  }
}

fn refresh_load_states(
  mut tracker: ResMut<GameAssetLoadStateTracker>,
  catalog: Res<GameAssetCatalog>,
  asset_server: Res<AssetServer>,
) {
  tracker.update(&catalog, &asset_server);
}
