@tool
extends RefCounted
## Trusted integration code creates reusable scenes; resource packs supply only data.

const InstalledCatalog := preload("res://addons/game_assets/installed_catalog.gd")
const Report := preload("res://addons/game_assets/engine_report.gd")
const Collision := preload("res://addons/game_assets/collision.gd")
const Preview := preload("res://addons/game_assets/preview.gd")
const Prop := preload("res://addons/game_assets/prop.gd")
const Journal := preload("res://addons/game_assets/journal.gd")

var problems: PackedStringArray = []
var preview_path := ""

func build(manifest: Dictionary, root: String, managed_namespace: String, unchanged: Array = []) -> bool:
	var journal := Journal.new()
	if not journal.load_from(managed_namespace):
		problems.append("导入记录缺失，不能创建资产场景。")
		return false
	if DirAccess.make_dir_recursive_absolute(root.path_join("scenes")) != OK:
		return false
	for asset in manifest.assets:
		var path: String = root.path_join("scenes/" + String(asset.stable_key) + ".tscn")
		var packed: PackedScene
		if String(asset.stable_key) in unchanged and FileAccess.file_exists(path):
			packed = ResourceLoader.load(path, "PackedScene", ResourceLoader.CACHE_MODE_REPLACE) as PackedScene
			if packed == null:
				problems.append("无法读取原有资产场景：" + path); return false
		else:
			var previous: Node
			if FileAccess.file_exists(path):
				var prior := ResourceLoader.load(path, "PackedScene", ResourceLoader.CACHE_MODE_IGNORE) as PackedScene
				if prior != null: previous = prior.instantiate()
			var node: Node
			if asset.kind in ["icon_2d", "sprite_2d"]:
				if previous != null and not previous is Sprite2D: previous.free(); previous = null
				node = _sprite(asset, root, previous)
			else:
				if previous != null and not previous is Node3D: previous.free(); previous = null
				node = _prop(asset, root, previous)
			if node == null:
				if is_instance_valid(previous): previous.free()
				return false
			node.name = String(asset.stable_key)
			node.set_meta("artcraft_asset_id", asset.asset_id)
			node.set_meta("artcraft_version_id", asset.version_id)
			packed = PackedScene.new()
			var error := packed.pack(node)
			node.free()
			if error != OK or not _save_scene(packed, path):
				return false
		var entry: Dictionary = journal.entries[String(asset.asset_id)]
		var files: Array = entry.files.filter(func(file: Dictionary) -> bool: return file.get("role") != "generated_scene")
		files.append({"role": "generated_scene", "path": "scenes/" + String(asset.stable_key) + ".tscn", "sha256": FileAccess.get_sha256(path)})
		entry.files = files
	var catalog := InstalledCatalog.from_journal(manifest, journal.entries)
	preview_path = root.path_join("preview.tscn")
	var catalog_path := root.path_join("catalog.json")
	var known_preview := false
	for generated in journal.generated_files:
		if generated.path == "preview.tscn" and FileAccess.file_exists(preview_path) and generated.sha256 == FileAccess.get_sha256(preview_path): known_preview = true
	if unchanged.size() == manifest.assets.size() and known_preview and FileAccess.file_exists(catalog_path) and JSON.parse_string(FileAccess.get_file_as_string(catalog_path)) == catalog:
		return journal.save(managed_namespace)
	var scenes: Array[PackedScene] = []
	for descriptor in catalog.assets:
		var path: String = root.path_join("scenes/" + String(descriptor.stable_key) + ".tscn")
		var scene := ResourceLoader.load(path, "PackedScene", ResourceLoader.CACHE_MODE_REPLACE) as PackedScene if FileAccess.file_exists(path) else null
		scenes.append(scene)
	if not Report.save(catalog, catalog_path):
		problems.append("无法保存已安装资产目录，导入尚未完成。"); return false
	preview_path = root.path_join("preview.tscn")
	var preview := Node.new()
	preview.name = "GameAssetsPreview"
	preview.set_script(Preview)
	preview.set("asset_scenes", scenes)
	preview.set("manifest", manifest)
	preview.set("catalog_assets", catalog.assets)
	var packed := PackedScene.new()
	var error := packed.pack(preview)
	preview.free()
	if error != OK or not _save_scene(packed, preview_path):
		return false
	journal.generated_files = [{"path": "preview.tscn", "sha256": FileAccess.get_sha256(preview_path)}, {"path": "catalog.json", "sha256": FileAccess.get_sha256(catalog_path)}]
	if not journal.save(managed_namespace):
		problems.append("无法保存资源映射，导入尚未完成。")
		return false
	return true

func _sprite(asset: Dictionary, root: String, previous: Sprite2D = null) -> Sprite2D:
	var image: Dictionary = asset.image
	var atlas: Dictionary = image.get("atlas", {})
	var entry: Dictionary = {}
	if not atlas.is_empty():
		entry = asset.files[int(atlas.page_file_index)]
	else:
		for file in asset.files:
			if file.role == "main":
				entry = file
	if entry.is_empty():
		problems.append("图像缺少主文件：" + String(asset.stable_key))
		return null
	var texture := ResourceLoader.load(root.path_join(String(entry.path)), "Texture2D", ResourceLoader.CACHE_MODE_REPLACE) as Texture2D
	if texture == null:
		problems.append("Godot 未成功导入图像：" + String(entry.path))
		return null
	var width: float = image.width
	var height: float = image.height
	var anchor: Dictionary = image.get("anchor", {"x": 0.5, "y": 0.5})
	if not atlas.is_empty():
		var cropped := AtlasTexture.new()
		cropped.atlas = texture
		var rect: Dictionary = atlas.rect
		cropped.region = Rect2(rect.x, rect.y, rect.width, rect.height)
		width = atlas.uncropped_size.width; height = atlas.uncropped_size.height
		cropped.margin = Rect2(atlas.crop_offset.x, atlas.crop_offset.y, width - rect.width, height - rect.height)
		cropped.filter_clip = true
		texture = cropped
		anchor = atlas.anchor
	var sprite := _clean_root(previous, Sprite2D.new()) as Sprite2D
	sprite.texture = texture
	sprite.offset = Vector2((0.5 - float(anchor.x)) * width, (0.5 - float(anchor.y)) * height)
	sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST if image.sampling == "nearest" else CanvasItem.TEXTURE_FILTER_LINEAR
	sprite.set_meta("pixels_per_world_unit", image.get("pixels_per_world_unit", 100.0))
	return sprite

func _prop(asset: Dictionary, root: String, previous: Node3D = null) -> Node3D:
	var node := _clean_root(previous, Node3D.new()) as Node3D
	node.set_script(Prop)
	node.set("lod_description", asset.mesh.get("lod", {}))
	var levels: Array = [{"level": -1, "file_index": -1}]
	levels.append_array(asset.mesh.get("lod", {}).get("levels", []))
	for level in levels:
		var file: Dictionary = {}
		if int(level.level) == -1:
			for candidate in asset.files:
				if candidate.role == "main":
					file = candidate
		else:
			file = asset.files[int(level.file_index)]
		var scene := ResourceLoader.load(root.path_join(String(file.get("path", ""))), "PackedScene", ResourceLoader.CACHE_MODE_REPLACE) as PackedScene
		if scene == null:
			problems.append("模型或 LOD 未成功导入：" + String(asset.stable_key))
			node.free(); return null
		var instance := scene.instantiate()
		if not _has_mesh(instance):
			problems.append("模型或 LOD 没有可显示的网格：" + String(asset.get("display_name", asset.stable_key)))
			instance.free(); node.free(); return null
		instance.name = "Model" if int(level.level) == -1 else "LOD%d" % int(level.level)
		node.add_child(instance); instance.owner = node
	var nodes: Variant = Collision.build(asset.mesh, problems)
	if nodes == null:
		node.free(); return null
	for collision in nodes:
		node.add_child(collision)
		_set_owner(collision, node)
	return node

func _has_mesh(node: Node) -> bool:
	if node is MeshInstance3D and node.mesh != null and node.mesh.get_surface_count() > 0:
		return true
	for child in node.get_children():
		if _has_mesh(child): return true
	return false

func _save_scene(scene: PackedScene, path: String) -> bool:
	var previous_uid := ResourceSaver.get_resource_id_for_path(path, false)
	if ResourceSaver.save(scene, path) != OK:
		problems.append("无法保存资产场景：" + path); return false
	if previous_uid != ResourceUID.INVALID_ID and ResourceSaver.set_uid(path, previous_uid) != OK:
		problems.append("无法保留已有资源 UID：" + path); return false
	return true

func _set_owner(node: Node, root: Node) -> void:
	node.owner = root
	for child in node.get_children():
		_set_owner(child, root)

## Reuse only the node identity used by scene references. An explicit replacement
## must not promote old managed-file edits into the next generated baseline.
func _clean_root(previous: Node, defaults: Node) -> Node:
	if previous == null: return defaults
	for signal_info in previous.get_signal_list():
		for connection in previous.get_signal_connection_list(StringName(signal_info.name)):
			if int(connection.flags) & Object.CONNECT_PERSIST:
				previous.disconnect(StringName(signal_info.name), connection.callable)
	previous.set_script(null)
	for child in previous.get_children(true): previous.remove_child(child); child.free()
	for key in previous.get_meta_list(): previous.remove_meta(key)
	for group in previous.get_groups(): previous.remove_from_group(group)
	for property in defaults.get_property_list():
		if (int(property.usage) & PROPERTY_USAGE_STORAGE) != 0 and (int(property.usage) & PROPERTY_USAGE_READ_ONLY) == 0 and String(property.name) not in ["script", "name", "owner", "scene_file_path"]:
			previous.set(StringName(property.name), defaults.get(StringName(property.name)))
	defaults.free()
	return previous
