extends Node3D

const Chain := preload("res://addons/game_assets/lod.gd")
@export var lod_description: Dictionary = {}
var _chain
var _level := -1

func _ready() -> void:
	_chain = Chain.from_manifest(lod_description)
	_show_level(-1)
	set_process(not lod_description.is_empty())

func _process(_delta: float) -> void:
	var camera := get_viewport().get_camera_3d()
	if camera != null:
		var selected: int = _chain.select_level(global_position.distance_to(camera.global_position), _level)
		if selected != _level:
			_show_level(selected)

func _show_level(level: int) -> void:
	_level = level
	for child in get_children():
		if child is Node3D and (child.name == "Model" or String(child.name).begins_with("LOD")):
			child.visible = String(child.name) == ("Model" if level == -1 else "LOD%d" % level)
