//! Bevy integration for Artcraft game-asset packs (plan section 15.2).
//!
//! Responsibilities:
//! - load and validate a pack manifest (schema major gate, engine
//!   profile presence, required-features gate),
//! - verify pack file bytes against the manifest's sha256 on disk
//!   ([`verify_pack_files`]),
//! - maintain a [`GameAssetCatalog`] mapping stable [`GameAssetId`]s to
//!   versions, handles and specs,
//! - track per-asset [`GameAssetLoadState`] through file load AND
//!   recursive dependencies AND scene instantiation readiness,
//! - spawn sprites/props honoring the manifest's anchor and mesh
//!   semantics, without touching global renderer defaults.
//!
//! The crate consumes LOCAL packs only: no Artcraft login, no vendor
//! credentials (plan section 6.3).

use bevy::app::App;
pub use bevy::asset::LoadState;

pub mod animation_2d;
pub mod animation_binding;
pub mod catalog;
mod data_file;
pub mod install;
pub mod instances;
pub use instances::GameAssetInstance;
pub mod json_asset;
pub mod sprite_images;
pub mod lod;
pub mod manifest;
pub mod plugin;
pub mod spawn;
pub mod state;

pub use animation_2d::{atlas_layout, frame_at, GameAssetAnimation2d, FrameTable};
pub use animation_binding::{
  bind_character_rigs, find_entity_by_path, sync_animation_3d_playback, GameAssetAnimation3d,
  GameAssetRigBinding,
};
pub use catalog::{
  GameAssetAnimation2dEntry, GameAssetAnimation3dEntry, GameAssetCatalog, GameAssetEntry,
  GameAssetLoadStateTracker,
};
pub use json_asset::{JsonAsset, JsonAssetLoader};
pub use lod::{GameAssetLodChain, GameAssetLodLevel};
pub use manifest::{GameAssetPackManifest, ManifestAsset, ManifestFile};
pub use plugin::GameAssetPackPlugin;
pub use manifest::verify_pack_files;
pub use spawn::{
  platform_anchor_to_bevy, spawn_game_animation_2d, spawn_game_prop, spawn_game_prop_at_lod_level,
  spawn_game_sprite, GameAssetCollisionDescriptor,
};
pub use state::GameAssetLoadState;

/// A pack-namespace + stable-key identity. Stable across content updates
/// (the plan's "资源更新不丢引用" guarantee anchors on this, not paths).
#[derive(Clone, PartialEq, Eq, Hash, Debug)]
pub struct GameAssetId {
  pub namespace: String,
  pub stable_key: String,
}

impl GameAssetId {
  pub fn new(namespace: impl Into<String>, stable_key: impl Into<String>) -> Self {
    Self { namespace: namespace.into(), stable_key: stable_key.into() }
  }
}

/// Registers the integration once per app.
pub fn add_game_assets(app: &mut App) {
  app.add_plugins(GameAssetPackPlugin);
}
