@tool
extends RefCounted
## The installation inventory is separate from the latest delivery manifest.
## Descriptors name reusable scenes; they do not invent missing generation specs.

const FORMAT := "game-assets-installed-catalog.v1"

static func from_journal(manifest: Dictionary, entries: Dictionary) -> Dictionary:
	var assets: Array[Dictionary] = []
	var incoming := {}
	for asset in manifest.assets: incoming[String(asset.asset_id)] = asset
	for asset_id in entries:
		var entry: Dictionary = entries[asset_id]
		var current: Dictionary = incoming.get(String(asset_id), {})
		var kind := String(entry.get("kind", current.get("kind", "")))
		if kind.is_empty():
			kind = "image_2d"
			for file in entry.files:
				if file.get("role") == "main" and String(file.get("path", "")).get_extension().to_lower() == "glb": kind = "prop_3d"
		assets.append({
			"asset_id": String(asset_id), "stable_key": String(entry.stable_key),
			"version_id": String(entry.version_id), "kind": kind,
			"display_name": String(entry.get("display_name", current.get("display_name", "早期导入资产 · " + String(entry.stable_key)))),
		})
	return {"schema_version": FORMAT, "project_id": manifest.project_id, "latest_pack_id": manifest.pack_id, "assets": assets}
