//! LOD chain selection (plan 13.5: the integration layer provides the
//! selection/switching capability; glTF is never assumed to carry LOD
//! behavior both engines understand).
//!
//! Semantics (v1, documented as part of the frozen contract):
//!   * The asset's MAIN scene is the implicit finest level (`None`
//!     here); manifest lod levels are progressively coarser with
//!     strictly increasing switch distances (validated at manifest
//!     parse).
//!   * Hysteresis bands are symmetric around each level's threshold:
//!       - coarsening onto level i engages only at distance >= d_i + h_i;
//!       - refining away from level i engages only at distance <= d_i - h_i;
//!     between those bands the current level is kept, absorbing the
//!     flicker the plan requires the config to prevent. The main scene
//!     participates as a normal (finest) state — the first coarsening
//!     hop waits out the band like any other.

use bevy::asset::Handle;
use bevy::prelude::WorldAsset;

use crate::manifest::ManifestLod;

/// One loaded LOD level: its scene handle plus the switching config.
#[derive(Debug, Clone)]
pub struct GameAssetLodLevel {
  pub level: u32,
  pub switch_distance_m: f32,
  pub hysteresis_m: f32,
  pub triangles: u64,
  pub scene: Handle<WorldAsset>,
}

#[derive(Debug, Clone)]
pub struct GameAssetLodChain {
  /// Ascending by level (manifest validation guarantees the order).
  pub levels: Vec<GameAssetLodLevel>,
}

impl GameAssetLodChain {
  /// Pick the level for a view distance given the currently active
  /// level (`None` = the main/finest scene). Returns `None` while the
  /// main scene remains the right choice.
  pub fn select_level(&self, distance_m: f32, current: Option<u32>) -> Option<u32> {
    // Coarsest plain-threshold candidate: the last level whose switch
    // distance the view has passed.
    let candidate = self
      .levels
      .iter()
      .filter(|level| distance_m >= level.switch_distance_m)
      .next_back()
      .map(|level| level.level);
    // Rank the main scene as level 0 so both transition directions are
    // uniform.
    let current_rank = current.unwrap_or(0);
    let candidate_rank = candidate.unwrap_or(0);
    if candidate_rank == current_rank {
      return current;
    }
    if candidate_rank > current_rank {
      // Coarsening: engage only outside the TARGET level's band.
      let Some(target) = self.find(candidate.unwrap()) else { return current };
      if distance_m >= target.switch_distance_m + target.hysteresis_m {
        candidate
      } else {
        current
      }
    } else {
      // Refining: leave the CURRENT level only inside its inner band.
      let Some(active) = self.find(current.unwrap()) else { return current };
      if distance_m <= active.switch_distance_m - active.hysteresis_m {
        candidate
      } else {
        current
      }
    }
  }

  fn find(&self, level: u32) -> Option<&GameAssetLodLevel> {
    self.levels.iter().find(|entry| entry.level == level)
  }

  /// Scene handle for a level number (`None` = main scene, callers hold
  /// that handle on the catalog entry).
  pub fn scene_for_level(&self, level: u32) -> Option<&Handle<WorldAsset>> {
    self.find(level).map(|entry| &entry.scene)
  }

  /// Build the chain skeleton (handles filled by the catalog loader)
  /// from the manifest block; validation already happened at parse.
  pub fn from_manifest(lod: &ManifestLod) -> Self {
    GameAssetLodChain {
      levels: lod
        .levels
        .iter()
        .map(|level| GameAssetLodLevel {
          level: level.level,
          switch_distance_m: level.switch_distance_m,
          hysteresis_m: level.hysteresis_m,
          triangles: level.triangles,
          scene: Handle::default(),
        })
        .collect(),
    }
  }
}

#[cfg(test)]
mod tests {
  use super::*;

  fn chain() -> GameAssetLodChain {
    GameAssetLodChain {
      levels: vec![
        GameAssetLodLevel { level: 1, switch_distance_m: 10.0, hysteresis_m: 2.0, triangles: 400, scene: Handle::default() },
        GameAssetLodLevel { level: 2, switch_distance_m: 25.0, hysteresis_m: 5.0, triangles: 100, scene: Handle::default() },
      ],
    }
  }

  #[test]
  fn initial_pick_uses_plain_thresholds() {
    let chain = chain();
    assert_eq!(chain.select_level(5.0, None), None, "near: main scene");
    // Main participates as a normal state: the first hop waits out
    // level 1's band (10 + 2).
    assert_eq!(chain.select_level(11.0, None), None, "inside level-1 band");
    assert_eq!(chain.select_level(12.0, None), Some(1));
    assert_eq!(chain.select_level(31.0, None), Some(2), "straight past both bands coarsens fully");
  }

  #[test]
  fn coarsening_waits_out_the_target_band() {
    let chain = chain();
    // On level 1, approaching level 2: its band is 25 + 5 = 30.
    assert_eq!(chain.select_level(27.0, Some(1)), Some(1), "still inside level-2 band");
    assert_eq!(chain.select_level(29.9, Some(1)), Some(1));
    assert_eq!(chain.select_level(30.0, Some(1)), Some(2));
  }

  #[test]
  fn refining_waits_out_the_active_band() {
    let chain = chain();
    // On level 1 (d=10, h=2): refine to main only at distance <= 8.
    assert_eq!(chain.select_level(9.0, Some(1)), Some(1), "inside the level-1 band");
    assert_eq!(chain.select_level(8.0, Some(1)), None);
    // On level 2 (d=25, h=5): refine to level 1 only at distance <= 20.
    assert_eq!(chain.select_level(21.0, Some(2)), Some(2));
    assert_eq!(chain.select_level(20.0, Some(2)), Some(1));
  }

  #[test]
  fn flicker_across_a_threshold_is_absorbed() {
    let chain = chain();
    // Coarsened onto level 1 at 12m, then hovers around level 1's
    // threshold: oscillating between 9 and 10.5 never bounces back to
    // main (refining needs <= 8).
    let mut current = chain.select_level(12.0, None);
    assert_eq!(current, Some(1));
    current = chain.select_level(9.0, current);
    assert_eq!(current, Some(1));
    current = chain.select_level(10.5, current);
    assert_eq!(current, Some(1));
    current = chain.select_level(7.9, current);
    assert_eq!(current, None, "fully below the inner band refines at last");
  }
}
