@tool
extends RefCounted
## §12.2 anim_2d playback resources. Parses and validates the frozen
## frames table (game.anim2d.frames.v1, artcraft-services
## animation_2d.rs::FrameTable), builds a SpriteFrames resource with one
## named animation per direction, and exposes the exact playback math the
## Bevy consumer uses so both engines sample the same frame at the same
## time. Pure logic + resource construction — runs headless.

const FRAMES_SCHEMA := "game.anim2d.frames.v1"
const DIRECTION_SETS := {
	1: ["default"],
	4: ["n", "e", "s", "w"],
	8: ["n", "ne", "e", "se", "s", "sw", "w", "nw"],
}
## Plugin image budgets shared with the PNG header check in importer.gd.
const MAX_ATLAS_EDGE := 8192
const MAX_TOTAL_FRAMES := 4096
## 1 platform world unit == 100 Godot 2D coordinate units (§12.2).
const GODOT_UNITS_PER_WORLD_UNIT := 100.0

var problems: PackedStringArray = PackedStringArray()

## Validate a frames table (JSON text) with explicit plugin budgets.
## Returns the validated Dictionary or {} and appends reasons to `errors`.
static func parse_frames(text: String, errors: PackedStringArray) -> Dictionary:
	var parsed: Variant = JSON.parse_string(text)
	if not (parsed is Dictionary):
		errors.append("frames 文件不是 JSON 对象。")
		return {}
	var t: Dictionary = parsed
	for key in t:
		if not (String(key) in ["schema_version", "clip_name", "canvas", "anchor", "atlas", "fps", "loop", "directions"]):
			errors.append("frames 文件包含未知字段：%s" % String(key))
			return {}
	if String(t.get("schema_version", "")) != FRAMES_SCHEMA:
		errors.append("frames 文件的 schema_version 不是 %s。" % FRAMES_SCHEMA)
		return {}
	if not safe_clip_name(String(t.get("clip_name", ""))):
		errors.append("frames 文件的 clip_name 不合法。")
		return {}
	var fps: Variant = t.get("fps")
	if typeof(fps) not in [TYPE_INT, TYPE_FLOAT] or not is_finite(float(fps)) or float(fps) <= 0:
		errors.append("frames 文件的 fps 必须为正数。")
		return {}
	var canvas: Dictionary = t.get("canvas", {})
	var atlas: Variant = t.get("atlas")
	var directions: Variant = t.get("directions")
	if not (atlas is Dictionary) or not (directions is Array):
		errors.append("frames 文件的 atlas/directions 结构不完整。")
		return {}
	var canvas_dict: Dictionary = t.get("canvas", {})
	var canvas_width := int(canvas_dict.get("width", 0))
	var canvas_height := int(canvas_dict.get("height", 0))
	if canvas_width < 1 or canvas_height < 1 or canvas_width > MAX_ATLAS_EDGE or canvas_height > MAX_ATLAS_EDGE:
		errors.append("frames 文件的画布尺寸不在可用范围内。")
		return {}
	var a: Dictionary = atlas
	for key in a:
		if not (String(key) in ["role", "ordinal", "width", "height", "extrude_px"]):
			errors.append("frames 文件的图集描述包含未知字段：%s" % String(key))
			return {}
	for block_name in ["canvas", "anchor"]:
		var block: Variant = t.get(block_name)
		if not (block is Dictionary):
			errors.append("frames 文件的 %s 结构不完整。" % block_name)
			return {}
		for key in block:
			var allowed := ["width", "height"] if block_name == "canvas" else ["origin", "x", "y"]
			if not (String(key) in allowed):
				errors.append("frames 文件的 %s 包含未知字段：%s" % [block_name, String(key)])
				return {}
	var anchor_dict: Dictionary = t.get("anchor", {})
	for axis in ["x", "y"]:
		var axis_value: Variant = anchor_dict.get(axis)
		if typeof(axis_value) not in [TYPE_INT, TYPE_FLOAT] or not is_finite(float(axis_value)) or float(axis_value) < 0 or float(axis_value) > 1:
			errors.append("frames 文件的 anchor 不合法。")
			return {}
	if String(anchor_dict.get("origin", "")) != "top_left":
		errors.append("frames 文件的 anchor 不合法。")
		return {}
	var atlas_width := int(a.get("width", 0))
	var atlas_height := int(a.get("height", 0))
	if String(a.get("role", "")) != "main" or int(a.get("ordinal", -1)) != 0 or int(a.get("extrude_px", -1)) != 1 or atlas_width < 1 or atlas_height < 1 or atlas_width > MAX_ATLAS_EDGE or atlas_height > MAX_ATLAS_EDGE:
		errors.append("frames 文件的图集描述不符合冻结布局（main/ordinal 0/1px 外扩）。")
		return {}
	var expected_directions: Array = DIRECTION_SETS.get((directions as Array).size(), []) as Array
	if expected_directions.is_empty():
		errors.append("frames 文件的方向数量必须是 1、4 或 8。")
		return {}
	var count := 0
	if not (directions as Array).is_empty() and ((directions as Array)[0] is Dictionary):
		count = (((directions as Array)[0] as Dictionary).get("frames", []) as Array).size()
	if count < 1 or count > MAX_TOTAL_FRAMES:
		errors.append("frames 文件的每方向帧数不在可用范围内。")
		return {}
	if not is_finite(float(count) / float(fps)):
		errors.append("frames 文件的时长无法表示。")
		return {}
	var occupied: Array = []
	for index in (directions as Array).size():
		var direction: Dictionary = (directions as Array)[index]
		for key in direction:
			if not (String(key) in ["name", "frames"]):
				errors.append("frames 文件的方向包含未知字段：%s" % String(key))
				return {}
		if not (direction is Dictionary) or String(direction.get("name", "")) != String(expected_directions[index]) or (direction.get("frames", []) as Array).size() != count:
			errors.append("frames 文件的方向 %s 帧数或命名不完整。" % String(expected_directions[index]))
			return {}
		for rect in direction.get("frames", []) as Array:
			if not (rect is Dictionary):
				errors.append("frames 文件的帧矩形不是对象。")
				return {}
			var r: Dictionary = rect
			for key in r:
				if not (String(key) in ["x", "y", "width", "height"]):
					errors.append("frames 文件的帧矩形包含未知字段：%s" % String(key))
					return {}
			var x := int(r.get("x", 0))
			var y := int(r.get("y", 0))
			var width := int(r.get("width", 0))
			var height := int(r.get("height", 0))
			if width != canvas_width or height != canvas_height or x <= 0 or y <= 0:
				errors.append("frames 文件的帧矩形与画布不符。")
				return {}
			var right := x + width + 1
			var bottom := y + height + 1
			if right > atlas_width or bottom > atlas_height:
				errors.append("frames 文件的帧矩形越出图集。")
				return {}
			for other in occupied:
				if x < int(other[2]) and right > int(other[0]) and y < int(other[3]) and bottom > int(other[1]):
					errors.append("frames 文件的帧矩形重叠。")
					return {}
			occupied.append([x, y, right, bottom])
	return t

## Playback index rule shared with Bevy (animation_2d.rs::frame_at):
## loop → floor(t*fps) mod N; one-shot → clamp at N-1. Returns -1 for
## unrepresentable inputs.
static func frame_index_at(time: float, fps: float, count: int, looping: bool) -> int:
	if not is_finite(time) or time < 0.0 or not is_finite(fps) or fps <= 0.0 or count <= 0:
		return -1
	var duration := float(count) / fps
	if not is_finite(duration) or duration <= 0.0:
		return -1
	var phase := fmod(time, duration) if looping else minf(time, duration)
	return mini(int(floor(phase * fps)), count - 1)

## Sprite offset for centered drawing with a top-left anchor contract:
## the anchor point lands on the node origin.
static func anchor_offset(anchor: Dictionary, canvas: Dictionary) -> Vector2:
	var width := float(canvas.get("width", 0))
	var height := float(canvas.get("height", 0))
	return Vector2((0.5 - float(anchor.get("x", 0.5))) * width, (0.5 - float(anchor.get("y", 0.5))) * height)

## Root scale: pixels_per_world_unit pixels == 1 world unit == 100 Godot
## 2D units, so scale = 100 / pixels_per_world_unit.
static func world_scale(pixels_per_world_unit: float) -> Vector2:
	var factor := GODOT_UNITS_PER_WORLD_UNIT / maxf(pixels_per_world_unit, 0.0001)
	return Vector2(factor, factor)

## Build the SpriteFrames resource: one named animation per direction,
## per-frame AtlasTexture references into the delivered main atlas.
static func build_sprite_frames(table: Dictionary, atlas_texture: Texture2D, problems: PackedStringArray) -> SpriteFrames:
	var frames := SpriteFrames.new()
	for name in frames.get_animation_names():
		frames.remove_animation(name)
	var fps := float(table.get("fps", 0))
	var looping := bool(table.get("loop", false))
	for direction in table.get("directions", []) as Array:
		var name := String((direction as Dictionary).get("name", ""))
		frames.add_animation(name)
		frames.set_animation_speed(name, fps)
		frames.set_animation_loop(name, looping)
		for rect in (direction as Dictionary).get("frames", []) as Array:
			var r: Dictionary = rect
			var frame_texture := AtlasTexture.new()
			frame_texture.atlas = atlas_texture
			frame_texture.region = Rect2(float(r.get("x", 0)), float(r.get("y", 0)), float(r.get("width", 0)), float(r.get("height", 0)))
			frame_texture.filter_clip = true
			frames.add_frame(name, frame_texture)
	frames.set_meta("artcraft_clip_name", String(table.get("clip_name", "")))
	frames.set_meta("artcraft_fps", fps)
	frames.set_meta("artcraft_loop", looping)
	return frames

## Switch the playing direction while keeping the phase: both engines
## agree on the frame index for a given time, so a direction switch must
## continue at the same position in the (equal-length) animation.
static func switch_direction(sprite: AnimatedSprite2D, direction: StringName) -> void:
	if sprite.sprite_frames == null or not sprite.sprite_frames.has_animation(direction):
		return
	var current := sprite.get_animation()
	if sprite.is_playing() and current != direction:
		var previous_count := sprite.sprite_frames.get_frame_count(current)
		var next_count := sprite.sprite_frames.get_frame_count(direction)
		if previous_count > 0 and next_count > 0:
			var progress := float(sprite.frame + sprite.frame_progress) / float(previous_count)
			sprite.play(direction)
			sprite.frame = mini(int(progress * next_count), next_count - 1)
			return
	sprite.play(direction)

## Load the atlas texture without relying on the editor import system so
## editor runs and headless checks see the same pixels.
static func load_atlas_texture(path: String, problems: PackedStringArray) -> Texture2D:
	var image := Image.load_from_file(path)
	if image == null or image.is_empty():
		problems.append("无法读取动画图集：" + path)
		return null
	return ImageTexture.create_from_image(image)

static func valid_anchor(anchor: Variant) -> bool:
	if not (anchor is Dictionary):
		return false
	var a: Dictionary = anchor
	if String(a.get("origin", "")) != "top_left":
		return false
	for axis in ["x", "y"]:
		var v: Variant = a.get(axis)
		if typeof(v) not in [TYPE_INT, TYPE_FLOAT] or not is_finite(float(v)) or float(v) < 0 or float(v) > 1:
			return false
	return true

static func safe_clip_name(value: String) -> bool:
	if value.is_empty() or value.length() > 64:
		return false
	if not (value[0] >= "a" and value[0] <= "z"):
		return false
	for i in value.length():
		var c := value[i]
		if not ((c >= "a" and c <= "z") or (c >= "0" and c <= "9") or c == "_"):
			return false
	return true
