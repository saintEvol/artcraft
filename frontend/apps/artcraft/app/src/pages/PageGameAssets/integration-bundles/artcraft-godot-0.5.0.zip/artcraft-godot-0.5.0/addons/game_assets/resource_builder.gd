@tool
extends RefCounted
## Trusted integration code creates reusable scenes; resource packs supply only data.
## Manifest 2.0 adds animation playback resources: anim_2d scenes carry a
## SpriteFrames resource (§12.2), character_3d scenes carry a recorded
## glTF-path → NodePath/bone binding (§12.3), and anim_3d scenes carry a
## retargeted AnimationLibrary. All derived files are registered in the
## journal's generated_files so recovery and update checks see them.

const InstalledCatalog := preload("res://addons/game_assets/installed_catalog.gd")
const Report := preload("res://addons/game_assets/engine_report.gd")
const Collision := preload("res://addons/game_assets/collision.gd")
const Preview := preload("res://addons/game_assets/preview.gd")
const Prop := preload("res://addons/game_assets/prop.gd")
const Journal := preload("res://addons/game_assets/journal.gd")
const Manifest2 := preload("res://addons/game_assets/manifest.gd")
const Animation2D := preload("res://addons/game_assets/animation_2d_resources.gd")
const Binding := preload("res://addons/game_assets/animation_binding.gd")

var problems: PackedStringArray = []
var preview_path := ""

func build(manifest: Dictionary, root: String, managed_namespace: String, unchanged: Array = []) -> bool:
	var journal := Journal.new()
	if not journal.load_from(managed_namespace):
		problems.append("导入记录缺失，不能创建资产场景。")
		return false
	if DirAccess.make_dir_recursive_absolute(root.path_join("scenes")) != OK:
		return false
	# Assets rebuilt this round: unchanged ones are reused verbatim, except
	# anim_3d clips whose rig was rebuilt (the retargeted library must be
	# regenerated against the new binding).
	var rebuilt_ids := {}
	for asset in manifest.assets:
		if not unchanged.has(String(asset.asset_id)):
			rebuilt_ids[String(asset.asset_id)] = true
	for asset in manifest.assets:
		if String(asset.kind) == "anim_3d":
			for dependency in asset.get("dependencies", []) as Array:
				if dependency is Dictionary and rebuilt_ids.has(String(dependency.get("asset_id", ""))):
					unchanged.erase(String(asset.asset_id))
					rebuilt_ids[String(asset.asset_id)] = true
	var derived: Array = []
	for asset in manifest.assets:
		var path: String = root.path_join(Manifest2.scene_relpath(asset))
		var packed: PackedScene
		if String(asset.asset_id) in unchanged and FileAccess.file_exists(path):
			packed = ResourceLoader.load(path, "PackedScene", ResourceLoader.CACHE_MODE_REPLACE) as PackedScene
			if packed == null:
				problems.append("无法读取原有资产场景：" + path); return false
		else:
			var extras: Array = []
			var node := _build_node(asset, root, journal, derived, extras)
			if node == null:
				return false
			node.name = String(asset.stable_key)
			node.set_meta("artcraft_asset_id", asset.asset_id)
			node.set_meta("artcraft_version_id", asset.version_id)
			packed = PackedScene.new()
			var error := packed.pack(node)
			node.free()
			if error != OK or not _save_scene(packed, path):
				return false
			derived.append({"path": Manifest2.scene_relpath(asset), "role": "generated_scene", "asset_id": String(asset.asset_id), "sha256": FileAccess.get_sha256(path)})
			derived.append_array(extras)
	# Carry over derived resources of reused assets; drop stale records of
	# rebuilt ones (their files are replaced above).
	var previous_generated := journal.generated_files.duplicate(true)
	journal.generated_files = []
	for record in previous_generated:
		var record_asset := String(record.get("asset_id", ""))
		if record_asset.is_empty() or not rebuilt_ids.has(record_asset):
			if FileAccess.file_exists(root.path_join(String(record.path))):
				journal.generated_files.append(record)
	journal.generated_files.append_array(derived)
	var catalog := InstalledCatalog.from_journal(manifest, journal.entries)
	preview_path = root.path_join("preview.tscn")
	var catalog_path := root.path_join("catalog.json")
	var known_preview := false
	for generated in journal.generated_files:
		if generated.path == "preview.tscn" and FileAccess.file_exists(preview_path) and generated.sha256 == FileAccess.get_sha256(preview_path): known_preview = true
	if unchanged.size() == manifest.assets.size() and known_preview and FileAccess.file_exists(catalog_path) and JSON.parse_string(FileAccess.get_file_as_string(catalog_path)) == catalog:
		return journal.save(managed_namespace)
	var scenes: Array[PackedScene] = []
	for descriptor in catalog.assets:
		var path: String = root.path_join(Manifest2.scene_relpath({"kind": descriptor.get("kind", ""), "stable_key": descriptor.get("stable_key", ""), "stage": descriptor.get("stage", "")}))
		var scene := ResourceLoader.load(path, "PackedScene", ResourceLoader.CACHE_MODE_REPLACE) as PackedScene if FileAccess.file_exists(path) else null
		scenes.append(scene)
	if not Report.save(catalog, catalog_path):
		problems.append("无法保存已安装资产目录，导入尚未完成。"); return false
	preview_path = root.path_join("preview.tscn")
	var preview := Node.new()
	preview.name = "GameAssetsPreview"
	preview.set_script(Preview)
	preview.set("asset_scenes", scenes)
	preview.set("manifest", manifest)
	preview.set("catalog_assets", catalog.assets)
	var packed := PackedScene.new()
	var error := packed.pack(preview)
	preview.free()
	if error != OK or not _save_scene(packed, preview_path):
		return false
	journal.generated_files = journal.generated_files.filter(func(record: Dictionary) -> bool: return String(record.get("path", "")) != "preview.tscn" and String(record.get("path", "")) != "catalog.json")
	journal.generated_files.append({"path": "preview.tscn", "sha256": FileAccess.get_sha256(preview_path)})
	journal.generated_files.append({"path": "catalog.json", "sha256": FileAccess.get_sha256(catalog_path)})
	if not journal.save(managed_namespace):
		problems.append("无法保存资源映射，导入尚未完成。")
		return false
	return true

func _build_node(asset: Dictionary, root: String, journal, derived: Array, extras: Array) -> Node:
	var previous: Node
	var scene_path := root.path_join(Manifest2.scene_relpath(asset))
	if FileAccess.file_exists(scene_path):
		var prior := ResourceLoader.load(scene_path, "PackedScene", ResourceLoader.CACHE_MODE_IGNORE) as PackedScene
		if prior != null: previous = prior.instantiate()
	match String(asset.kind):
		"icon_2d", "sprite_2d":
			if previous != null and not previous is Sprite2D: previous.free(); previous = null
			return _sprite(asset, root, previous)
		"anim_2d":
			if previous != null: previous.free()
			return _animation_2d(asset, root, extras)
		"prop_3d":
			if previous != null and not previous is Node3D: previous.free(); previous = null
			return _prop(asset, root, previous)
		"character_3d":
			if previous != null: previous.free()
			return _character_3d(asset, root, extras)
		"anim_3d":
			if previous != null: previous.free()
			return _animation_3d(asset, root, journal, derived, extras)
	if is_instance_valid(previous): previous.free()
	problems.append("资产类型无法生成场景：" + String(asset.stable_key))
	return null

func _animation_2d(asset: Dictionary, root: String, extras: Array) -> AnimatedSprite2D:
	var animation: Dictionary = asset.get("animation_2d", {}) as Dictionary
	var frames_path := ""
	var main_path := ""
	for file in asset.files:
		if file.role == "frames": frames_path = String(file.path)
		if file.role == "main": main_path = String(file.path)
	var parse_problems := PackedStringArray()
	var table := Animation2D.parse_frames(FileAccess.get_file_as_string(root.path_join(frames_path)), parse_problems)
	if table.is_empty():
		problems.append_array(parse_problems); return null
	var atlas := Animation2D.load_atlas_texture(root.path_join(main_path), problems)
	if atlas == null:
		return null
	if atlas.get_width() != int(table.atlas.width) or atlas.get_height() != int(table.atlas.height):
		problems.append("动画图集尺寸与 frames 描述不一致：" + String(asset.stable_key))
		return null
	var frames := Animation2D.build_sprite_frames(table, atlas, problems)
	var resource_path := "animations/" + String(asset.stable_key) + ".tres"
	if not _save_resource(frames, root.path_join(resource_path)):
		return null
	frames.resource_path = root.path_join(resource_path)
	var sprite := AnimatedSprite2D.new()
	sprite.sprite_frames = frames
	sprite.offset = Animation2D.anchor_offset(table.anchor, table.canvas)
	sprite.scale = Animation2D.world_scale(float(animation.get("pixels_per_world_unit", 100.0)))
	sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST if String(animation.get("sampling", "nearest")) == "nearest" else CanvasItem.TEXTURE_FILTER_LINEAR
	sprite.set_meta("artcraft_clip_name", String(table.clip_name))
	sprite.set_meta("artcraft_fps", float(table.fps))
	sprite.set_meta("artcraft_loop", bool(table.loop))
	sprite.set_meta("artcraft_pixels_per_world_unit", float(animation.get("pixels_per_world_unit", 100.0)))
	var directions := []
	for direction in table.directions: directions.append(String(direction.name))
	sprite.set_meta("artcraft_directions", directions)
	extras.append({"path": resource_path, "role": "generated_sprite_frames", "asset_id": String(asset.asset_id), "sha256": FileAccess.get_sha256(root.path_join(resource_path))})
	return sprite

func _character_3d(asset: Dictionary, root: String, extras: Array) -> Node3D:
	var main_path := ""
	for file in asset.files:
		if file.role == "main": main_path = String(file.path)
	var node := Node3D.new()
	var model := _load_gltf_scene(root.path_join(main_path))
	if model == null:
		problems.append("角色模型无法生成场景：" + String(asset.stable_key))
		node.free(); return null
	model.name = "Model"
	node.add_child(model)
	_set_owner(model, node)
	var nodes: Variant = Collision.build(asset.mesh, problems)
	if nodes == null:
		node.free(); return null
	for collision in nodes:
		node.add_child(collision)
		_set_owner(collision, node)
	var binding := Binding.new().build_node_map(root.path_join(main_path), "Model")
	if binding.is_empty():
		problems.append("无法生成角色的骨骼绑定：" + String(asset.stable_key))
		node.free(); return null
	binding["stable_key"] = String(asset.stable_key)
	binding["asset_id"] = String(asset.asset_id)
	binding["version_id"] = String(asset.version_id)
	binding["motion_root_path"] = (asset.get("rig", {}) as Dictionary).get("motion_root_path", [])
	binding["coordinate_conversion"] = Binding.COORDINATE_CONVERSION
	binding["importer_version"] = "game_assets_addon_1@" + Report.COMPONENT_VERSION
	var rig: Dictionary = asset.get("rig", {}) as Dictionary
	for slot in (rig.get("semantic_bones", {}) as Dictionary):
		var gltf_path := "/".join((rig.semantic_bones as Dictionary)[slot] as Array)
		if not (binding["paths"] as Dictionary).has(gltf_path):
			problems.append("清单声明的语义骨骼 %s（%s）不在导入的绑定中。" % [slot, gltf_path])
			node.free(); return null
	var binding_path := "bindings/" + String(asset.stable_key) + ".json"
	if not Report.save(binding, root.path_join(binding_path)):
		problems.append("无法保存角色绑定：" + binding_path)
		node.free(); return null
	extras.append({"path": binding_path, "role": "generated_binding", "asset_id": String(asset.asset_id), "sha256": FileAccess.get_sha256(root.path_join(binding_path))})
	return node

func _animation_3d(asset: Dictionary, root: String, journal, derived: Array, extras: Array) -> Node3D:
	var dependencies: Array = asset.get("dependencies", []) as Array
	if dependencies.size() != 1:
		problems.append("anim_3d 资产必须恰好依赖一个 rig：" + String(asset.stable_key))
		return null
	var dependency: Dictionary = dependencies[0] as Dictionary
	var binding := _load_binding(String(dependency.get("asset_id", "")), journal, derived, root)
	if binding.is_empty():
		problems.append("找不到依赖角色的绑定记录；请先导入角色 " + String(dependency.get("asset_id", "")))
		return null
	var map_path := ""
	var main_path := ""
	for file in asset.files:
		if file.role == "skeleton_map": map_path = String(file.path)
		if file.role == "main": main_path = String(file.path)
	var map_problems := PackedStringArray()
	var skeleton_map := Binding.parse_skeleton_map(FileAccess.get_file_as_string(root.path_join(map_path)), map_problems)
	if skeleton_map.is_empty():
		problems.append_array(map_problems); return null
	var binder := Binding.new()
	if not binder.verify_contract_mapping(binding, skeleton_map):
		problems.append_array(binder.problems); return null
	var motion_root: Array = binding.get("motion_root_path", []) as Array
	var built := binder.build_animation_library(root.path_join(main_path), binding, skeleton_map, motion_root)
	if built.is_empty():
		problems.append_array(binder.problems); return null
	var library: AnimationLibrary = built["library"]
	var library_path := "animations/" + String(asset.stable_key) + ".library.tres"
	if not _save_resource(library, root.path_join(library_path)):
		return null
	library.resource_path = root.path_join(library_path)
	var node := Node3D.new()
	var player := AnimationPlayer.new()
	player.name = "AnimationPlayer"
	node.add_child(player)
	player.owner = node
	player.add_animation_library(String(built["clip"]), library)
	node.set_meta("artcraft_clip", String(built["clip"]))
	node.set_meta("artcraft_rig_asset_id", String(dependency.get("asset_id", "")))
	node.set_meta("artcraft_rig_version_id", String(dependency.get("version_id", "")))
	node.set_meta("artcraft_coordinate_conversion", Binding.COORDINATE_CONVERSION)
	extras.append({"path": library_path, "role": "generated_animation_library", "asset_id": String(asset.asset_id), "sha256": FileAccess.get_sha256(root.path_join(library_path))})
	return node

## The rig binding comes from this build (same-pack character) or from the
## retained installation's journal.
func _load_binding(asset_id: String, journal, derived: Array, root: String) -> Dictionary:
	for record in derived:
		if String(record.get("asset_id", "")) == asset_id and String(record.get("role", "")) == "generated_binding":
			var fresh: Variant = JSON.parse_string(FileAccess.get_file_as_string(root.path_join(String(record.path))))
			return fresh if fresh is Dictionary else {}
	for record in journal.generated_files:
		if String(record.get("asset_id", "")) == asset_id and String(record.get("role", "")) == "generated_binding":
			var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string(root.path_join(String(record.path))))
			return parsed if parsed is Dictionary else {}
	return {}

## Editor path: use Godot's imported scene so UID/import metadata stay
## intact. Headless fallback: GLTFDocument generates the same scene graph
## without the import system.
func _load_gltf_scene(path: String) -> Node:
	if FileAccess.file_exists(path + ".import") or ResourceLoader.exists(path, "PackedScene"):
		var packed := ResourceLoader.load(path, "PackedScene", ResourceLoader.CACHE_MODE_REPLACE) as PackedScene
		if packed != null:
			return packed.instantiate()
	var state := GLTFState.new()
	var document := GLTFDocument.new()
	if document.append_from_file(path, state) != OK:
		return null
	var scene := document.generate_scene(state)
	if scene == null:
		return null
	var replacement := Node3D.new()
	replacement.name = String(scene.name)
	for child in scene.get_children():
		scene.remove_child(child)
		replacement.add_child(child)
	scene.free()
	return replacement

func _sprite(asset: Dictionary, root: String, previous: Sprite2D = null) -> Sprite2D:
	var image: Dictionary = asset.image
	var atlas: Dictionary = image.get("atlas", {})
	var entry: Dictionary = {}
	if not atlas.is_empty():
		entry = asset.files[int(atlas.page_file_index)]
	else:
		for file in asset.files:
			if file.role == "main":
				entry = file
	if entry.is_empty():
		problems.append("图像缺少主文件：" + String(asset.stable_key))
		return null
	var texture := ResourceLoader.load(root.path_join(String(entry.path)), "Texture2D", ResourceLoader.CACHE_MODE_REPLACE) as Texture2D
	if texture == null:
		texture = Animation2D.load_atlas_texture(root.path_join(String(entry.path)), problems)
	if texture == null:
		problems.append("Godot 未成功导入图像：" + String(entry.path))
		return null
	var width: float = image.width
	var height: float = image.height
	var anchor: Dictionary = image.get("anchor", {"x": 0.5, "y": 0.5})
	if not atlas.is_empty():
		var cropped := AtlasTexture.new()
		cropped.atlas = texture
		var rect: Dictionary = atlas.rect
		cropped.region = Rect2(rect.x, rect.y, rect.width, rect.height)
		width = atlas.uncropped_size.width; height = atlas.uncropped_size.height
		cropped.margin = Rect2(atlas.crop_offset.x, atlas.crop_offset.y, width - rect.width, height - rect.height)
		cropped.filter_clip = true
		texture = cropped
		anchor = atlas.anchor
	var sprite := _clean_root(previous, Sprite2D.new()) as Sprite2D
	sprite.texture = texture
	sprite.offset = Vector2((0.5 - float(anchor.x)) * width, (0.5 - float(anchor.y)) * height)
	sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST if image.sampling == "nearest" else CanvasItem.TEXTURE_FILTER_LINEAR
	sprite.set_meta("pixels_per_world_unit", image.get("pixels_per_world_unit", 100.0))
	return sprite

func _prop(asset: Dictionary, root: String, previous: Node3D = null) -> Node3D:
	var node := _clean_root(previous, Node3D.new()) as Node3D
	node.set_script(Prop)
	node.set("lod_description", asset.mesh.get("lod", {}))
	var levels: Array = [{"level": -1, "file_index": -1}]
	levels.append_array(asset.mesh.get("lod", {}).get("levels", []))
	for level in levels:
		var file: Dictionary = {}
		if int(level.level) == -1:
			for candidate in asset.files:
				if candidate.role == "main":
					file = candidate
		else:
			file = asset.files[int(level.file_index)]
		var model := _load_gltf_scene(root.path_join(String(file.get("path", ""))))
		if model == null or not _has_mesh(model):
			problems.append("模型或 LOD 没有可显示的网格：" + String(asset.get("display_name", asset.stable_key)))
			if model != null: model.free()
			node.free(); return null
		model.name = "Model" if int(level.level) == -1 else "LOD%d" % int(level.level)
		node.add_child(model); model.owner = node
	var nodes: Variant = Collision.build(asset.mesh, problems)
	if nodes == null:
		node.free(); return null
	for collision in nodes:
		node.add_child(collision)
		_set_owner(collision, node)
	return node

func _has_mesh(node: Node) -> bool:
	if node is MeshInstance3D and node.mesh != null and node.mesh.get_surface_count() > 0:
		return true
	for child in node.get_children():
		if _has_mesh(child): return true
	return false

func _save_scene(scene: PackedScene, path: String) -> bool:
	if DirAccess.make_dir_recursive_absolute(path.get_base_dir()) != OK:
		problems.append("无法建立资产场景目录：" + path)
		return false
	var previous_uid := ResourceSaver.get_resource_id_for_path(path, false)
	if ResourceSaver.save(scene, path) != OK:
		problems.append("无法保存资产场景：" + path); return false
	if previous_uid != ResourceUID.INVALID_ID and ResourceSaver.set_uid(path, previous_uid) != OK:
		problems.append("无法保留已有资源 UID：" + path); return false
	return true

func _save_resource(resource: Resource, path: String) -> bool:
	if DirAccess.make_dir_recursive_absolute(path.get_base_dir()) != OK:
		problems.append("无法建立派生资源目录：" + path)
		return false
	var previous_uid := ResourceSaver.get_resource_id_for_path(path, false)
	if ResourceSaver.save(resource, path) != OK:
		problems.append("无法保存派生资源：" + path); return false
	if previous_uid != ResourceUID.INVALID_ID and ResourceSaver.set_uid(path, previous_uid) != OK:
		problems.append("无法保留已有资源 UID：" + path); return false
	return true

func _set_owner(node: Node, root: Node) -> void:
	node.owner = root
	for child in node.get_children():
		_set_owner(child, root)

## Reuse only the node identity used by scene references. An explicit replacement
## must not promote old managed-file edits into the next generated baseline.
func _clean_root(previous: Node, defaults: Node) -> Node:
	if previous == null: return defaults
	for signal_info in previous.get_signal_list():
		for connection in previous.get_signal_connection_list(StringName(signal_info.name)):
			if int(connection.flags) & Object.CONNECT_PERSIST:
				previous.disconnect(StringName(signal_info.name), connection.callable)
	previous.set_script(null)
	for child in previous.get_children(true): previous.remove_child(child); child.free()
	for key in previous.get_meta_list(): previous.remove_meta(key)
	for group in previous.get_groups(): previous.remove_from_group(group)
	for property in defaults.get_property_list():
		if (int(property.usage) & PROPERTY_USAGE_STORAGE) != 0 and (int(property.usage) & PROPERTY_USAGE_READ_ONLY) == 0 and String(property.name) not in ["script", "name", "owner", "scene_file_path"]:
			previous.set(StringName(property.name), defaults.get(StringName(property.name)))
	defaults.free()
	return previous
