//! Update managed resource fields without replacing the game's root entity/transform.
use bevy::prelude::*;
use bevy::sprite::Anchor;
use crate::{GameAssetId, GameAssetLoadState};
use crate::catalog::{GameAssetCatalog, GameAssetLoadStateTracker};
use crate::spawn::{platform_anchor_to_bevy, GameAssetCollisionDescriptor};

#[derive(Component, Clone, Debug)]
pub struct GameAssetInstance {
  pub id: GameAssetId,
  pub version: String,
  pub lod_level: Option<u32>,
  pub automatic_lod: bool,
}

pub fn sync_instances(
  mut commands: Commands,
  catalog: Res<GameAssetCatalog>,
  tracker: Res<GameAssetLoadStateTracker>,
  camera: Query<&GlobalTransform, With<Camera3d>>,
  mut instances: Query<(
    Entity,
    &mut GameAssetInstance,
    Option<&mut Sprite>,
    Option<&mut ImageNode>,
    Option<&mut Anchor>,
    Option<&GlobalTransform>,
  )>,
) {
  for (entity, mut binding, sprite, ui, anchor, transform) in &mut instances {
    if tracker.state(&binding.id) != GameAssetLoadState::Loaded {
      continue;
    }
    let Some(entry) = catalog.entries.get(&binding.id) else {
      continue;
    };
    let changed = binding.version != entry.version_id;
    if let Some(handle) = &entry.render_image {
      if let Some(mut sprite) = sprite {
        if changed || sprite.image.id() != handle.id() {
          sprite.image = handle.clone();
          sprite.custom_size =
            Some(Vec2::new(entry.width as f32, entry.height as f32) / entry.pixels_per_world_unit);
        }
      }
      if let Some(mut image) = ui {
        if changed || image.image.id() != handle.id() {
          image.image = handle.clone();
        }
      }
      if changed {
        if let Some(mut anchor) = anchor {
          *anchor = platform_anchor_to_bevy(entry.anchor.0, entry.anchor.1);
        }
      }
    } else if entry.scene.is_some() {
      let level = if binding.automatic_lod {
        entry.lod.as_ref().and_then(|chain| {
          camera.iter().next().zip(transform).and_then(|(camera, root)| {
            chain.select_level(camera.translation().distance(root.translation()), binding.lod_level)
          })
        })
      } else {
        binding.lod_level
      };
      if changed || level != binding.lod_level {
        let handle = level
          .and_then(|level| entry.lod.as_ref().and_then(|chain| chain.scene_for_level(level)))
          .cloned()
          .or_else(|| entry.scene.clone());
        if let Some(handle) = handle {
          commands.entity(entity).insert(WorldAssetRoot(handle));
        }
        if let Some(collision) = &entry.collision {
          commands.entity(entity).insert(collision.clone());
        } else {
          commands.entity(entity).remove::<GameAssetCollisionDescriptor>();
        }
        binding.lod_level = level;
      }
    }
    binding.version = entry.version_id.clone();
  }
}

#[cfg(test)]
mod tests {
  use super::*;
  use bevy::ecs::system::RunSystemOnce;
  use crate::catalog::GameAssetEntry;

  #[test]
  fn helper_spawned_sprite_updates_its_resource_without_changing_game_transform_or_entity() {
    let mut app = App::new();
    app
      .init_resource::<Assets<Image>>()
      .init_resource::<GameAssetCatalog>()
      .init_resource::<GameAssetLoadStateTracker>()
      .add_systems(Update, sync_instances);
    let first = app.world_mut().resource_mut::<Assets<Image>>().add(Image::default());
    let second = app.world_mut().resource_mut::<Assets<Image>>().add(Image::default());
    let id = GameAssetId::new("qa", "icon");
    app.world_mut().resource_mut::<GameAssetCatalog>().entries.insert(
      id.clone(),
      GameAssetEntry {
        id: id.clone(),
        version_id: "v1".into(),
        display_name: "icon".into(),
        kind: "icon_2d".into(),
        image: Some(first.clone()),
        render_image: Some(first.clone()),
        scene: None,
        atlas: None,
        pixels_per_world_unit: 100.,
        width: 32,
        height: 64,
        anchor: (0.5, 0.5),
        sampling: "linear".into(),
        triangles: None,
        collision: None,
        lod: None,
      },
    );
    app
      .world_mut()
      .resource_mut::<GameAssetLoadStateTracker>()
      .states
      .insert(id.clone(), GameAssetLoadState::Loaded);
    let spawn_id = id.clone();
    let entity = app
      .world_mut()
      .run_system_once(
        move |mut commands: Commands,
              mut images: ResMut<Assets<Image>>,
              catalog: Res<GameAssetCatalog>,
              tracker: Res<GameAssetLoadStateTracker>| {
          crate::spawn::spawn_game_sprite(
            &mut commands,
            &mut images,
            &catalog,
            &tracker,
            &spawn_id,
            Vec2::new(3., 4.),
          )
          .unwrap()
        },
      )
      .unwrap();
    assert!(app.world().get::<GameAssetInstance>(entity).is_some());
    {
      let mut catalog = app.world_mut().resource_mut::<GameAssetCatalog>();
      let entry = catalog.entries.get_mut(&id).unwrap();
      entry.version_id = "v2".into();
      entry.render_image = Some(second.clone());
      entry.anchor = (0., 1.);
    }
    app.update();
    assert_eq!(app.world().get::<Sprite>(entity).unwrap().image.id(), second.id());
    assert_eq!(app.world().get::<Transform>(entity).unwrap().translation, Vec3::new(3., 4., 0.));
    assert_eq!(app.world().get::<GameAssetInstance>(entity).unwrap().version, "v2");
    assert_eq!(app.world().get::<Anchor>(entity).unwrap().0, Vec2::new(-0.5, -0.5));
  }
}
