extends RefCounted
## Directory swap with retained previous files and an explicit recovery marker.

const TAG := "artcraft-directory-transaction.v1"
const IGNORE := "# Artcraft transaction workspace\n"

var root := ""
var stage := ""
var backup := ""
var marker := ""
var problems: PackedStringArray = []

func prepare(destination: String) -> bool:
	root = destination
	marker = root + ".pending.json"
	if FileAccess.file_exists(marker) and not recover(destination):
		return false
	if FileAccess.file_exists(root.path_join(".gdignore")):
		problems.append("受管理目录有 .gdignore，请先核对工程中的忽略设置。")
		return false
	var nonce := Crypto.new().generate_random_bytes(16).hex_encode()
	stage = root.get_base_dir().path_join(".artcraft-stage_" + nonce)
	backup = root.get_base_dir().path_join(".artcraft-backup_" + nonce)
	if DirAccess.make_dir_recursive_absolute(stage) != OK:
		problems.append("无法建立导入工作目录。")
		return false
	if not _write_text(stage.path_join(".gdignore"), IGNORE):
		return false
	if DirAccess.dir_exists_absolute(root) and not _copy_tree(root, stage):
		return false
	return true

func commit_files() -> bool:
	if not _write_text(marker, JSON.stringify({"format": TAG, "root": root, "stage": stage, "backup": backup, "phase": "prepared"})):
		return false
	if DirAccess.dir_exists_absolute(root):
		if DirAccess.rename_absolute(root, backup) != OK:
			problems.append("无法保留上一份资源目录；没有替换当前资源。")
			return false
		_write_text(backup.path_join(".gdignore"), IGNORE)
	if DirAccess.rename_absolute(stage, root) != OK:
		problems.append("无法替换资源目录，正在恢复上一份。")
		recover(root)
		return false
	DirAccess.remove_absolute(root.path_join(".gdignore"))
	return true

func finish() -> bool:
	if not _write_text(marker, JSON.stringify({"format": TAG, "root": root, "stage": stage, "backup": backup, "phase": "committed"})):
		return false
	if DirAccess.remove_absolute(marker) != OK:
		problems.append("资源已提交，但完成标记尚未清理；下次导入将继续核对。")
		return false
	return true

func recover(destination: String) -> bool:
	var pending := destination + ".pending.json"
	if not FileAccess.file_exists(pending):
		return true
	var data: Variant = JSON.parse_string(FileAccess.get_file_as_string(pending))
	if not (data is Dictionary) or data.get("format") != TAG or data.get("root") != destination:
		problems.append("导入恢复标记无法识别；保留当前文件，请核对 " + pending)
		return false
	var previous := String(data.get("backup", ""))
	var working := String(data.get("stage", ""))
	var parent := destination.get_base_dir()
	if previous.get_base_dir() != parent or working.get_base_dir() != parent or not previous.get_file().begins_with(".artcraft-backup_") or not working.get_file().begins_with(".artcraft-stage_"):
		problems.append("恢复路径不属于受管理的导入工作目录。")
		return false
	if data.get("phase") != "committed":
		if DirAccess.dir_exists_absolute(destination):
			if DirAccess.dir_exists_absolute(working) or DirAccess.rename_absolute(destination, working) != OK:
				problems.append("无法保留未完成版本，恢复已停止。")
				return false
			_write_text(working.path_join(".gdignore"), IGNORE)
		if DirAccess.dir_exists_absolute(previous):
			if DirAccess.rename_absolute(previous, destination) != OK:
				problems.append("上一份仍保留，但尚未恢复到原资源位置。")
				return false
			if FileAccess.get_file_as_string(destination.path_join(".gdignore")) == IGNORE:
				DirAccess.remove_absolute(destination.path_join(".gdignore"))
	return DirAccess.remove_absolute(pending) == OK

func _copy_tree(source: String, destination: String) -> bool:
	var directory := DirAccess.open(source)
	if directory == null:
		problems.append("无法读取已有资源目录。")
		return false
	directory.include_hidden = true
	for name in directory.get_files():
		if directory.is_link(name) or DirAccess.copy_absolute(source.path_join(name), destination.path_join(name)) != OK:
			problems.append("无法保留已有文件或遇到符号链接：" + name)
			return false
	for name in directory.get_directories():
		if directory.is_link(name):
			problems.append("受管理目录包含符号链接：" + name)
			return false
		if DirAccess.make_dir_recursive_absolute(destination.path_join(name)) != OK or not _copy_tree(source.path_join(name), destination.path_join(name)):
			return false
	return true

func _write_text(path: String, text: String) -> bool:
	var file := FileAccess.open(path, FileAccess.WRITE)
	if file == null:
		problems.append("无法写入导入状态：" + path)
		return false
	file.store_string(text)
	file.flush()
	return true
