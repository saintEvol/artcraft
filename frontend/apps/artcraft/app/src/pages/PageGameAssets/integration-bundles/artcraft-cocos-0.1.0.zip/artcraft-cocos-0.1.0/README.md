# Artcraft Cocos Creator 集成 0.1.0

Artcraft 资产包（manifest 1.0/1.1/2.0）在 Cocos Creator 3.8.8 上的集成：`src/core/` 是零编辑器、零 DOM 依赖的纯 TypeScript 核心逻辑（清单解析与 2.0 全量校验、最终依赖安装图、导入日志 `artcraft-cocos-install.v2`、2D 帧播放规则、skeleton_map 对齐检查、引擎报告组装、§8.2 图集网格算法）；`src/extension/` 是编辑器扩展源码，编译产物在 `extension/`（扩展清单 + dist + 运行时组件脚本）。语义与 Bevy/Godot 两份既有实现及 services 仓 `game_asset_contracts` 对齐。

## 构建与测试

```sh
cd integrations/cocos/game-assets
npm install
npm run build        # tsc → extension/dist/（扩展运行时零外部依赖）
npx vitest run       # core 层 Node 测试（无需编辑器）
```

## 真实编辑器测试（macOS，Cocos Creator 3.8.8）

```sh
python3 script/artcraft/game-assets/test_cocos_probes.py          # P1/P2 探针 + 面板冒烟
python3 script/artcraft/game-assets/test_cocos_import_lifecycle.py  # 导入/幂等/回滚/冲突/1.x 全生命周期
```

脚本自建临时工程（含 `extensions/artcraft-game-assets`），扩展 load 后自执行任务、写结果、退出编辑器；结束行 `ARTCRAFT_COCOS_PROBES_OK` / `ARTCRAFT_COCOS_LIFECYCLE_OK`。探针结论见 [PROBES.md](PROBES.md)。

## 扩展结构

```
extension/                       # Cocos 扩展根（复制进工程 extensions/ 即用）
  package.json                   # 菜单（导入资产包/重新扫描/打开面板）+ 面板 + 场景脚本注册
  dist/extension/main.js         # 主进程：导入流程（菜单 ARTCRAFT 资产）
  dist/extension/scene.js        # 场景脚本：animation_binding（bind/stop）
  dist/extension/panel.js        # 简单面板：已安装资产列表/依赖/导入报告
  static/game_asset_animation_2d.ts  # 2D 运行时组件（随包安装进 assets/game_assets/<ns>/runtime/）
```

安装布局：`assets/game_assets/<project_id>/`（交付文件 + `import_journal.json` + 受管 `manifest.json` 副本 + `runtime/`），`.meta` 全部计入 journal 托管文件（UUID 稳定依赖它）；引擎报告落盘 `game_assets_reports/`。
