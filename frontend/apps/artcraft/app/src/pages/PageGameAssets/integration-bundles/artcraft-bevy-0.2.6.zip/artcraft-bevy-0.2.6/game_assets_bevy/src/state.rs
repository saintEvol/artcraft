//! Per-asset load-state projection (plan 15.2). The tracker itself lives
//! in [`crate::catalog::GameAssetLoadStateTracker`]; this module is the
//! stable import surface.

pub use crate::catalog::{GameAssetLoadState, GameAssetLoadStateTracker};
