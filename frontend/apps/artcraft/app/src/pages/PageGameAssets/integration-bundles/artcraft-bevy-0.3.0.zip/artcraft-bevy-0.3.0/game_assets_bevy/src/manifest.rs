//! Pack manifest model + validation (plan sections 14.2/14.3 and 11.2).
//!
//! Mirrors the frozen JSON schemas (`asset_pack_manifest.schema.json` for
//! 1.x, `asset_pack_manifest_v2.schema.json` for 2.0); unknown schema
//! MAJOR versions are rejected outright. Same-major unknown fields are
//! tolerated for 1.x; the 2.0 animation/rig blocks are closed (their
//! contract is `additionalProperties: false` and the rig block must not
//! smuggle private material URLs), so unknown keys there are rejected.

use std::collections::{BTreeMap, HashSet};
use serde::Deserialize;
use serde_json::Value;

pub const SUPPORTED_SCHEMA_MAJOR: u64 = 1;
pub const SUPPORTED_SCHEMA_MAJORS: [u64; 2] = [1, 2];
pub const MANIFEST_V2: &str = "2.0";
/// Engine features this crate can actually consume (2.0 kinds declare
/// them in engine_profiles; anything else fails the import).
pub const SUPPORTED_FEATURES: [&str; 3] =
  ["game.character3d.rig.v1", "game.anim2d.frames.v1", "game.anim3d.skeleton_map.v1"];
pub const MAX_MANIFEST_BYTES: usize = 4 * 1024 * 1024;

/// Consumer-side validation note: this parser is deliberately a subset of
/// the exporter schema — the exporter (artcraft-services) remains the
/// strict gate. Known leniencies: schema_version without a minor part and
/// uppercase-hex sha256 are accepted here;
/// exporters must not emit them.
#[derive(Debug, Clone, Deserialize)]
pub struct GameAssetPackManifest {
  /// "1.0"-style major.minor; major must be a supported one.
  pub schema_version: String,
  pub pack_id: String,
  pub project_id: String,
  pub export_id: String,
  pub engine_profiles: Vec<EngineProfile>,
  pub assets: Vec<ManifestAsset>,
}

impl GameAssetPackManifest {
  pub fn schema_major(&self) -> u64 {
    self.schema_version.split('.').next().and_then(|part| part.parse::<u64>().ok()).unwrap_or(0)
  }
}

#[derive(Debug, Clone, Deserialize)]
pub struct EngineProfile {
  pub id: String,
  pub engine: String,
  pub engine_version: String,
  #[serde(default)]
  pub validation_status: String,
  #[serde(default)]
  pub required_features: Option<Vec<String>>,
}

#[derive(Debug, Clone, Deserialize)]
pub struct ManifestAsset {
  pub asset_id: String,
  pub stable_key: String,
  #[serde(default)]
  pub display_name: String,
  pub version_id: String,
  /// icon_2d | sprite_2d | prop_3d | character_3d | anim_2d | anim_3d.
  pub kind: String,
  pub files: Vec<ManifestFile>,
  #[serde(default)]
  pub image: Option<ManifestImage>,
  #[serde(default)]
  pub mesh: Option<ManifestMesh>,
  /// 2.0: delivery stage per kind (plan 11.2); absent in 1.x.
  #[serde(default)]
  pub stage: Option<String>,
  /// 2.0: required array; `None` = field absent (1.x or invalid 2.0).
  #[serde(default)]
  pub dependencies: Option<Vec<ManifestDependency>>,
  #[serde(default)]
  pub rig: Option<ManifestRig>,
  #[serde(default)]
  pub animation_2d: Option<ManifestAnimation2d>,
  #[serde(default)]
  pub animation_3d: Option<ManifestAnimation3d>,
}

#[derive(Debug, Clone, Deserialize)]
pub struct ManifestFile {
  pub role: String,
  /// Pack-relative POSIX path.
  pub path: String,
  pub sha256: String,
  pub byte_length: u64,
  pub mime: String,
  /// 2.0: required non-negative ordinal, unique per (role, ordinal)
  /// within the asset; 1.x files default to 0.
  #[serde(default)]
  pub ordinal: u64,
}

impl ManifestAsset {
  /// The one main file (role main, ordinal 0). 2.0 layout rules plus the
  /// 1.x single-main convention make this unique.
  pub fn main_file(&self) -> Option<&ManifestFile> {
    self.files.iter().find(|file| file.role == "main" && file.ordinal == 0)
  }

  /// Catalog key within a namespace: 2.0 animation/character kinds live in
  /// per-kind delivery directories, so their stable keys are prefixed with
  /// the directory (anim_2d and anim_3d may share a stable key). Static
  /// kinds keep the bare 1.x stable key.
  pub fn catalog_key(&self) -> String {
    match kind_directory(&self.kind) {
      Some(directory) => format!("{directory}/{}", self.stable_key),
      None => self.stable_key.clone(),
    }
  }
}

/// 2.0 dependency entry (plan 11.2): anim_3d carries exactly one rig.
#[derive(Debug, Clone, Deserialize)]
pub struct ManifestDependency {
  pub role: String,
  pub asset_id: String,
  pub version_id: String,
  pub rig_main_sha256: String,
}

/// 2.0 `assets[i].rig` block — the parts the engine consumes for binding.
/// The full rig_profile snapshot travels inside the pack; this consumer
/// checks its identity/schema but does not need its execution parameters.
#[derive(Debug, Clone, Deserialize)]
pub struct ManifestRig {
  pub scene_index: u32,
  #[serde(default)]
  pub rig_profile: Option<Value>,
  #[serde(default)]
  pub rig_profile_hash: String,
  pub motion_root_path: Vec<String>,
  pub semantic_bones: BTreeMap<String, Vec<String>>,
  pub bone_count: u32,
  pub skin_count: u32,
  pub max_influences_per_vertex: u32,
  #[serde(default)]
  pub node_rest_sha256: String,
  #[serde(default)]
  pub skin_sha256: String,
}

/// 2.0 `assets[i].animation_2d` block.
#[derive(Debug, Clone, Deserialize)]
pub struct ManifestAnimation2d {
  pub frames_file: ManifestFileRef,
  pub pixels_per_world_unit: f32,
  /// nearest | linear.
  pub sampling: String,
  #[serde(default)]
  pub alpha_mode: String,
}

/// 2.0 `assets[i].animation_3d` block.
#[derive(Debug, Clone, Deserialize)]
pub struct ManifestAnimation3d {
  pub scene_index: u32,
  pub skeleton_map_file: ManifestFileRef,
}

/// Reference into the same asset's files: (role, ordinal).
#[derive(Debug, Clone, Deserialize)]
pub struct ManifestFileRef {
  pub role: String,
  pub ordinal: u64,
}

#[derive(Debug, Clone, Deserialize)]
pub struct ManifestImage {
  pub width: u32,
  pub height: u32,
  #[serde(default = "default_anchor")]
  pub anchor: ManifestAnchor,
  /// linear | nearest (plan 15.2: per-asset sampling, never global
  /// ImagePlugin defaults).
  pub sampling: String,
  #[serde(default = "default_ppu")]
  pub pixels_per_world_unit: f32,
  #[serde(default)]
  pub atlas: Option<ManifestAtlas>,
}

fn default_ppu() -> f32 {
  100.0
}

#[derive(Debug, Clone, Deserialize)]
pub struct ManifestAtlas {
  pub page_file_index: usize,
  pub rect: AtlasRect,
  pub uncropped_size: AtlasSize,
  pub crop_offset: AtlasOffset,
  pub anchor: ManifestAnchor,
}
#[derive(Debug, Clone, Deserialize)]
pub struct AtlasRect {
  pub x: u32,
  pub y: u32,
  pub width: u32,
  pub height: u32,
}
#[derive(Debug, Clone, Deserialize)]
pub struct AtlasSize {
  pub width: u32,
  pub height: u32,
}
#[derive(Debug, Clone, Deserialize)]
pub struct AtlasOffset {
  pub x: u32,
  pub y: u32,
}

#[derive(Debug, Clone, Deserialize)]
pub struct ManifestAnchor {
  pub x: f32,
  pub y: f32,
  /// "top_left" (platform convention, Y down, [0,1]).
  #[serde(default = "default_origin")]
  pub origin: String,
}

#[derive(Debug, Clone, Deserialize)]
pub struct ManifestMesh {
  pub scene_index: usize,
  #[serde(default)]
  pub triangles: Option<u64>,
  #[serde(default)]
  pub collision: Option<ManifestCollision>,
  #[serde(default)]
  pub lod: Option<ManifestLod>,
}

#[derive(Debug, Clone, Deserialize)]
pub struct ManifestCollision {
  pub kind: String,
  #[serde(default)]
  pub center: Option<Vec<f32>>,
  #[serde(default)]
  pub half_extents: Option<Vec<f32>>,
}

/// LOD block (plan 14.2): ordered explicit levels, each referencing a
/// listed+hashed file by index into the SAME asset's files array.
#[derive(Debug, Clone, Deserialize)]
pub struct ManifestLod {
  pub levels: Vec<ManifestLodLevel>,
}

#[derive(Debug, Clone, Deserialize)]
pub struct ManifestLodLevel {
  pub level: u32,
  pub file_index: usize,
  pub scene_index: usize,
  pub triangles: u64,
  pub switch_distance_m: f32,
  #[serde(default)]
  pub hysteresis_m: f32,
}

/// Pack paths must be relative, traversal-free and non-empty-segmented.
/// Shared by validation and disk verification (verify_pack_files reads
/// from this predicate too, so a validated manifest can never point the
/// verifier outside the pack root).
pub fn path_escapes(path: &str) -> bool {
  path.starts_with('/')
    || path.contains(['\\', ':', '#'])
    || path.len() > 240
    || path.split('/').any(|segment| segment == "." || segment == ".." || segment.is_empty())
}

fn safe_name(value: &str) -> bool {
  !value.is_empty()
    && value.len() <= 64
    && value.bytes().next().is_some_and(|byte| byte.is_ascii_lowercase())
    && value.bytes().all(|byte| byte.is_ascii_lowercase() || byte.is_ascii_digit() || byte == b'_')
}

fn default_anchor() -> ManifestAnchor {
  ManifestAnchor { x: 0.5, y: 0.5, origin: default_origin() }
}

fn default_origin() -> String {
  "top_left".to_string()
}

#[derive(Debug, Clone)]
pub struct ManifestProblem {
  pub message: String,
}

impl GameAssetPackManifest {
  /// Parse + contract-check. `problems` returns every reason the pack is
  /// not importable; an empty vec means importable.
  pub fn parse_and_validate(json: &str) -> Result<Self, Vec<ManifestProblem>> {
    if json.len() > MAX_MANIFEST_BYTES {
      return Err(vec![ManifestProblem {
        message: "清单超过 4 MiB，请分批交付。".into()
      }]);
    }
    let raw: Value = match serde_json::from_str(json) {
      Ok(raw) => raw,
      Err(error) => {
        return Err(vec![ManifestProblem {
          message: format!("manifest JSON parse error: {error}"),
        }]);
      },
    };
    let schema_version =
      raw.get("schema_version").and_then(Value::as_str).unwrap_or_default().to_string();
    let major = schema_version.split('.').next().and_then(|part| part.parse::<u64>().ok());
    match major {
      Some(major) if SUPPORTED_SCHEMA_MAJORS.contains(&major) => {},
      Some(_major) => {
        return Err(vec![ManifestProblem {
          message: format!(
            "unsupported manifest schema_version {schema_version} (crate supports majors {SUPPORTED_SCHEMA_MAJORS:?})",
          ),
        }]);
      },
      None => {
        return Err(vec![ManifestProblem {
          message: format!("malformed schema_version {schema_version}"),
        }]);
      },
    }
    // 2.0 is the only frozen 2.x shape; unknown minors are refused rather
    // than misread.
    if major == Some(2) && schema_version != MANIFEST_V2 {
      return Err(vec![ManifestProblem {
        message: format!(
          "unsupported manifest schema_version {schema_version} (only the frozen 2.0 shape is supported)"
        ),
      }]);
    }
    let manifest: GameAssetPackManifest =
      serde_json::from_value(raw.clone()).map_err(|error| {
        vec![ManifestProblem { message: format!("manifest decode error: {error}") }]
      })?;
    let mut problems = Vec::new();
    if manifest.pack_id.is_empty()
      || manifest.export_id.is_empty()
      || !safe_name(&manifest.project_id)
    {
      problems.push(ManifestProblem {
        message: "资源包身份缺失，或项目命名空间不安全；不会转换大小写后覆盖已有项目。".into(),
      });
    }

    if !manifest.engine_profiles.iter().any(|profile| profile.engine == "bevy") {
      problems.push(ManifestProblem { message: "no bevy engine_profile in the pack".to_string() });
    } else {
      // Plan 14.2: unsupported REQUIRED features must fail the import.
      // Supported set: the three 2.0 animation/character features.
      let mut declared: HashSet<&str> = HashSet::new();
      for profile in &manifest.engine_profiles {
        if profile.engine != "bevy" {
          continue;
        }
        if profile.engine_version != "0.20.0" {
          problems.push(ManifestProblem {
            message: "此组件要求 Bevy 0.20.0，请使用与资源包匹配的组件和引擎。".into(),
          });
        }
        if let Some(required) = profile.required_features.as_ref() {
          for feature in required {
            declared.insert(feature.as_str());
            if !SUPPORTED_FEATURES.contains(&feature.as_str()) {
              problems.push(ManifestProblem {
                message: format!(
                  "bevy profile requires unsupported features: {required:?} (this crate supports {SUPPORTED_FEATURES:?})"
                ),
              });
            }
          }
        }
      }
      if major == Some(2) {
        // 2.0: each kind's required feature must be declared by the bevy
        // profile (the exporter contract's missing_engine_feature_contract).
        for asset in &manifest.assets {
          if let Some(feature) = required_feature_for_kind(&asset.kind) {
            if !declared.contains(feature) {
              problems.push(ManifestProblem {
                message: format!(
                  "asset kind {} requires feature {feature} which no bevy profile declares",
                  asset.kind
                ),
              });
            }
          }
        }
      }
    }
    if manifest.assets.is_empty() {
      problems.push(ManifestProblem { message: "manifest carries no assets".to_string() });
    }
    let mut asset_ids = HashSet::new();
    // 1.x: stable_key is globally unique (it IS the catalog key). 2.0:
    // uniqueness is per kind — the delivery directories partition the
    // namespaces, so anim_2d/walk and anim_3d/walk coexist (the frozen
    // all-kinds fixture ships exactly that).
    let mut stable_keys = HashSet::new();
    let mut stable_keys_by_kind: HashSet<(&str, &str)> = HashSet::new();
    for asset in &manifest.assets {
      let key_unique = if major == Some(2) {
        stable_keys_by_kind.insert((asset.kind.as_str(), asset.stable_key.as_str()))
      } else {
        stable_keys.insert(asset.stable_key.clone())
      };
      if asset.asset_id.is_empty()
        || asset.version_id.is_empty()
        || !safe_name(&asset.stable_key)
        || !asset_ids.insert(asset.asset_id.clone())
        || !key_unique
      {
        problems.push(ManifestProblem {
          message: "资产身份缺失、不安全或重复，不能合并为同一个资源引用。".into(),
        });
      }
      if let Some(image) = &asset.image {
        if !image.pixels_per_world_unit.is_finite() || image.pixels_per_world_unit <= 0.0 {
          problems
            .push(ManifestProblem { message: "pixels_per_world_unit must be positive".into() });
        }
        if let Some(atlas) = &image.atlas {
          if atlas.page_file_index >= asset.files.len()
            || atlas.rect.width == 0
            || atlas.rect.height == 0
            || atlas.uncropped_size.width == 0
            || atlas.uncropped_size.height == 0
            || atlas.uncropped_size.width > 8192
            || atlas.uncropped_size.height > 8192
          {
            problems
              .push(ManifestProblem { message: "atlas mapping or dimensions are invalid".into() });
          }
        }
      }
      if asset.stable_key.is_empty() {
        problems
          .push(ManifestProblem { message: format!("asset {} has no stable_key", asset.asset_id) });
      }
      if asset.files.is_empty() {
        problems
          .push(ManifestProblem { message: format!("asset {} lists no files", asset.stable_key) });
      }
      for file in &asset.files {
        if path_escapes(&file.path) {
          problems.push(ManifestProblem {
            message: format!(
              "asset {} file path escapes the pack: {}",
              asset.stable_key, file.path
            ),
          });
        }
        if file.sha256.len() != 64 || !file.sha256.chars().all(|c| c.is_ascii_hexdigit()) {
          problems.push(ManifestProblem {
            message: format!(
              "asset {} file {} has a malformed sha256",
              asset.stable_key, file.path
            ),
          });
        }
      }
      if major == Some(2) {
        validate_asset_v2(asset, &raw, &manifest.assets, &mut problems);
      }
      match asset.kind.as_str() {
        "icon_2d" | "sprite_2d" => {
          if asset.image.is_none() {
            problems.push(ManifestProblem {
              message: format!("2D asset {} has no image block", asset.stable_key),
            });
          }
        },
        "prop_3d" | "character_3d" => {
          if asset.mesh.is_none() {
            problems.push(ManifestProblem {
              message: format!("3D asset {} has no mesh block", asset.stable_key),
            });
          }
          // LOD contract (plan 14.2/13.5): enabled but incomplete or
          // inconsistent mapping is rejected at import, never degraded.
          if let Some(lod) = asset.mesh.as_ref().and_then(|mesh| mesh.lod.as_ref()) {
            validate_lod_chain(asset, lod, &mut problems);
          }
        },
        "anim_2d" | "anim_3d" => {
          if major == Some(1) {
            problems.push(ManifestProblem {
              message: format!(
                "asset kind {} only exists in manifest 2.0 (asset {})",
                asset.kind, asset.stable_key
              ),
            });
          }
        },
        other => {
          problems.push(ManifestProblem { message: format!("unknown asset kind {other}") });
        },
      }
      if asset.kind == "character_3d" && major == Some(1) {
        problems.push(ManifestProblem {
          message: format!(
            "asset kind character_3d only exists in manifest 2.0 (asset {})",
            asset.stable_key
          ),
        });
      }
    }

    if problems.is_empty() {
      Ok(manifest)
    } else {
      Err(problems)
    }
  }

  /// Managed resource namespace derived from immutable project identity
  /// (plan 15.2: assets/game_assets/{project_namespace}/).
  pub fn project_namespace(&self) -> String {
    self.project_id.clone()
  }

  pub fn find_asset(&self, stable_key: &str) -> Option<&ManifestAsset> {
    self.assets.iter().find(|asset| asset.stable_key == stable_key)
  }
}

fn required_feature_for_kind(kind: &str) -> Option<&'static str> {
  match kind {
    "character_3d" => Some(SUPPORTED_FEATURES[0]),
    "anim_2d" => Some(SUPPORTED_FEATURES[1]),
    "anim_3d" => Some(SUPPORTED_FEATURES[2]),
    _ => None,
  }
}

fn stage_for_kind(kind: &str) -> Option<&'static str> {
  match kind {
    "icon_2d" | "sprite_2d" | "prop_3d" => Some("asset"),
    "character_3d" => Some("rigged"),
    "anim_2d" | "anim_3d" => Some("animation"),
    _ => None,
  }
}

/// 2.0 new-kind delivery directory (plan 11.2 file layout).
fn kind_directory(kind: &str) -> Option<&'static str> {
  match kind {
    "character_3d" => Some("characters"),
    "anim_2d" => Some("animations_2d"),
    "anim_3d" => Some("animations_3d"),
    _ => None,
  }
}

fn is_sha256(value: &str) -> bool {
  value.len() == 64 && value.chars().all(|c| c.is_ascii_hexdigit())
}

/// Windows reserved device names never become directory stems (the 2.0
/// safe_pack_path contract).
fn reserved_stem(segment: &str) -> bool {
  let stem = segment.split('.').next().unwrap_or("").to_ascii_lowercase();
  let bytes = stem.as_bytes();
  matches!(stem.as_str(), "con" | "nul" | "aux" | "prn")
    || (bytes.len() == 4
      && matches!(&stem[..3], "com" | "lpt")
      && (b'1'..=b'9').contains(&bytes[3]))
}

fn reject_unknown_keys(
  object: &Value,
  allowed: &[&str],
  what: &str,
  problems: &mut Vec<ManifestProblem>,
) {
  let Some(entries) = object.as_object() else { return };
  for key in entries.keys() {
    if !allowed.contains(&key.as_str()) {
      problems.push(ManifestProblem {
        message: format!("{what} carries unknown field {key} (2.0 blocks are closed)"),
      });
    }
  }
}

/// All 2.0-only checks for one asset (plan 11.2): required fields present,
/// stage per kind, kind↔metadata mapping, ordinal rules, dependency
/// closure against the pack itself, animation sidecar references, file
/// layout for the new kinds and closed rig/animation blocks.
fn validate_asset_v2(
  asset: &ManifestAsset,
  raw: &Value,
  all_assets: &[ManifestAsset],
  problems: &mut Vec<ManifestProblem>,
) {
  let raw_assets = raw.get("assets").and_then(Value::as_array);
  let raw_asset = raw_assets
    .and_then(|assets| assets.iter().find(|entry| entry.get("asset_id") == Some(&Value::String(asset.asset_id.clone()))))
    .cloned()
    .unwrap_or(Value::Null);

  // Required 2.0 fields must be present as fields, not just defaults.
  if asset.stage.is_none() {
    problems.push(ManifestProblem {
      message: format!("2.0 asset {} is missing required stage", asset.stable_key),
    });
  }
  if raw_asset.get("dependencies").is_none() {
    problems.push(ManifestProblem {
      message: format!("2.0 asset {} is missing required dependencies", asset.stable_key),
    });
  }
  for (index, file) in asset.files.iter().enumerate() {
    let raw_file = raw_asset
      .get("files")
      .and_then(Value::as_array)
      .and_then(|files| files.get(index));
    if raw_file.and_then(|entry| entry.get("ordinal")).is_none() {
      problems.push(ManifestProblem {
        message: format!(
          "2.0 asset {} file {} is missing required ordinal",
          asset.stable_key, file.path
        ),
      });
    }
  }

  // stage legality + kind mapping.
  if let Some(stage) = asset.stage.as_deref() {
    if Some(stage) != stage_for_kind(&asset.kind) {
      problems.push(ManifestProblem {
        message: format!(
          "2.0 asset {} kind {} cannot carry stage {} (intermediate stages never ship)",
          asset.stable_key, asset.kind, stage
        ),
      });
    }
  }
  let mut expects = |block: &str, present: bool| {
    if !present {
      problems.push(ManifestProblem {
        message: format!(
          "2.0 asset {} kind {} requires the {block} block",
          asset.stable_key, asset.kind
        ),
      });
    }
  };
  match asset.kind.as_str() {
    "icon_2d" | "sprite_2d" => {
      expects("image", asset.image.is_some());
      if asset.mesh.is_some() || asset.rig.is_some() {
        problems.push(ManifestProblem {
          message: format!("2.0 2D asset {} carries 3D blocks", asset.stable_key),
        });
      }
    },
    "prop_3d" => {
      expects("mesh", asset.mesh.is_some());
    },
    "character_3d" => {
      expects("mesh", asset.mesh.is_some());
      expects("rig", asset.rig.is_some());
    },
    "anim_2d" => {
      expects("animation_2d", asset.animation_2d.is_some());
    },
    "anim_3d" => {
      expects("animation_3d", asset.animation_3d.is_some());
    },
    _ => {},
  }
  if !matches!(asset.kind.as_str(), "anim_2d") && asset.animation_2d.is_some() {
    problems.push(ManifestProblem {
      message: format!("2.0 asset {} carries animation_2d but is not anim_2d", asset.stable_key),
    });
  }
  if !matches!(asset.kind.as_str(), "anim_3d") && asset.animation_3d.is_some() {
    problems.push(ManifestProblem {
      message: format!("2.0 asset {} carries animation_3d but is not anim_3d", asset.stable_key),
    });
  }
  if !matches!(asset.kind.as_str(), "character_3d") && asset.rig.is_some() {
    problems.push(ManifestProblem {
      message: format!("2.0 asset {} carries rig but is not character_3d", asset.stable_key),
    });
  }

  // (role, ordinal) uniqueness; main/frames/skeleton_map ordinal must be 0.
  let mut bindings = HashSet::new();
  for file in &asset.files {
    if !bindings.insert((file.role.as_str(), file.ordinal)) {
      problems.push(ManifestProblem {
        message: format!(
          "2.0 asset {} declares role {} ordinal {} twice",
          asset.stable_key, file.role, file.ordinal
        ),
      });
    }
    if matches!(file.role.as_str(), "main" | "frames" | "skeleton_map") && file.ordinal != 0 {
      problems.push(ManifestProblem {
        message: format!(
          "2.0 asset {} file role {} must use ordinal 0",
          asset.stable_key, file.role
        ),
      });
    }
  }

  // Dependencies: anim_3d exactly one rig resolving inside the pack;
  // everything else empty.
  let dependencies = asset.dependencies.clone().unwrap_or_default();
  if asset.kind == "anim_3d" {
    if dependencies.len() != 1 {
      problems.push(ManifestProblem {
        message: format!(
          "2.0 anim_3d asset {} must depend on exactly one rig (got {})",
          asset.stable_key,
          dependencies.len()
        ),
      });
    }
  } else if !dependencies.is_empty() {
    problems.push(ManifestProblem {
      message: format!(
        "2.0 asset {} carries dependencies but only anim_3d may",
        asset.stable_key
      ),
    });
  }
  for dependency in &dependencies {
    reject_unknown_keys(
      raw_asset
        .get("dependencies")
        .and_then(Value::as_array)
        .and_then(|list| list.iter().find(|entry| entry.get("asset_id").and_then(Value::as_str) == Some(dependency.asset_id.as_str())))
        .unwrap_or(&Value::Null),
      &["role", "asset_id", "version_id", "rig_main_sha256"],
      &format!("dependency of {}", asset.stable_key),
      problems,
    );
    if dependency.role != "rig" {
      problems.push(ManifestProblem {
        message: format!(
          "2.0 dependency role {} is unknown (only rig exists)",
          dependency.role
        ),
      });
    }
    if !is_sha256(&dependency.rig_main_sha256) {
      problems.push(ManifestProblem {
        message: format!("2.0 dependency of {} has a malformed sha256", asset.stable_key),
      });
    }
    let target = all_assets
      .iter()
      .find(|candidate| candidate.asset_id == dependency.asset_id);
    let Some(target) = target else {
      problems.push(ManifestProblem {
        message: format!(
          "2.0 anim_3d asset {} depends on rig {} which is not in the pack",
          asset.stable_key, dependency.asset_id
        ),
      });
      continue;
    };
    if target.kind != "character_3d"
      || target.stage.as_deref() != Some("rigged")
      || target.version_id != dependency.version_id
      || target.main_file().map(|file| file.sha256.to_lowercase())
        != Some(dependency.rig_main_sha256.to_lowercase())
    {
      problems.push(ManifestProblem {
        message: format!(
          "2.0 anim_3d asset {} depends on rig {} with kind/stage/version/main hash not matching the delivered character",
          asset.stable_key, dependency.asset_id
        ),
      });
    }
  }

  // Animation sidecar references must land in this asset's files.
  if let Some(animation) = &asset.animation_2d {
    reject_unknown_keys(
      raw_asset.get("animation_2d").unwrap_or(&Value::Null),
      &["frames_file", "pixels_per_world_unit", "sampling", "alpha_mode"],
      &format!("animation_2d block of {}", asset.stable_key),
      problems,
    );
    if animation.frames_file.role != "frames"
      || animation.frames_file.ordinal != 0
      || !asset
        .files
        .iter()
        .any(|file| file.role == "frames" && file.ordinal == 0 && file.mime == "application/json")
    {
      problems.push(ManifestProblem {
        message: format!(
          "2.0 anim_2d asset {} frames_file does not reference its frames.json",
          asset.stable_key
        ),
      });
    }
    if !animation.pixels_per_world_unit.is_finite() || animation.pixels_per_world_unit <= 0.0 {
      problems.push(ManifestProblem {
        message: format!(
          "2.0 anim_2d asset {} has non-positive pixels_per_world_unit",
          asset.stable_key
        ),
      });
    }
    if !matches!(animation.sampling.as_str(), "nearest" | "linear") {
      problems.push(ManifestProblem {
        message: format!("2.0 anim_2d asset {} has unknown sampling", asset.stable_key),
      });
    }
  }
  if let Some(animation) = &asset.animation_3d {
    reject_unknown_keys(
      raw_asset.get("animation_3d").unwrap_or(&Value::Null),
      &["scene_index", "skeleton_map_file"],
      &format!("animation_3d block of {}", asset.stable_key),
      problems,
    );
    if animation.scene_index != 0
      || animation.skeleton_map_file.role != "skeleton_map"
      || animation.skeleton_map_file.ordinal != 0
      || !asset
        .files
        .iter()
        .any(|file| file.role == "skeleton_map" && file.ordinal == 0 && file.mime == "application/json")
    {
      problems.push(ManifestProblem {
        message: format!(
          "2.0 anim_3d asset {} skeleton_map_file does not reference its skeleton_map.json",
          asset.stable_key
        ),
      });
    }
  }
  // Static kinds cannot smuggle animation sidecar files.
  if required_feature_for_kind(&asset.kind).is_none()
    && asset.files.iter().any(|file| matches!(file.role.as_str(), "frames" | "skeleton_map"))
  {
    problems.push(ManifestProblem {
      message: format!(
        "2.0 asset {} ships animation sidecar files but is not an animation kind",
        asset.stable_key
      ),
    });
  }

  // rig block: closed shape, structural measurements, offline-usable paths.
  if let Some(rig) = &asset.rig {
    reject_unknown_keys(
      raw_asset.get("rig").unwrap_or(&Value::Null),
      &[
        "scene_index", "rig_profile", "rig_profile_hash", "motion_root_path", "semantic_bones",
        "bone_count", "skin_count", "max_influences_per_vertex", "node_rest_sha256",
        "skin_sha256",
      ],
      &format!("rig block of {}", asset.stable_key),
      problems,
    );
    if rig.scene_index != 0 {
      problems.push(ManifestProblem {
        message: format!("2.0 rig of {} must use scene_index 0", asset.stable_key),
      });
    }
    if rig.bone_count == 0 || rig.skin_count == 0 || !(1..=4).contains(&rig.max_influences_per_vertex)
    {
      problems.push(ManifestProblem {
        message: format!("2.0 rig of {} has invalid bone/skin measurements", asset.stable_key),
      });
    }
    if !is_sha256(&rig.node_rest_sha256)
      || !is_sha256(&rig.skin_sha256)
      || !is_sha256(&rig.rig_profile_hash)
    {
      problems.push(ManifestProblem {
        message: format!("2.0 rig of {} has malformed digests", asset.stable_key),
      });
    }
    if rig.motion_root_path.is_empty()
      || rig.motion_root_path.iter().any(|name| name.is_empty() || name.contains(['/', '\\', ':', '.', '%']))
    {
      problems.push(ManifestProblem {
        message: format!("2.0 rig of {} has an invalid motion_root_path", asset.stable_key),
      });
    }
    if rig.semantic_bones.is_empty() {
      problems.push(ManifestProblem {
        message: format!("2.0 rig of {} has no semantic_bones", asset.stable_key),
      });
    }
    for (slot, path) in &rig.semantic_bones {
      if slot.is_empty()
        || path.is_empty()
        || path.iter().any(|name| name.is_empty() || name.contains(['/', '\\', ':', '.', '%']))
        || !path.starts_with(&rig.motion_root_path)
      {
        problems.push(ManifestProblem {
          message: format!(
            "2.0 rig of {} maps slot {} outside the motion root",
            asset.stable_key, slot
          ),
        });
      }
    }
    let profile = rig.rig_profile.as_ref().unwrap_or(&Value::Null);
    reject_unknown_keys(
      profile,
      &[
        "schema_version", "id", "revision", "unit", "up_axis", "visual_forward", "pose",
        "motion_root_slot", "bones", "max_bones", "max_skins", "max_influences_per_vertex",
        "max_nodes", "max_accessors", "max_vertices", "tolerances", "diagnostic_poses",
      ],
      &format!("rig_profile snapshot of {}", asset.stable_key),
      problems,
    );
    if profile.get("schema_version").and_then(Value::as_str) != Some("game.rig_profile.v1") {
      problems.push(ManifestProblem {
        message: format!(
          "2.0 rig of {} does not carry a game.rig_profile.v1 snapshot",
          asset.stable_key
        ),
      });
    }
  }

  // File layout for the new kinds (plan 11.2): only main/frames/
  // skeleton_map/preview under assets/<kind dir>/<stable_key>/.
  if let Some(directory) = kind_directory(&asset.kind) {
    for file in &asset.files {
      let allowed = match (asset.kind.as_str(), file.role.as_str(), file.mime.as_str()) {
        ("character_3d", "main", "model/gltf-binary") => true,
        ("anim_2d", "main", "image/png") => true,
        ("anim_2d", "frames", "application/json") => true,
        ("anim_3d", "main", "model/gltf-binary") => true,
        ("anim_3d", "skeleton_map", "application/json") => true,
        (_, "preview", "image/png") => true,
        _ => false,
      };
      let extension = match file.mime.as_str() {
        "image/png" => "png",
        "model/gltf-binary" => "glb",
        "application/json" => "json",
        _ => "",
      };
      let expected = format!("assets/{}/{}/{}.{}", directory, asset.stable_key, file.role, extension);
      if !allowed || file.ordinal != 0 || file.path != expected {
        problems.push(ManifestProblem {
          message: format!(
            "2.0 asset {} file {} violates the delivery layout (private or unsupported file)",
            asset.stable_key, file.path
          ),
        });
      }
      if file.path.split('/').any(reserved_stem) {
        problems.push(ManifestProblem {
          message: format!(
            "2.0 asset {} file path uses a reserved name: {}",
            asset.stable_key, file.path
          ),
        });
      }
    }
  }

  // All 2.0 scenes are scene 0 (the exporter never ships multi-scene GLBs).
  if let Some(mesh) = &asset.mesh {
    if mesh.scene_index != 0 {
      problems.push(ManifestProblem {
        message: format!("2.0 asset {} mesh must use scene_index 0", asset.stable_key),
      });
    }
  }
}

fn validate_lod_chain(
  asset: &ManifestAsset,
  lod: &crate::manifest::ManifestLod,
  problems: &mut Vec<ManifestProblem>,
) {
  if lod.levels.is_empty() {
    problems.push(ManifestProblem {
      message: format!("asset {} has an empty lod block", asset.stable_key),
    });
  }
  let mut previous_level: Option<u32> = None;
  let mut previous_switch: Option<f32> = None;
  for level in &lod.levels {
    if level.level < 1 {
      // Main is the implicit finest level (rank 0 in both engines'
      // selectors); explicit levels are 1-based.
      problems.push(ManifestProblem {
        message: format!(
          "asset {} lod level {} is invalid: explicit levels start at 1",
          asset.stable_key, level.level
        ),
      });
    }
    if level.file_index >= asset.files.len() {
      problems.push(ManifestProblem {
        message: format!(
          "asset {} lod level {} references file_index {} outside its files",
          asset.stable_key, level.level, level.file_index
        ),
      });
    }
    if let Some(previous) = previous_level {
      if level.level <= previous {
        problems.push(ManifestProblem {
          message: format!(
            "asset {} lod levels must be ascending: {} after {}",
            asset.stable_key, level.level, previous
          ),
        });
      }
    }
    if !(level.switch_distance_m.is_finite() && level.switch_distance_m > 0.0) {
      problems.push(ManifestProblem {
        message: format!(
          "asset {} lod level {} has a non-positive switch distance",
          asset.stable_key, level.level
        ),
      });
    }
    if let Some(previous) = previous_switch {
      if level.switch_distance_m <= previous {
        problems.push(ManifestProblem {
          message: format!(
            "asset {} lod switch distances must increase: {} after {}",
            asset.stable_key, level.switch_distance_m, previous
          ),
        });
      }
    }
    if !(level.hysteresis_m.is_finite() && level.hysteresis_m >= 0.0) {
      problems.push(ManifestProblem {
        message: format!(
          "asset {} lod level {} has a negative hysteresis",
          asset.stable_key, level.level
        ),
      });
    } else if level.hysteresis_m > level.switch_distance_m {
      // A band wider than its threshold can never be left.
      problems.push(ManifestProblem {
        message: format!(
          "asset {} lod level {} hysteresis {} exceeds its switch distance {}",
          asset.stable_key, level.level, level.hysteresis_m, level.switch_distance_m
        ),
      });
    }
    previous_level = Some(level.level);
    previous_switch = Some(level.switch_distance_m);
  }
}

#[cfg(test)]
mod tests {
  use super::*;

  /// Frozen 2.0 fixtures from test_data/game_assets/contracts/fixtures.
  fn fixture_dir() -> String {
    format!(
      "{}/../../../test_data/game_assets/contracts/fixtures/asset_pack_manifest_v2",
      env!("CARGO_MANIFEST_DIR")
    )
  }

  fn fixture(name: &str) -> String {
    std::fs::read_to_string(format!("{}/{}.json", fixture_dir(), name))
      .unwrap_or_else(|error| panic!("cannot read fixture {name}: {error}"))
  }

  #[test]
  fn accepts_the_frozen_valid_all_kinds_fixture() {
    let manifest = GameAssetPackManifest::parse_and_validate(&fixture("valid_all_kinds"))
      .unwrap_or_else(|problems| panic!("{problems:?}"));
    assert_eq!(manifest.schema_major(), 2);
    let hero = manifest.find_asset("hero").unwrap();
    assert_eq!(hero.stage.as_deref(), Some("rigged"));
    let rig = hero.rig.as_ref().unwrap();
    assert_eq!(rig.motion_root_path, vec!["Hero".to_string()]);
    assert_eq!(
      rig.semantic_bones.get("hips"),
      Some(&vec!["Hero".to_string(), "Hip".to_string()])
    );
    assert_eq!(
      hero.dependencies.as_ref().map(|deps| deps.len()),
      Some(0)
    );
    let walk = manifest.find_asset("walk").unwrap();
    assert_eq!(walk.animation_2d.as_ref().unwrap().pixels_per_world_unit, 100.0);
    let hero_files: Vec<&str> =
      hero.files.iter().map(|file| file.role.as_str()).collect();
    assert_eq!(hero_files, vec!["main"]);
  }

  #[test]
  fn rejects_every_frozen_invalid_v2_fixture() {
    for name in [
      "invalid_intermediate_stage",
      "invalid_missing_frames",
      "invalid_missing_rig_dependency",
      "invalid_null_metadata",
      "invalid_private_source",
      "invalid_reserved_path",
      "invalid_sidecar_reference",
      "invalid_unknown_rig_field",
    ] {
      let problems = GameAssetPackManifest::parse_and_validate(&fixture(name))
        .err()
        .unwrap_or_else(|| panic!("fixture {name} must be rejected"));
      assert!(
        !problems.is_empty(),
        "fixture {name} rejected without a reason"
      );
    }
  }

  #[test]
  fn v2_dependency_must_match_the_packed_character_bytes() {
    // Corrupt only the rig_main_sha256 of the anim_3d dependency: the
    // pack still references hero, but no longer the delivered main hash.
    let mut raw: serde_json::Value =
      serde_json::from_str(&fixture("valid_all_kinds")).unwrap();
    raw["assets"][2]["dependencies"][0]["rig_main_sha256"] =
      serde_json::json!("f".repeat(64));
    let problems = GameAssetPackManifest::parse_and_validate(&raw.to_string()).unwrap_err();
    assert!(
      problems.iter().any(|problem| problem.message.contains("not matching the delivered character")),
      "{problems:?}"
    );

    // Point the dependency at the wrong version of the same character.
    let mut raw: serde_json::Value =
      serde_json::from_str(&fixture("valid_all_kinds")).unwrap();
    raw["assets"][2]["dependencies"][0]["version_id"] = serde_json::json!("rig_v2");
    let problems = GameAssetPackManifest::parse_and_validate(&raw.to_string()).unwrap_err();
    assert!(
      problems.iter().any(|problem| problem.message.contains("not matching the delivered character")),
      "{problems:?}"
    );
  }

  #[test]
  fn v2_required_fields_and_ordinal_rules_are_enforced() {
    let base: serde_json::Value = serde_json::from_str(&fixture("valid_all_kinds")).unwrap();

    // ordinal missing on one file.
    let mut raw = base.clone();
    raw["assets"][0]["files"][0].as_object_mut().unwrap().remove("ordinal");
    let problems = GameAssetPackManifest::parse_and_validate(&raw.to_string()).unwrap_err();
    assert!(problems.iter().any(|p| p.message.contains("missing required ordinal")), "{problems:?}");

    // dependencies array missing on a no-dependency asset.
    let mut raw = base.clone();
    raw["assets"][0].as_object_mut().unwrap().remove("dependencies");
    let problems = GameAssetPackManifest::parse_and_validate(&raw.to_string()).unwrap_err();
    assert!(
      problems.iter().any(|p| p.message.contains("missing required dependencies")),
      "{problems:?}"
    );

    // stage missing.
    let mut raw = base.clone();
    raw["assets"][0].as_object_mut().unwrap().remove("stage");
    let problems = GameAssetPackManifest::parse_and_validate(&raw.to_string()).unwrap_err();
    assert!(problems.iter().any(|p| p.message.contains("missing required stage")), "{problems:?}");

    // duplicate (role, ordinal) binding.
    let mut raw = base.clone();
    let file = raw["assets"][2]["files"][1].clone();
    raw["assets"][2]["files"].as_array_mut().unwrap().push(file);
    let problems = GameAssetPackManifest::parse_and_validate(&raw.to_string()).unwrap_err();
    assert!(problems.iter().any(|p| p.message.contains("twice")), "{problems:?}");

    // unsupported 2.x minor.
    let mut raw = base.clone();
    raw["schema_version"] = serde_json::json!("2.1");
    assert!(GameAssetPackManifest::parse_and_validate(&raw.to_string()).is_err());
  }

  #[test]
  fn new_kinds_never_parse_from_a_1x_manifest() {
    let mut raw: serde_json::Value = serde_json::from_str(&fixture("valid_all_kinds")).unwrap();
    raw["schema_version"] = serde_json::json!("1.1");
    let problems = GameAssetPackManifest::parse_and_validate(&raw.to_string()).unwrap_err();
    assert!(
      problems.iter().any(|p| p.message.contains("only exists in manifest 2.0")),
      "{problems:?}"
    );
  }

  #[test]
  fn identities_cannot_alias_existing_namespaces_or_overwrite_another_catalog_entry() {
    let valid = manifest_json(
      r#""lod": {"levels": [{"level":1,"file_index":1,"scene_index":0,"triangles":8,"switch_distance_m":10.0,"hysteresis_m":1.0}]}"#,
    );
    assert!(GameAssetPackManifest::parse_and_validate(&valid).is_ok());
    let base: serde_json::Value = serde_json::from_str(&valid).unwrap();
    for id in ["PROJ1", "../proj1", ""] {
      let mut raw = base.clone();
      raw["project_id"] = serde_json::json!(id);
      assert!(GameAssetPackManifest::parse_and_validate(&raw.to_string()).is_err());
    }
    for duplicate_id in [false, true] {
      let mut raw = base.clone();
      let mut second = raw["assets"][0].clone();
      if duplicate_id {
        second["stable_key"] = serde_json::json!("other");
      } else {
        second["asset_id"] = serde_json::json!("other");
      }
      raw["assets"].as_array_mut().unwrap().push(second);
      assert!(GameAssetPackManifest::parse_and_validate(&raw.to_string()).is_err());
    }
    let mut wrong_engine = base;
    wrong_engine["engine_profiles"][0]["engine_version"] = serde_json::json!("0.19.0");
    assert!(GameAssetPackManifest::parse_and_validate(&wrong_engine.to_string()).is_err());
  }

  #[test]
  fn oversized_manifest_is_rejected_before_deserializing() {
    let text = " ".repeat(MAX_MANIFEST_BYTES + 1);
    let problems = GameAssetPackManifest::parse_and_validate(&text).unwrap_err();
    assert!(problems[0].message.contains("超过 4 MiB"));
  }

  /// Minimal valid manifest JSON with an optional lod block on the
  /// single prop_3d asset (two files: main + one lod).
  fn manifest_json(lod_json: &str) -> String {
    format!(
      r#"{{
  "schema_version": "1.0",
  "pack_id": "pk1", "project_id": "proj1", "export_id": "ex1", "generated_at": "2026-10-23T00:00:00Z",
  "engine_profiles": [{{"id": "p1", "engine": "bevy", "engine_version": "0.20.0", "renderer_backend": "wgpu", "importer_version": "1", "coordinate_conversion": "y-up", "required_features": [], "validation_status": "verified"}}],
  "assets": [{{
    "asset_id": "a1", "stable_key": "crate", "version_id": "v1", "kind": "prop_3d", "spec_hash": "{}",
    "files": [
      {{"role": "main", "path": "models/crate.glb", "sha256": "{}", "byte_length": 10, "mime": "model/gltf-binary"}},
      {{"role": "lod", "path": "models/crate_lod1.glb", "sha256": "{}", "byte_length": 10, "mime": "model/gltf-binary"}}
    ],
    "mesh": {{
      "scene_index": 0, "unit": "meter", "up_axis": "+Y", "visual_forward": "+Z", "origin": "bottom_center",
      "measured_dimensions_m": {{"x": 1, "y": 1, "z": 1}}, "triangles": 12,
      "material_workflow": "gltf_metallic_roughness",
      "collision": {{"kind": "none", "unit": "meter"}}, {lod_json}
    }},
    "quality": {{"technical_check": {{"status": "passed", "validator_version": "t"}}, "human_review": {{"status": "passed"}}}}
  }}]
}}"#,
      "a".repeat(64),
      "b".repeat(64),
      "c".repeat(64),
    )
  }

  #[test]
  fn lod_accepts_a_valid_chain() {
    let lod = r#""lod": {"levels": [
      {"level": 1, "file_index": 1, "scene_index": 0, "triangles": 8, "switch_distance_m": 10.0, "hysteresis_m": 1.0}
    ]}"#;
    let manifest = GameAssetPackManifest::parse_and_validate(&manifest_json(lod)).expect("valid");
    let mesh = manifest.assets[0].mesh.as_ref().unwrap();
    let lod = mesh.lod.as_ref().expect("lod parsed");
    assert_eq!(lod.levels.len(), 1);
    assert_eq!(lod.levels[0].triangles, 8);
  }

  #[test]
  fn lod_rejects_out_of_range_file_index() {
    let lod = r#""lod": {"levels": [
      {"level": 1, "file_index": 5, "scene_index": 0, "triangles": 8, "switch_distance_m": 10.0, "hysteresis_m": 1.0}
    ]}"#;
    let problems = GameAssetPackManifest::parse_and_validate(&manifest_json(lod)).unwrap_err();
    assert!(problems.iter().any(|p| p.message.contains("file_index 5 outside")), "{problems:?}");
  }

  #[test]
  fn lod_rejects_descending_levels_or_distances() {
    let descending = r#""lod": {"levels": [
      {"level": 2, "file_index": 1, "scene_index": 0, "triangles": 4, "switch_distance_m": 25.0, "hysteresis_m": 0.0},
      {"level": 1, "file_index": 1, "scene_index": 0, "triangles": 8, "switch_distance_m": 10.0, "hysteresis_m": 0.0}
    ]}"#;
    let problems =
      GameAssetPackManifest::parse_and_validate(&manifest_json(descending)).unwrap_err();
    assert!(problems.iter().any(|p| p.message.contains("ascending")), "{problems:?}");

    let flat_distances = r#""lod": {"levels": [
      {"level": 1, "file_index": 1, "scene_index": 0, "triangles": 8, "switch_distance_m": 10.0, "hysteresis_m": 0.0},
      {"level": 2, "file_index": 1, "scene_index": 0, "triangles": 4, "switch_distance_m": 10.0, "hysteresis_m": 0.0}
    ]}"#;
    let problems =
      GameAssetPackManifest::parse_and_validate(&manifest_json(flat_distances)).unwrap_err();
    assert!(
      problems.iter().any(|p| p.message.contains("switch distances must increase")),
      "{problems:?}"
    );
  }

  #[test]
  fn lod_rejects_level_zero_and_oversized_hysteresis() {
    let level_zero = r#""lod": {"levels": [
      {"level": 0, "file_index": 1, "scene_index": 0, "triangles": 8, "switch_distance_m": 10.0, "hysteresis_m": 1.0}
    ]}"#;
    let problems =
      GameAssetPackManifest::parse_and_validate(&manifest_json(level_zero)).unwrap_err();
    assert!(problems.iter().any(|p| p.message.contains("start at 1")), "{problems:?}");

    let sticky = r#""lod": {"levels": [
      {"level": 1, "file_index": 1, "scene_index": 0, "triangles": 8, "switch_distance_m": 10.0, "hysteresis_m": 11.0}
    ]}"#;
    let problems = GameAssetPackManifest::parse_and_validate(&manifest_json(sticky)).unwrap_err();
    assert!(
      problems.iter().any(|p| p.message.contains("exceeds its switch distance")),
      "{problems:?}"
    );
  }

  #[test]
  fn lod_rejects_empty_block_and_bad_thresholds() {
    let empty = r#""lod": {"levels": []}"#;
    let problems = GameAssetPackManifest::parse_and_validate(&manifest_json(empty)).unwrap_err();
    assert!(problems.iter().any(|p| p.message.contains("empty lod block")), "{problems:?}");

    let zero_distance = r#""lod": {"levels": [
      {"level": 1, "file_index": 1, "scene_index": 0, "triangles": 8, "switch_distance_m": 0.0, "hysteresis_m": 0.0}
    ]}"#;
    let problems =
      GameAssetPackManifest::parse_and_validate(&manifest_json(zero_distance)).unwrap_err();
    assert!(
      problems.iter().any(|p| p.message.contains("non-positive switch distance")),
      "{problems:?}"
    );
  }
}

/// Verify every listed pack file's bytes against the manifest's sha256,
/// reading from an absolute pack root on disk. The consumer calls this
/// before/alongside catalog loading (the AssetServer itself does not
/// verify content). Returns one problem per mismatch/missing file; an
/// empty vec means the pack is byte-intact.
pub fn verify_pack_files(
  manifest: &GameAssetPackManifest,
  pack_root_abs: &str,
) -> Vec<ManifestProblem> {
  let mut problems = Vec::new();
  let mut seen = std::collections::HashSet::new();
  let mut total = 0u64;
  if manifest.assets.len() > 500 {
    return vec![ManifestProblem { message: "每份包最多接受 500 项资产。".into() }];
  }
  for asset in &manifest.assets {
    for file in &asset.files {
      if seen.insert(file.path.clone()) {
        total = total.saturating_add(file.byte_length);
        if total > 1024 * 1024 * 1024 {
          problems.push(ManifestProblem { message: "包数据超过 1 GiB。".into() });
          return problems;
        }
      }
      if let Err(problem) = verify_pack_file(pack_root_abs, file) {
        problems.push(ManifestProblem { message: format!("{}：{problem}", file.path) });
      }
    }
  }
  problems
}

fn verify_pack_file(root: &str, file: &ManifestFile) -> Result<(), String> {
  use std::io::Read;
  use sha2::{Digest, Sha256};

  if path_escapes(&file.path) || !file.path.starts_with("assets/") {
    return Err("资源路径不在包的 assets 目录。".into());
  }
  if file.byte_length == 0 || file.byte_length > 250 * 1024 * 1024 {
    return Err("资源文件为空或超过 250 MiB。".into());
  }
  let mut path = std::path::PathBuf::from(root);
  for part in file.path.split('/') {
    path.push(part);
    let metadata = std::fs::symlink_metadata(&path).map_err(|e| format!("资源无法读取：{e}"))?;
    if metadata.file_type().is_symlink() {
      return Err("资源路径包含符号链接。".into());
    }
  }
  let expected_extension = match file.mime.as_str() {
    "image/png" => "png",
    "model/gltf-binary" => "glb",
    "application/json" => "json",
    _ => return Err("只接受 PNG、GLB 和 JSON 资源数据。".into()),
  };
  if path.extension().and_then(|ext| ext.to_str()) != Some(expected_extension) {
    return Err("扩展名与资源类型不同。".into());
  }
  let metadata = std::fs::metadata(&path).map_err(|e| e.to_string())?;
  if !metadata.is_file() || metadata.len() != file.byte_length {
    return Err("文件类型或字节数与交付清单不同。".into());
  }
  crate::data_file::validate_data_file(&path, &file.mime)?;
  let mut reader = std::fs::File::open(path).map_err(|e| e.to_string())?;
  let mut digest = Sha256::new();
  let mut count = 0u64;
  let mut buffer = [0u8; 65536];
  loop {
    let length = reader.read(&mut buffer).map_err(|e| e.to_string())?;
    if length == 0 {
      break;
    }
    count += length as u64;
    if count > file.byte_length {
      return Err("校验过程中资源大小发生变化。".into());
    }
    digest.update(&buffer[..length]);
  }
  if count != file.byte_length || hex::encode(digest.finalize()) != file.sha256.to_lowercase() {
    return Err("文件内容与交付清单的 SHA-256 不同。".into());
  }
  Ok(())
}
