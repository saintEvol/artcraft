@tool
extends RefCounted
## Discover managed installations independently of the original download folder.

const Journal := preload("res://addons/game_assets/journal.gd")
const Manifest := preload("res://addons/game_assets/manifest.gd")

static func list_packs() -> Array[Dictionary]:
	var packs: Array[Dictionary] = []
	var base := DirAccess.open("res://game_assets")
	if base == null: return packs
	var directories := base.get_directories(); directories.sort()
	for directory in directories:
		if not safe_namespace(directory) or base.is_link(directory): continue
		var path := "res://game_assets/" + directory
		var input := FileAccess.open(path.path_join("manifest.json"), FileAccess.READ)
		if input == null or input.get_length() > 4 * 1024 * 1024: continue
		var manifest: Variant = JSON.parse_string(input.get_as_text())
		if not (manifest is Dictionary) or not (manifest.get("assets") is Array) or not (manifest.get("pack_id") is String) or not (manifest.get("project_id") is String): continue
		var journal := Journal.new()
		if not journal.load_from(directory): continue
		var names: Array[String] = []
		for asset in manifest.assets:
			if asset is Dictionary: names.append(String(asset.get("display_name", asset.get("stable_key", "资产"))))
		var summary := "、".join(names.slice(0, 2))
		var count := journal.entries.size()
		var copy_label := " · 副本 " + directory.right(8) if directory != manifest.project_id else ""
		packs.append({"namespace": directory, "root": path, "manifest": manifest, "count": count, "label": "%s等 %d 项%s" % [summary, count, copy_label]})
	return packs

static func safe_namespace(value: String) -> bool:
	var pattern := RegEx.new(); pattern.compile("^[a-z0-9][a-z0-9_-]{0,127}$")
	return pattern.search(value) != null
