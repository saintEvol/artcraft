@tool
extends RefCounted
## is_scanning becomes false before the scanned index is installed (Godot 4.7.2).
## filesystem_changed also covers automatic import completion; do not start a second import.

static func scan(filesystem: EditorFileSystem, tree: SceneTree) -> bool:
	var state := {"finished": false}
	var callback := func() -> void: state.finished = true
	filesystem.filesystem_changed.connect(callback)
	filesystem.scan()
	var deadline := Time.get_ticks_msec() + 60000
	while not state.finished or filesystem.is_scanning() or filesystem.is_importing():
		if Time.get_ticks_msec() >= deadline:
			filesystem.filesystem_changed.disconnect(callback)
			return false
		await tree.process_frame
	filesystem.filesystem_changed.disconnect(callback)
	return true
