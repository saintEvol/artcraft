extends Node
## Reusable real-engine showcase; all PackedScenes are export dependencies.

const Report := preload("res://addons/game_assets/engine_report.gd")
const CAMERA_ACTIONS := [
	["向左旋转", KEY_J], ["向右旋转", KEY_L], ["俯视", KEY_I], ["仰视", KEY_K],
	["放大", KEY_PLUS], ["缩小", KEY_MINUS], ["重置视角", KEY_R],
]
@export var asset_scenes: Array[PackedScene] = []
@export var manifest: Dictionary = {}
@export var catalog_assets: Array[Dictionary] = []
var _display_assets: Array = []
var _incoming_ids: Dictionary = {}
var _camera: Camera3D
var _center := Vector3.ZERO
var _distance := 6.0
var _initial_distance := 6.0
var _yaw := 0.35
var _pitch := 0.25
var _status: Label
var _results: Array = []
var _problems: Array = []
var _report_path := ""
var _return_button: Button

func _ready() -> void:
	_display_assets = catalog_assets if not catalog_assets.is_empty() else manifest.get("assets", [])
	for asset in manifest.get("assets", []): _incoming_ids[String(asset.asset_id)] = true
	var world := Node3D.new(); add_child(world)
	_camera = Camera3D.new(); world.add_child(_camera); _camera.current = true
	var light := DirectionalLight3D.new(); light.rotation_degrees = Vector3(-45, -30, 0); light.light_energy = 1.0; light.shadow_enabled = true; world.add_child(light)
	var environment := WorldEnvironment.new(); environment.environment = Environment.new()
	environment.environment.background_mode = Environment.BG_COLOR
	environment.environment.background_color = Color("242b36")
	environment.environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.environment.ambient_light_color = Color.WHITE
	environment.environment.ambient_light_energy = 0.7
	world.add_child(environment)
	var layer := CanvasLayer.new(); add_child(layer)
	var margin := MarginContainer.new(); layer.add_child(margin)
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 20)
	margin.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var column := VBoxContainer.new(); column.mouse_filter = Control.MOUSE_FILTER_IGNORE; margin.add_child(column)
	var title := Label.new(); title.text = "游戏资产 · Godot 实际运行预览"; title.add_theme_font_size_override("font_size", 24); column.add_child(title)
	var hint := Label.new(); hint.text = "使用下方按钮调整视角，也支持拖动 / 滚轮及 J、L、I、K、+、-、R。图标为 64px，模型为米制。"; hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; column.add_child(hint)
	var camera_actions := HFlowContainer.new(); column.add_child(camera_actions)
	for action in CAMERA_ACTIONS:
		var camera_button := Button.new(); camera_button.text = action[0]
		camera_button.pressed.connect(_camera_action.bind(action[1])); camera_actions.add_child(camera_button)
	var inventory := Label.new(); inventory.text = "当前安装 %d 项 · 本次包 %d 项 · 此前保留 %d 项" % [_display_assets.size(), _incoming_ids.size(), maxi(0, _display_assets.size() - _incoming_ids.size())]; column.add_child(inventory)
	var grid := GridContainer.new(); grid.columns = 6; grid.add_theme_constant_override("h_separation", 16); column.add_child(grid)
	var lane := 0.0
	if asset_scenes.size() != _display_assets.size() or asset_scenes.is_empty():
		_problems.append("场景引用数量与清单不一致。")
	for i in mini(asset_scenes.size(), _display_assets.size()):
		var asset: Dictionary = _display_assets[i]
		var outcome := {"asset_id": asset.asset_id, "version_id": asset.version_id, "status": "failed"}
		if asset_scenes[i] == null:
			outcome["problem"] = "资源无法加载：" + String(asset.get("display_name", asset.stable_key))
			_results.append(outcome); continue
		var instance := asset_scenes[i].instantiate()
		if instance.get_meta("artcraft_asset_id", "") != asset.asset_id or instance.get_meta("artcraft_version_id", "") != asset.version_id:
			outcome["problem"] = "场景内的资产身份或版本与安装目录不一致：" + String(asset.get("display_name", asset.stable_key))
			instance.free(); _results.append(outcome); continue
		var retained := not _incoming_ids.has(String(asset.asset_id))
		if instance is AnimatedSprite2D and instance.sprite_frames != null and not instance.sprite_frames.get_animation_names().is_empty():
			var animation_name: StringName = instance.sprite_frames.get_animation_names()[0]
			var first_frame: Texture2D = instance.sprite_frames.get_frame_texture(animation_name, 0) if instance.sprite_frames.get_frame_count(animation_name) > 0 else null
			if first_frame != null:
				var cell := VBoxContainer.new(); grid.add_child(cell)
				var button := TextureButton.new(); button.accessibility_name = "选择 " + String(asset.get("display_name", asset.stable_key)); button.texture_normal = first_frame
				button.ignore_texture_size = true; button.stretch_mode = TextureButton.STRETCH_KEEP_ASPECT_CENTERED
				button.custom_minimum_size = Vector2(64, 64); button.texture_filter = instance.texture_filter
				button.pressed.connect(func() -> void: _status.text = "已选择：" + String(asset.get("display_name", asset.stable_key)))
				cell.add_child(button)
				var label := Label.new(); label.text = String(asset.get("display_name", asset.stable_key)); cell.add_child(label)
				if retained:
					var source := Label.new(); source.text = "此前保留"; source.modulate = Color("b3c0d1"); cell.add_child(source)
				outcome.status = "loaded"; outcome["clip"] = String(instance.get_meta("artcraft_clip_name", ""))
			else:
				outcome["problem"] = "动画没有可显示的帧：" + String(asset.get("display_name", asset.stable_key))
			instance.free()
		elif instance is Sprite2D and instance.texture != null:
			var cell := VBoxContainer.new(); grid.add_child(cell)
			var button := TextureButton.new(); button.accessibility_name = "选择 " + String(asset.get("display_name", asset.stable_key)); button.texture_normal = instance.texture
			button.ignore_texture_size = true; button.stretch_mode = TextureButton.STRETCH_KEEP_ASPECT_CENTERED
			button.custom_minimum_size = Vector2(64, 64); button.texture_filter = instance.texture_filter
			button.pressed.connect(func() -> void: _status.text = "已选择：" + String(asset.get("display_name", asset.stable_key)))
			cell.add_child(button)
			var label := Label.new(); label.text = String(asset.get("display_name", asset.stable_key)); cell.add_child(label)
			if retained:
				var source := Label.new(); source.text = "此前保留"; source.modulate = Color("b3c0d1"); cell.add_child(source)
			outcome.status = "loaded"; outcome["pixels"] = [instance.texture.get_width(), instance.texture.get_height()]
			instance.free()
		elif instance is Node3D:
			world.add_child(instance); instance.position.x = lane
			var measured := _measure_bounds(instance)
			if measured.get("found", false):
				var bounds: AABB = measured.bounds
				outcome["measured_size_m"] = [bounds.size.x, bounds.size.y, bounds.size.z]
				_add_label(world, "%s\n实测高 %.2f m%s" % [String(asset.get("display_name", asset.stable_key)), bounds.size.y, "\n此前保留" if retained else ""], Vector3(lane, bounds.end.y + 0.25, 0))
				outcome.status = "loaded"
			elif not instance.find_children("*", "AnimationPlayer", true, false).is_empty():
				# A delivered clip has no mesh of its own; it plays on a rig.
				_add_label(world, "%s\n动画资源（搭配角色使用）%s" % [String(asset.get("display_name", asset.stable_key)), "\n此前保留" if retained else ""], Vector3(lane, 1.2, 0))
				outcome.status = "loaded"
				outcome["animation_only"] = true
			else:
				outcome["problem"] = "模型实例没有可显示的网格：" + String(asset.get("display_name", asset.stable_key))
			lane += 2.2
		else:
			outcome["problem"] = "资产没有可实例化的图像或模型：" + String(asset.stable_key); instance.free()
		_results.append(outcome)
	if lane > 0:
		var reference := MeshInstance3D.new(); reference.mesh = BoxMesh.new(); reference.mesh.size = Vector3(0.4, 1.7, 0.25)
		reference.position = Vector3(lane, 0.85, 0)
		var reference_material := StandardMaterial3D.new(); reference_material.albedo_color = Color("5798b8"); reference.material_override = reference_material
		world.add_child(reference)
		_add_label(world, "1.70 m 尺度参照\n非交付资产", Vector3(lane, 2.0, 0))
		_center = Vector3(lane / 2, 0.9, 0); _distance = maxf(5.0, lane * 1.3)
		var floor_mesh := MeshInstance3D.new(); floor_mesh.mesh = PlaneMesh.new(); floor_mesh.mesh.size = Vector2(maxf(lane * 2, 12), 12); floor_mesh.position.x = lane / 2
		var floor_material := StandardMaterial3D.new(); floor_material.albedo_color = Color("424b57"); floor_mesh.material_override = floor_material
		world.add_child(floor_mesh)
	_initial_distance = _distance
	_update_camera()
	var spacer := Control.new(); spacer.mouse_filter = Control.MOUSE_FILTER_IGNORE; spacer.size_flags_vertical = Control.SIZE_EXPAND_FILL; column.add_child(spacer)
	_status = Label.new(); _status.text = "等待全部实例进入场景并记录运行报告…"; column.add_child(_status)
	var actions := HBoxContainer.new(); column.add_child(actions)
	if bool(ProjectSettings.get_setting("game_assets/preview_project", false)) and ResourceLoader.exists("res://welcome.tscn", "PackedScene"):
		_return_button = Button.new(); _return_button.text = "返回资源选择"; _return_button.disabled = true; _return_button.pressed.connect(_return_to_selection); actions.add_child(_return_button)
	var open_report := Button.new(); open_report.text = "打开运行报告目录"; open_report.size_flags_horizontal = Control.SIZE_EXPAND_FILL; open_report.pressed.connect(func() -> void: OS.shell_open(ProjectSettings.globalize_path("user://game_assets_reports"))); actions.add_child(open_report)
	call_deferred("_save_runtime_report")

func _save_runtime_report() -> void:
	await get_tree().process_frame
	var rendered := DisplayServer.get_name() != "headless"
	for frame in 3:
		if rendered:
			await RenderingServer.frame_post_draw
		else:
			await get_tree().process_frame
	var current_results: Array = []
	var current_problems: Array = _problems.duplicate()
	for asset in manifest.get("assets", []):
		var matching := _results.filter(func(value: Dictionary) -> bool: return value.asset_id == asset.asset_id and value.version_id == asset.version_id)
		if matching.size() == 1:
			current_results.append(matching[0])
			if matching[0].status != "loaded": current_problems.append(matching[0].get("problem", "本次包中的资产未加载。"))
		else:
			current_results.append({"asset_id": asset.asset_id, "version_id": asset.version_id, "status": "failed"})
			current_problems.append("本次包的资产版本不在当前安装中：" + String(asset.get("display_name", asset.stable_key)))
	var retained_problems: Array = []
	for outcome in _results:
		if not _incoming_ids.has(String(outcome.asset_id)) and outcome.status != "loaded": retained_problems.append(outcome.get("problem", "此前保留的资产未加载。"))
	var loaded_count := _results.filter(func(value: Dictionary) -> bool: return value.status == "loaded").size()
	_status.text = "工程已加载 %d / %d 项；正在保存本次包 %d 项的运行报告…" % [loaded_count, _display_assets.size(), current_results.size()]
	# Render the status before taking the evidence frame.
	if rendered: await RenderingServer.frame_post_draw
	var report := Report.create(manifest, "runtime", "failed" if not current_problems.is_empty() else "succeeded" if rendered else "loaded", current_results, current_problems)
	report["installed_asset_count"] = _display_assets.size()
	report["retained_asset_count"] = maxi(0, _display_assets.size() - _incoming_ids.size())
	report["retained_problems"] = retained_problems
	report.rendered = rendered
	if rendered:
		var screenshot := "user://game_assets_reports/%s-preview-%s.png" % [String(manifest.get("pack_id", "preview")).validate_filename(), Time.get_unix_time_from_system()]
		DirAccess.make_dir_recursive_absolute(screenshot.get_base_dir())
		if get_viewport().get_texture().get_image().save_png(screenshot) == OK:
			report["preview_image"] = screenshot
			report["preview_image_sha256"] = FileAccess.get_sha256(screenshot)
		else:
			report.problems.append("无法保存渲染图像。"); report.status = "failed"
	_report_path = "user://game_assets_reports/%s_runtime_%s.json" % [String(manifest.get("pack_id", "unknown")).validate_filename(), Time.get_unix_time_from_system()]
	var saved := Report.save(report, _report_path)
	if saved:
		_status.text = "本次包 %d 项的报告已保存；工程已加载 %d / %d 项，另有 %d 项此前保留的资产需检查。" % [current_results.size(), loaded_count, _display_assets.size(), retained_problems.size()]
	else:
		_status.text = "运行报告未能写入，请检查工程的数据目录。"
	if _return_button != null: _return_button.disabled = false
	if OS.get_cmdline_user_args().has("--exit-after-report"):
		get_tree().quit(0 if saved and report.status != "failed" else 1)

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion:
		var motion := drag_motion(event)
		if motion != Vector2.ZERO:
			_yaw -= motion.x * 0.008; _pitch = clampf(_pitch - motion.y * 0.008, -1.2, 1.2); _update_camera()
	elif event is InputEventMouseButton and event.pressed:
		if event.button_index == MOUSE_BUTTON_WHEEL_UP: _distance = maxf(0.5, _distance * 0.85)
		elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN: _distance *= 1.15
		_update_camera()
	elif event is InputEventKey and event.pressed and not event.echo:
		_camera_action(event.keycode)

func _camera_action(keycode: int) -> void:
	match keycode:
		KEY_J: _yaw -= 0.2
		KEY_L: _yaw += 0.2
		KEY_I: _pitch = clampf(_pitch + 0.15, -1.2, 1.2)
		KEY_K: _pitch = clampf(_pitch - 0.15, -1.2, 1.2)
		KEY_PLUS, KEY_EQUAL, KEY_KP_ADD: _distance = maxf(0.5, _distance * 0.85)
		KEY_MINUS, KEY_KP_SUBTRACT: _distance *= 1.15
		KEY_R: _yaw = 0.35; _pitch = 0.25; _distance = _initial_distance
		_: return
	_update_camera()

func _update_camera() -> void:
	_camera.position = _center + Vector3(sin(_yaw) * cos(_pitch), sin(_pitch), cos(_yaw) * cos(_pitch)) * _distance
	_camera.look_at(_center)

func _add_label(world: Node3D, text: String, position: Vector3) -> void:
	var label := Label3D.new(); label.text = text; label.font_size = 40; label.pixel_size = 0.005
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED; label.no_depth_test = true
	label.position = position; world.add_child(label)

func _measure_bounds(root: Node3D) -> Dictionary:
	var result := {"found": false, "bounds": AABB()}
	for child in root.get_children(): _collect_bounds(child, Transform3D.IDENTITY, result)
	return result

func _collect_bounds(node: Node, parent_transform: Transform3D, result: Dictionary) -> void:
	var transform := parent_transform
	if node is Node3D: transform = parent_transform * node.transform
	if node is MeshInstance3D and node.mesh != null and node.mesh.get_surface_count() > 0:
		var bounds: AABB = transform * node.mesh.get_aabb()
		result.bounds = result.bounds.merge(bounds) if result.found else bounds
		result.found = true
	for child in node.get_children(): _collect_bounds(child, transform, result)

## Mouse events can be delivered after the global button state has changed.
static func drag_motion(event: InputEventMouseMotion) -> Vector2:
	return event.relative if (event.button_mask & MOUSE_BUTTON_MASK_LEFT) != 0 else Vector2.ZERO

func _return_to_selection() -> void:
	ProjectSettings.set_setting("game_assets/session_preview_namespace", scene_file_path.get_base_dir().get_file())
	get_tree().change_scene_to_file("res://welcome.tscn")
