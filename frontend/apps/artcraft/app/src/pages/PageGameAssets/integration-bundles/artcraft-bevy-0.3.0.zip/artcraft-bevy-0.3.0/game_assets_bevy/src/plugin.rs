//! Plugin wiring (plan 15.2): registers resources and the state-refresh
//! system. Deliberately minimal — no global renderer/plugin defaults are
//! touched (per-asset sampling instead of ImagePlugin changes).

use bevy::asset::AssetApp;
use bevy::prelude::*;

use crate::catalog::{GameAssetCatalog, GameAssetLoadStateTracker};

pub struct GameAssetPackPlugin;

impl Plugin for GameAssetPackPlugin {
  fn build(&self, app: &mut App) {
    app
      .init_asset::<crate::json_asset::JsonAsset>()
      .init_asset_loader::<crate::json_asset::JsonAssetLoader>()
      .init_asset::<TextureAtlasLayout>()
      .init_resource::<GameAssetCatalog>()
      .init_resource::<GameAssetLoadStateTracker>()
      .add_systems(
        PreUpdate,
        (
          crate::sprite_images::invalidate_source_images,
          crate::sprite_images::prepare_sprite_images,
          crate::catalog::prepare_animation_assets,
          refresh_load_states,
          crate::instances::sync_instances,
        )
          .chain(),
      )
      .add_systems(
        PostUpdate,
        (
          crate::animation_binding::bind_character_rigs,
          crate::animation_binding::sync_animation_3d_playback,
          crate::animation_2d::advance_game_animation_2d,
        )
          .chain(),
      );
  }
}

fn refresh_load_states(
  mut tracker: ResMut<GameAssetLoadStateTracker>,
  catalog: Res<GameAssetCatalog>,
  asset_server: Res<AssetServer>,
) {
  tracker.update(&catalog, &asset_server);
}
