@tool
extends Control

const Importer := preload("res://addons/game_assets/importer.gd")
const Builder := preload("res://addons/game_assets/resource_builder.gd")
const Report := preload("res://addons/game_assets/engine_report.gd")
const EditorResources := preload("res://addons/game_assets/editor_resources.gd")

var _path: LineEdit
var _log: RichTextLabel
var _decision: OptionButton
var _importer
var _preview := ""
var _last_report: Dictionary = {}
var _busy := false

func _ready() -> void:
	var layout := VBoxContainer.new(); add_child(layout); layout.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var title := Label.new(); title.text = "游戏资产 · 导入与更新"; layout.add_child(title)
	_path = LineEdit.new(); _path.placeholder_text = "解压后包含 manifest.json 的目录"; layout.add_child(_path)
	_path.text = String(EditorInterface.get_editor_settings().get_project_metadata("game_assets", "pack_directory", ""))
	var browse := Button.new(); browse.text = "选择资源包目录"; browse.pressed.connect(_browse); layout.add_child(browse)
	var preflight := Button.new(); preflight.text = "核对清单与更新差异"; preflight.pressed.connect(_preflight); layout.add_child(preflight)
	_decision = OptionButton.new(); _decision.fit_to_longest_item = false
	_decision.add_item("有冲突时停止，不覆盖", 0)
	_decision.add_item("保留当前，不应用更新", 1)
	_decision.add_item("另存副本，保留原引用", 2)
	_decision.add_item("备份后替换受管理文件", 3)
	layout.add_child(_decision)
	var apply := Button.new(); apply.text = "导入这份包 / 应用更新"; apply.pressed.connect(_import); layout.add_child(apply)
	var preview := Button.new(); preview.text = "打开资产预览"; preview.pressed.connect(_open_preview); layout.add_child(preview)
	var save := Button.new(); save.text = "保存导入报告"; save.pressed.connect(_save_report); layout.add_child(save)
	_log = RichTextLabel.new(); _log.bbcode_enabled = false; _log.custom_minimum_size.y = 140; _log.size_flags_vertical = Control.SIZE_EXPAND_FILL; layout.add_child(_log)
	_log.text = "先核对包，再导入。场景写入 game_assets 管理目录，自定义游戏节点请放在自己的场景中。"
	if not _path.text.is_empty(): call_deferred("_preflight")

func _browse() -> void:
	var dialog := FileDialog.new(); dialog.file_mode = FileDialog.FILE_MODE_OPEN_DIR; dialog.access = FileDialog.ACCESS_FILESYSTEM
	dialog.dir_selected.connect(func(path: String) -> void: _path.text = path; dialog.queue_free())
	add_child(dialog); dialog.popup_centered(Vector2i(900, 600))

func _preflight() -> void:
	if _busy: return
	_importer = Importer.new()
	_preview = ""; _last_report = {}
	var ok: bool = _importer.preflight(_path.text.strip_edges())
	_log.clear()
	if not ok:
		_show_failure("核对未通过"); return
	EditorInterface.get_editor_settings().set_project_metadata("game_assets", "pack_directory", _path.text.strip_edges())
	var plan: Dictionary = _importer.plan
	var names: Dictionary = {}
	for asset in _importer.manifest_data.assets:
		names[String(asset.stable_key)] = String(asset.get("display_name", asset.stable_key))
	for kind in ["new", "updated", "unchanged", "conflicts", "missing"]:
		_log.append_text("%s：%s\n" % [{"new":"新增", "updated":"更新", "unchanged":"保持", "conflicts":"本地修改冲突", "missing":"本次未包含，保留原文件"}[kind], ", ".join((plan[kind] as Array).map(func(key: String) -> String: return names.get(key, key)))])
	var installed_path: String = _importer.managed_root.path_join("manifest.json")
	if FileAccess.file_exists(installed_path):
		var installed: Variant = JSON.parse_string(FileAccess.get_file_as_string(installed_path))
		if installed is Dictionary and installed.get("pack_id") == _importer.manifest_data.get("pack_id") and FileAccess.file_exists(_importer.managed_root.path_join("preview.tscn")):
			_preview = _importer.managed_root.path_join("preview.tscn")
			_log.append_text("这份包已在当前工程中，可直接打开资产预览。\n")
	var last_path := String(EditorInterface.get_editor_settings().get_project_metadata("game_assets", "last_report", ""))
	if not last_path.is_empty() and FileAccess.file_exists(last_path):
		var saved := FileAccess.open(last_path, FileAccess.READ)
		if saved != null and saved.get_length() <= 2 * 1024 * 1024:
			var previous_report: Variant = JSON.parse_string(saved.get_as_text())
			if previous_report is Dictionary and previous_report.get("pack_id") == _importer.manifest_data.get("pack_id"):
				_last_report = previous_report

func _import() -> void:
	if _busy: return
	_busy = true; _log.text = "正在核对并准备资源…"
	_importer = Importer.new()
	var decisions := ["cancel", "keep", "copy", "replace"]
	if not _importer.import_pack(_path.text.strip_edges(), decisions[_decision.selected]):
		_show_failure("导入未完成"); return
	EditorInterface.get_editor_settings().set_project_metadata("game_assets", "pack_directory", _path.text.strip_edges())
	if _importer.result.get("kept_current", false):
		_last_report = _importer.result; _remember_report(); _log.text = "已保留工程当前全部版本，没有应用本次更新。可保存这次结果报告。"; _busy = false; return
	var filesystem := EditorInterface.get_resource_filesystem()
	if not await EditorResources.scan(filesystem, get_tree()):
		_importer.rollback(); _show_failure("资源扫描超时，已请求恢复原文件", ["Godot 资源扫描超过 60 秒，请检查编辑器导入错误后重试。"]); return
	var files: PackedStringArray = []
	for asset in _importer.manifest_data.assets:
		for entry in asset.files:
			if String(entry.path).get_extension() in ["png", "glb"]:
				files.append(_importer.managed_root.path_join(String(entry.path)))
	if not await EditorResources.reimport(filesystem, get_tree(), files):
		_importer.rollback(); _show_failure("引擎导入超时，已请求恢复原文件", ["Godot 资源导入超过 60 秒，请检查编辑器导入错误后重试。"]); return
	var builder := Builder.new()
	if not builder.build(_importer.manifest_data, _importer.managed_root, _importer.managed_namespace):
		_importer.rollback(); _show_failure("引擎导入或场景生成失败，已请求恢复原文件", builder.problems); return
	if not _importer.finish_import():
		_importer.rollback(); _show_failure("完成记录未保存，已请求恢复原文件"); return
	_preview = builder.preview_path; _last_report = _importer.result
	_remember_report()
	filesystem.scan()
	_log.text = "已完成。资产场景位于 %s/scenes，可拖进自己的场景。\n点击打开资产预览，实际运行后再保存运行报告。" % _importer.managed_root
	_busy = false

func _show_failure(message: String, extra: PackedStringArray = []) -> void:
	_last_report = _importer.failure_report(extra)
	if not String(_last_report.get("pack_id", "")).is_empty(): _remember_report()
	_log.text = message + "：\n" + "\n".join(_importer.report) + "\n当前结果可用“保存导入报告”保存。"
	_busy = false

func _remember_report() -> void:
	var path := "user://game_assets_reports/import-%s-%s.json" % [Time.get_unix_time_from_system(), Crypto.new().generate_random_bytes(4).hex_encode()]
	if Report.save(_last_report, path):
		EditorInterface.get_editor_settings().set_project_metadata("game_assets", "last_report", path)

func _open_preview() -> void:
	if _busy: return
	if _preview.is_empty(): _log.text = "请先成功导入本次资源包。"; return
	EditorInterface.open_scene_from_path(_preview)
	EditorInterface.play_custom_scene(_preview)

func _save_report() -> void:
	if _last_report.is_empty(): _log.text = "先核对并导入一份资源包，才能保存其结果。"; return
	var dialog := FileDialog.new(); dialog.file_mode = FileDialog.FILE_MODE_SAVE_FILE; dialog.access = FileDialog.ACCESS_FILESYSTEM
	dialog.add_filter("*.json", "引擎报告"); dialog.current_file = "game-assets-import-report.json"
	dialog.file_selected.connect(func(path: String) -> void: _log.text = "报告已保存。" if Report.save(_last_report, path) else "报告未保存，请重试。"; dialog.queue_free())
	add_child(dialog); dialog.popup_centered(Vector2i(900, 600))
