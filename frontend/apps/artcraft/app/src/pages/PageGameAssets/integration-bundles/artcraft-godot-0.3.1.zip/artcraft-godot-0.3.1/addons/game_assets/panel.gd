@tool
extends Control

const InstalledBrowser := preload("res://addons/game_assets/installed_browser.gd")
const InstalledPacks := preload("res://addons/game_assets/installed_packs.gd")
const ImportLock := preload("res://addons/game_assets/import_lock.gd")
const Importer := preload("res://addons/game_assets/importer.gd")
const Builder := preload("res://addons/game_assets/resource_builder.gd")
const Report := preload("res://addons/game_assets/engine_report.gd")
const EditorResources := preload("res://addons/game_assets/editor_resources.gd")

var _browser
var _tabs: TabContainer
var _selected_installation: Dictionary = {}
var _controls: Array[Control] = []
var _target: OptionButton
var _installations: Array[Dictionary] = []
var _path: LineEdit
var _log: RichTextLabel
var _decision: OptionButton
var _importer
var _preview := ""
var _last_report: Dictionary = {}
var _busy := false

func _ready() -> void:
	_tabs = TabContainer.new(); add_child(_tabs); _tabs.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var installed := ScrollContainer.new(); installed.name = "已安装资产"; installed.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED; _tabs.add_child(installed)
	_browser = InstalledBrowser.new(); _browser.size_flags_horizontal = Control.SIZE_EXPAND_FILL; installed.add_child(_browser)
	_browser.selection_changed.connect(_select_installation)
	_browser.preview_requested.connect(func(path: String) -> void: _preview = path; _open_preview())
	var scroll := ScrollContainer.new(); scroll.name = "导入或更新"; _tabs.add_child(scroll)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	var layout := VBoxContainer.new(); scroll.add_child(layout); layout.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var title := Label.new(); title.text = "游戏资产 · 导入与更新"; layout.add_child(title)
	_path = LineEdit.new(); _path.placeholder_text = "解压后包含 manifest.json 的目录"; _path.accessibility_name = "资源包解压目录"; layout.add_child(_path)
	_path.text = String(EditorInterface.get_editor_settings().get_project_metadata("game_assets", "pack_directory", ""))
	var browse := Button.new(); browse.text = "选择资源包目录"; browse.pressed.connect(_browse); layout.add_child(browse)
	var preflight := Button.new(); preflight.text = "核对清单与更新差异"; preflight.pressed.connect(_preflight); layout.add_child(preflight)
	_decision = OptionButton.new(); _decision.fit_to_longest_item = false; _decision.accessibility_name = "冲突处理方式"
	_decision.add_item("有冲突时停止，不覆盖", 0)
	_decision.add_item("保留当前，不应用更新", 1)
	_decision.add_item("另存副本，保留原引用", 2)
	_decision.add_item("备份后替换受管理文件", 3)
	layout.add_child(_decision)
	var target_title := Label.new(); target_title.text = "导入 / 更新的位置"; layout.add_child(target_title)
	_target = OptionButton.new(); _target.fit_to_longest_item = false; _target.accessibility_name = "导入或更新位置"; layout.add_child(_target)
	var recover := Button.new(); recover.text = "恢复已中断的导入"; recover.pressed.connect(_recover_interrupted); layout.add_child(recover)
	var apply := Button.new(); apply.text = "导入这份包 / 应用更新"; apply.pressed.connect(_import); layout.add_child(apply)
	var preview := Button.new(); preview.text = "打开资产预览"; preview.pressed.connect(_open_preview); layout.add_child(preview)
	var save := Button.new(); save.text = "保存导入报告"; save.pressed.connect(_save_report); layout.add_child(save)
	_controls = [_path, browse, preflight, _decision, _target, recover, apply, preview, save]
	_log = RichTextLabel.new(); _log.bbcode_enabled = false; _log.custom_minimum_size.y = 160; _log.size_flags_vertical = Control.SIZE_EXPAND_FILL; layout.add_child(_log)
	_log.text = "先核对包，再导入。场景写入 game_assets 管理目录，自定义游戏节点请放在自己的场景中。"
	_refresh_installed()
	_tabs.current_tab = 0 if not _installations.is_empty() else 1

func _browse() -> void:
	var dialog := FileDialog.new(); dialog.file_mode = FileDialog.FILE_MODE_OPEN_DIR; dialog.access = FileDialog.ACCESS_FILESYSTEM
	dialog.dir_selected.connect(func(path: String) -> void: _path.text = path; dialog.queue_free())
	add_child(dialog); dialog.popup_centered(Vector2i(900, 600))

func _preflight() -> void:
	if _busy: return
	_importer = Importer.new()
	_preview = ""; _last_report = {}
	var ok: bool = _importer.preflight(_path.text.strip_edges(), _target_namespace())
	_log.clear()
	if not ok:
		_show_failure("核对未通过"); return
	EditorInterface.get_editor_settings().set_project_metadata("game_assets", "pack_directory", _path.text.strip_edges())
	var plan: Dictionary = _importer.plan
	var names: Dictionary = {}
	var journal := preload("res://addons/game_assets/journal.gd").new()
	if journal.load_from(_importer.managed_namespace):
		for entry in journal.entries.values(): names[String(entry.stable_key)] = String(entry.get("display_name", entry.stable_key))
	for asset in _importer.manifest_data.assets:
		names[String(asset.stable_key)] = String(asset.get("display_name", asset.stable_key))
	for kind in ["new", "updated", "unchanged", "conflicts", "missing"]:
		_log.append_text("%s：%s\n" % [{"new":"新增", "updated":"更新", "unchanged":"保持", "conflicts":"本地修改冲突", "missing":"本次未包含，保留原文件"}[kind], ", ".join((plan[kind] as Array).map(func(key: String) -> String: return names.get(key, key)))])
	var installed_path: String = _importer.managed_root.path_join("manifest.json")
	if FileAccess.file_exists(installed_path):
		var installed: Variant = JSON.parse_string(FileAccess.get_file_as_string(installed_path))
		if installed is Dictionary and installed.get("pack_id") == _importer.manifest_data.get("pack_id") and FileAccess.file_exists(_importer.managed_root.path_join("preview.tscn")):
			_preview = _importer.managed_root.path_join("preview.tscn")
			_log.append_text("这份包已在当前工程中，可直接打开资产预览。\n")
	var last_path := String(EditorInterface.get_editor_settings().get_project_metadata("game_assets", "last_report", ""))
	if not last_path.is_empty() and FileAccess.file_exists(last_path):
		var saved := FileAccess.open(last_path, FileAccess.READ)
		if saved != null and saved.get_length() <= 2 * 1024 * 1024:
			var previous_report: Variant = JSON.parse_string(saved.get_as_text())
			if previous_report is Dictionary and previous_report.get("pack_id") == _importer.manifest_data.get("pack_id"):
				_last_report = previous_report

func _import() -> void:
	if _busy: return
	_set_busy(true); _log.text = "正在核对并准备资源…"
	_importer = Importer.new()
	var decisions := ["cancel", "keep", "copy", "replace"]
	if not _importer.import_pack(_path.text.strip_edges(), decisions[_decision.selected], _target_namespace()):
		_show_failure("导入未完成"); return
	EditorInterface.get_editor_settings().set_project_metadata("game_assets", "pack_directory", _path.text.strip_edges())
	if _importer.result.get("kept_current", false):
		_last_report = _importer.result; _remember_report(); _log.text = "已保留工程当前全部版本，没有应用本次更新。可保存这次结果报告。"; _set_busy(false); return
	var filesystem := EditorInterface.get_resource_filesystem()
	if not await EditorResources.scan(filesystem, get_tree()):
		_importer.rollback(); _show_failure("资源扫描超时，已请求恢复原文件", ["Godot 资源扫描超过 60 秒，请检查编辑器导入错误后重试。"]); return
	var builder := Builder.new()
	if not builder.build(_importer.manifest_data, _importer.managed_root, _importer.managed_namespace, _importer.plan.unchanged.filter(func(key: String) -> bool: return not _importer.plan.conflicts.has(key))):
		_importer.rollback(); _show_failure("引擎导入或场景生成失败，已请求恢复原文件", builder.problems); return
	if not _importer.finish_import():
		_importer.rollback(); _show_failure("完成记录未保存，已请求恢复原文件"); return
	_preview = builder.preview_path; _last_report = _importer.result
	_remember_report()
	_set_busy(false)
	_refresh_installed(_importer.managed_namespace)
	filesystem.scan()
	_log.text = "已完成。资产场景位于 %s/scenes，可拖进自己的场景。\n点击打开资产预览，实际运行后再保存运行报告。" % _importer.managed_root
	_set_busy(false)

func _show_failure(message: String, extra: PackedStringArray = []) -> void:
	_last_report = _importer.failure_report(extra)
	if not String(_last_report.get("pack_id", "")).is_empty(): _remember_report()
	_log.text = message + "：\n" + "\n".join(_importer.report)
	_log.text += "\n当前结果可用“保存导入报告”保存。" if not String(_last_report.get("pack_id", "")).is_empty() else "\n尚不能识别资源包身份，没有生成可上传的报告。"
	_set_busy(false)

func _remember_report() -> void:
	var path := "user://game_assets_reports/import-%s-%s.json" % [Time.get_unix_time_from_system(), Crypto.new().generate_random_bytes(4).hex_encode()]
	if Report.save(_last_report, path):
		EditorInterface.get_editor_settings().set_project_metadata("game_assets", "last_report", path)
		if _importer != null and not String(_importer.managed_namespace).is_empty():
			EditorInterface.get_editor_settings().set_project_metadata("game_assets", "report_" + _importer.managed_namespace, path)
			EditorInterface.get_editor_settings().set_project_metadata("game_assets", "report_" + _importer.managed_namespace + "_" + String(_last_report.pack_id), path)

func _open_preview() -> void:
	if _busy: return
	if _preview.is_empty(): _log.text = "请先成功导入本次资源包。"; return
	EditorInterface.open_scene_from_path(_preview)
	EditorInterface.play_custom_scene(_preview)

func _save_report() -> void:
	if _last_report.is_empty() or String(_last_report.get("pack_id", "")).is_empty(): _log.text = "先核对并导入一份资源包，才能保存其结果。"; return
	var dialog := FileDialog.new(); dialog.file_mode = FileDialog.FILE_MODE_SAVE_FILE; dialog.access = FileDialog.ACCESS_FILESYSTEM
	dialog.add_filter("*.json", "引擎报告"); dialog.current_file = "game-assets-import-report.json"
	dialog.file_selected.connect(func(path: String) -> void: _log.text = "报告已保存。" if Report.save(_last_report, path) else "报告未保存，请重试。"; dialog.queue_free())
	add_child(dialog); dialog.popup_centered(Vector2i(900, 600))

func _refresh_installed(preferred: String = "") -> void:
	_installations = InstalledPacks.list_packs()
	_target.clear(); _target.add_item("按资源包项目自动选择（默认）"); _target.set_item_metadata(0, "")
	for index in _installations.size():
		var installation: Dictionary = _installations[index]
		_target.add_item(installation.label); _target.set_item_metadata(index + 1, installation.namespace)
	var saved := preferred if not preferred.is_empty() else String(EditorInterface.get_editor_settings().get_project_metadata("game_assets", "selected_installation", ""))
	_browser.refresh(_installations, saved)

func _select_installation(installation: Dictionary) -> void:
	if _busy: return
	_selected_installation = installation
	if installation.is_empty(): return
	var candidate := String(installation.root).path_join("preview.tscn")
	_preview = candidate if FileAccess.file_exists(candidate) else ""; _last_report = {}
	var settings := EditorInterface.get_editor_settings()
	settings.set_project_metadata("game_assets", "selected_installation", installation.namespace)
	for index in _target.item_count:
		if _target.get_item_metadata(index) == installation.namespace: _target.select(index)
	var fallback := settings.get_project_metadata("game_assets", "report_" + String(installation.namespace), settings.get_project_metadata("game_assets", "last_report", ""))
	var report_path := String(settings.get_project_metadata("game_assets", "report_" + String(installation.namespace) + "_" + String(installation.manifest.pack_id), fallback))
	var report_file := FileAccess.open(report_path, FileAccess.READ) if not report_path.is_empty() else null
	if report_file != null and report_file.get_length() <= 2 * 1024 * 1024:
		var saved: Variant = JSON.parse_string(report_file.get_as_text())
		if saved is Dictionary and saved.get("pack_id") == installation.manifest.pack_id: _last_report = saved
	_log.text = "当前安装：%s\n更新的位置：%s" % [installation.label, installation.root]

func _set_busy(value: bool) -> void:
	_busy = value
	_tabs.set_tab_disabled(0, value)
	for control in _controls:
		if control is BaseButton: control.disabled = value
		elif control is LineEdit: control.editable = not value

func _target_namespace() -> String:
	return String(_target.get_item_metadata(_target.selected)) if _target.selected >= 0 else ""

func _recover_interrupted() -> void:
	if _busy: return
	var lock := ImportLock.new()
	if not lock.recover_abandoned(): _log.text = lock.problem; return
	_log.text = "已检查导入锁。现在可重新核对并导入；组件会先恢复中断事务，再准备新包。"
