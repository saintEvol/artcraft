@tool
extends RefCounted
## An atomic project-wide claim covers recovery, disk swaps and Godot scanning.
## Never recover a transaction while another importer can still be using it.

const DIRECTORY := "res://game_assets/.artcraft-import-lock"
const OWNER := DIRECTORY + "/owner.json"
var problem := ""
var _token := ""

func acquire() -> bool:
	var project := DirAccess.open("res://")
	if project == null or project.is_link("game_assets"):
		problem = "游戏资产目录不可用或位于符号链接下，未开始导入。"; return false
	if DirAccess.make_dir_recursive_absolute(DIRECTORY.get_base_dir()) != OK:
		problem = "无法建立游戏资产管理目录。"; return false
	if DirAccess.make_dir_absolute(DIRECTORY) != OK:
		var owner := _read_owner()
		if not owner.is_empty() and _owner_state(int(owner.get("pid", -1))) != 0:
			problem = "另一个导入仍在进行（进程 %s）。请等待完成，再核对或导入。" % owner.pid
		else:
			problem = "发现未释放的导入锁。确认先前导入已退出后，点击“恢复已中断的导入”，再重试。"
		return false
	_token = Crypto.new().generate_random_bytes(16).hex_encode()
	var ignore := FileAccess.open(DIRECTORY.path_join(".gdignore"), FileAccess.WRITE)
	var owner := FileAccess.open(OWNER, FileAccess.WRITE)
	if ignore == null or owner == null:
		if ignore != null: ignore.close()
		if owner != null: owner.close()
		problem = "无法保存导入锁，未开始写入资产。"; _remove_files(); _token = ""; return false
	ignore.store_string("# Artcraft import lock\n"); ignore.close()
	owner.store_string(JSON.stringify({"pid": OS.get_process_id(), "token": _token})); owner.flush(); owner.close()
	return true

func is_held() -> bool:
	return not _token.is_empty()

func release() -> void:
	if _token.is_empty(): return
	var owner := _read_owner()
	if owner.get("token") == _token: _remove_files()
	_token = ""

## Explicit recovery only. A live process or incomplete claim is never removed.
func recover_abandoned() -> bool:
	var base := DirAccess.open("res://")
	var parent := DirAccess.open(DIRECTORY.get_base_dir())
	if base == null or base.is_link("game_assets") or (parent != null and parent.is_link(DIRECTORY.get_file())):
		problem = "导入锁位于符号链接下，未修改它的文件。"; return false
	if not DirAccess.dir_exists_absolute(DIRECTORY): return true
	var owner := _read_owner()
	if owner.is_empty():
		problem = "导入锁记录不完整，无法自动判断是否仍在写入。请关闭该工程的其他 Godot 进程，人工核对 %s。" % ProjectSettings.globalize_path(DIRECTORY)
		return false
	if _owner_state(int(owner.get("pid", -1))) != 0:
		problem = "记录中的导入进程仍在运行，不能恢复或移除它的锁。"; return false
	# Recovery is an explicit, user initiated operation; acquisition still uses atomic mkdir.
	return _remove_files()

func _read_owner() -> Dictionary:
	var file := FileAccess.open(OWNER, FileAccess.READ)
	if file == null or file.get_length() > 4096: return {}
	var parsed: Variant = JSON.parse_string(file.get_as_text())
	if not (parsed is Dictionary) or not (parsed.get("pid") is float or parsed.get("pid") is int) or int(parsed.pid) <= 0 or not (parsed.get("token") is String): return {}
	return parsed

func _remove_files() -> bool:
	for path in [OWNER, DIRECTORY.path_join(".gdignore")]:
		if FileAccess.file_exists(path) and DirAccess.remove_absolute(path) != OK: return false
	return DirAccess.remove_absolute(DIRECTORY) == OK

## Godot's Unix is_process_running only tracks children created by this instance.
## Read the OS process table instead; unknown outcomes always retain the lock.
func _owner_state(pid: int) -> int:
	if pid <= 0: return -1
	if pid == OS.get_process_id(): return 1
	var output: Array = []
	if OS.get_name() in ["macOS", "Linux", "FreeBSD", "NetBSD", "OpenBSD"]:
		var status := OS.execute("/bin/ps", PackedStringArray(["-p", str(pid), "-o", "pid="]), output)
		var text := "".join(output).strip_edges()
		if status == 0 and text == str(pid): return 1
		if status == 1 and text.is_empty(): return 0
	elif OS.get_name() == "Windows":
		var executable := OS.get_environment("SystemRoot").path_join("System32/tasklist.exe")
		var status := OS.execute(executable, PackedStringArray(["/FI", "PID eq " + str(pid), "/FO", "CSV", "/NH"]), output)
		if status == 0:
			var pattern := RegEx.new(); pattern.compile('^"[^"]*","' + str(pid) + '",')
			for line in "".join(output).split("\n"):
				if pattern.search(line.strip_edges()) != null: return 1
			return 0
	return -1
