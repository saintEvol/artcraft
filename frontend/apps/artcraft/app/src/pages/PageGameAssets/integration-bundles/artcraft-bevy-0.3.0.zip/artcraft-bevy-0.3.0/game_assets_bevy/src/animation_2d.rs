//! 2D animation playback (plan sections 8.3 / 12.2).
//!
//! The frozen frame table (`game.anim2d.frames.v1`) is the single source
//! for canvas/anchor/fps/loop/directions. Frames live in ONE extruded
//! atlas PNG with arbitrary per-frame rects — never treated as an evenly
//! divided grid — so the layout is built by pushing each rect instead of
//! `TextureAtlasLayout::from_grid`.

use bevy::image::TextureAtlasLayout;
use bevy::math::{URect, UVec2};
use bevy::prelude::*;

use crate::catalog::GameAssetCatalog;
use crate::GameAssetId;

/// Consumer-side frame table (game.anim2d.frames.v1). The exporter's
/// schema is frozen; this mirrors the playback-relevant subset.
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct FrameTable {
  pub schema_version: String,
  pub clip_name: String,
  pub canvas: FrameDimensions,
  pub anchor: FrameAnchor,
  pub atlas: FrameAtlas,
  pub fps: f64,
  #[serde(rename = "loop")]
  pub looping: bool,
  pub directions: Vec<FrameDirection>,
}

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct FrameDimensions {
  pub width: u32,
  pub height: u32,
}

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct FrameAnchor {
  pub origin: String,
  pub x: f64,
  pub y: f64,
}

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct FrameAtlas {
  pub role: String,
  pub ordinal: u64,
  pub width: u32,
  pub height: u32,
  pub extrude_px: u32,
}

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct FrameDirection {
  pub name: String,
  pub frames: Vec<FrameRect>,
}

#[derive(Debug, Clone, Copy, serde::Serialize, serde::Deserialize)]
pub struct FrameRect {
  pub x: u32,
  pub y: u32,
  pub width: u32,
  pub height: u32,
}

impl FrameRect {
  fn to_urect(self) -> URect {
    URect::new(self.x, self.y, self.x + self.width, self.y + self.height)
  }
}

/// Budgets shared with the pack data gate (data_file.rs).
const MAX_ATLAS_EDGE: u32 = 8192;
const MAX_TOTAL_FRAMES: usize = 4096;

impl FrameTable {
  /// Parse and validate the playback-relevant contract: direction/frame
  /// completeness, equal frame counts, rects inside the atlas with the
  /// extrusion margin, positive timing and a usable anchor.
  pub fn parse(value: &serde_json::Value) -> Result<Self, String> {
    if value.get("schema_version").and_then(serde_json::Value::as_str) != Some("game.anim2d.frames.v1")
    {
      return Err("帧表 schema_version 不是 game.anim2d.frames.v1。".into());
    }
    let table: FrameTable = serde_json::from_value(value.clone())
      .map_err(|error| format!("帧表无法解析：{error}"))?;
    table.validate().map_err(|problem| format!("帧表 {} 不合法：{problem}", table.clip_name))?;
    Ok(table)
  }

  fn validate(&self) -> Result<(), &'static str> {
    if !self.fps.is_finite() || self.fps <= 0.0 {
      return Err("fps 必须为正。");
    }
    if !(0.0..=1.0).contains(&self.anchor.x) || !(0.0..=1.0).contains(&self.anchor.y) {
      return Err("anchor 必须在 [0,1]。");
    }
    if self.anchor.origin != "top_left" {
      return Err("anchor 原点合同只支持 top_left。");
    }
    if self.canvas.width == 0
      || self.canvas.height == 0
      || self.atlas.width == 0
      || self.atlas.height == 0
      || self.atlas.width > MAX_ATLAS_EDGE
      || self.atlas.height > MAX_ATLAS_EDGE
      || self.atlas.role != "main"
      || self.atlas.ordinal != 0
      || self.atlas.extrude_px != 1
    {
      return Err("图集声明不满足冻结网格算法。");
    }
    let Some(first) = self.directions.first() else {
      return Err("缺少方向。");
    };
    let count = first.frames.len();
    if count == 0 || count > MAX_TOTAL_FRAMES {
      return Err("每方向帧数为 0 或超过预算。");
    }
    for direction in &self.directions {
      if direction.frames.len() != count {
        return Err("各方向帧数不一致。");
      }
      for rect in &direction.frames {
        if rect.width != self.canvas.width || rect.height != self.canvas.height {
          return Err("帧 rect 与画布尺寸不同。");
        }
        let right = rect.x.checked_add(rect.width).and_then(|v| v.checked_add(1));
        let bottom = rect.y.checked_add(rect.height).and_then(|v| v.checked_add(1));
        match (right, bottom) {
          (Some(right), Some(bottom)) if right <= self.atlas.width && bottom <= self.atlas.height => {},
          _ => return Err("帧 rect 超出图集（含 extrusion）。"),
        }
      }
    }
    Ok(())
  }

  pub fn direction(&self, index: usize) -> Option<&FrameDirection> {
    self.directions.get(index)
  }
}

/// Unified playback rule (plan 8.3): looping `i = floor(t*fps) mod N`;
/// non-looping `i = min(floor(t*fps), N-1)` with the last frame retained.
pub fn frame_at(time: f64, fps: f64, count: usize, looping: bool) -> usize {
  debug_assert!(time >= 0.0 && fps > 0.0 && count > 0);
  let time = time.max(0.0);
  if looping {
    ((time * fps).floor() as usize) % count
  } else {
    ((time * fps).floor() as usize).min(count - 1)
  }
}

/// Build an arbitrary-rect layout for the whole table: one entry per
/// frame, directions in frozen order, `index = direction * N + frame`.
/// The atlas is an extruded grid — never assume uniform cells.
pub fn atlas_layout(table: &FrameTable) -> TextureAtlasLayout {
  let mut layout = TextureAtlasLayout::new_empty(UVec2::new(table.atlas.width, table.atlas.height));
  for direction in &table.directions {
    for rect in &direction.frames {
      layout.add_texture(rect.to_urect());
    }
  }
  layout
}

/// Playback state of one spawned 2D animation instance. Pause keeps the
/// phase; switching direction keeps the frame number/phase; stop returns
/// to frame 0 (plan 8.3).
#[derive(Component, Clone, Debug)]
pub struct GameAssetAnimation2d {
  pub id: GameAssetId,
  pub version: String,
  pub direction: usize,
  pub playing: bool,
  /// Seconds of accumulated play time (the phase).
  pub elapsed: f64,
}

impl GameAssetAnimation2d {
  pub fn play(&mut self) {
    self.playing = true;
  }

  pub fn pause(&mut self) {
    self.playing = false;
  }

  /// Keep the frame number/phase; only the direction's rect row changes.
  pub fn set_direction(&mut self, direction: usize) {
    self.direction = direction;
  }

  pub fn stop(&mut self) {
    self.playing = false;
    self.elapsed = 0.0;
  }

  /// Current frame index within the CURRENT direction's row.
  pub fn frame(&self, table: &FrameTable) -> Option<usize> {
    let direction = table.direction(self.direction)?;
    let count = direction.frames.len();
    Some(frame_at(self.elapsed, table.fps, count, table.looping).min(count.saturating_sub(1)))
  }

  /// Absolute layout index (direction row offset + frame).
  pub fn texture_index(&self, table: &FrameTable) -> Option<usize> {
    let frames = table.direction(self.direction)?.frames.len();
    Some(self.direction * frames + self.frame(table)?)
  }
}

/// Advance playing instances and push the computed frame into the
/// sprite's atlas index. Paused instances keep their phase (elapsed is
/// untouched); stopped ones sit at frame 0 because elapsed stays 0.
pub fn advance_game_animation_2d(
  time: Res<Time>,
  catalog: Res<GameAssetCatalog>,
  mut animations: Query<(&mut GameAssetAnimation2d, &mut Sprite)>,
) {
  let delta = time.delta_secs_f64();
  for (mut animation, mut sprite) in &mut animations {
    if animation.playing {
      animation.elapsed += delta;
    }
    let Some(entry) = catalog.entries.get(&animation.id) else { continue };
    let Some(block) = entry.animation_2d.as_ref() else { continue };
    let Some(table) = &block.table else { continue };
    let Some(index) = animation.texture_index(table) else { continue };
    if let Some(atlas) = sprite.texture_atlas.as_mut() {
      atlas.index = index;
    }
  }
}

#[cfg(test)]
mod tests {
  use super::*;

  fn table(directions: usize, frames: usize, looping: bool) -> FrameTable {
    FrameTable {
      schema_version: "game.anim2d.frames.v1".into(),
      clip_name: "walk".into(),
      canvas: FrameDimensions { width: 8, height: 8 },
      anchor: FrameAnchor { origin: "top_left".into(), x: 0.5, y: 1.0 },
      atlas: FrameAtlas {
        role: "main".into(),
        ordinal: 0,
        width: (frames as u32) * 10,
        height: (directions as u32) * 10,
        extrude_px: 1,
      },
      fps: 4.0,
      looping,
      directions: (0..directions)
        .map(|direction| FrameDirection {
          name: if direction == 0 { "default".into() } else { "n".into() },
          frames: (0..frames)
            .map(|frame| FrameRect { x: frame as u32 * 10 + 1, y: direction as u32 * 10 + 1, width: 8, height: 8 })
            .collect(),
        })
        .collect(),
    }
  }

  #[test]
  fn unified_playback_rule_matches_the_frozen_contract() {
    // Looping: i = floor(t*fps) mod N.
    assert_eq!(frame_at(0.0, 8.0, 4, true), 0);
    assert_eq!(frame_at(0.125, 8.0, 4, true), 1);
    assert_eq!(frame_at(0.249, 8.0, 4, true), 1);
    // Exactly one period wraps back to frame 0.
    assert_eq!(frame_at(0.5, 8.0, 4, true), 0);
    assert_eq!(frame_at(10.0, 8.0, 4, true), 0);
    // Non-looping: clamp to N-1.
    assert_eq!(frame_at(100.0, 8.0, 4, false), 3);
    assert_eq!(frame_at(0.0, 8.0, 4, false), 0);
  }

  #[test]
  fn pause_keeps_phase_direction_switch_keeps_frame_and_stop_resets() {
    let mut animation =
      GameAssetAnimation2d {
        id: GameAssetId::new("qa", "animations_2d/walk"),
        version: "v1".into(),
        direction: 0,
        playing: true,
        elapsed: 0.375,
      };
    let table = table(2, 4, true);
    // 0.375s * 4fps = frame 1 (phase preserved on pause).
    assert_eq!(animation.frame(&table), Some(1));
    animation.pause();
    assert_eq!(animation.frame(&table), Some(1));
    // Direction switch keeps the frame NUMBER: same index in the new row.
    animation.set_direction(1);
    assert_eq!(animation.frame(&table), Some(1));
    assert_eq!(animation.texture_index(&table), Some(4 + 1));
    animation.stop();
    assert_eq!(animation.frame(&table), Some(0));
  }

  #[test]
  fn layout_uses_arbitrary_rects_not_a_uniform_grid() {
    // Two frames with a horizontal gap: rects are (1,1)-(9,9) and
    // (11,1)-(19,9) — an extruded grid is NOT evenly divisible.
    let table = table(1, 2, true);
    let layout = atlas_layout(&table);
    assert_eq!(layout.textures.len(), 2);
    assert_eq!(layout.textures[0], URect::new(1, 1, 9, 9));
    assert_eq!(layout.textures[1], URect::new(11, 1, 19, 9));
    assert_eq!(layout.size, UVec2::new(20, 10));
  }

  #[test]
  fn frame_table_rejects_drifted_or_incomplete_payloads() {
    let valid = serde_json::to_value(table(1, 2, true)).unwrap();
    assert!(FrameTable::parse(&valid).is_ok());

    let mut wrong_schema = valid.clone();
    wrong_schema["schema_version"] = serde_json::json!("game.anim2d.frames.v2");
    assert!(FrameTable::parse(&wrong_schema).is_err());

    let mut uneven = valid.clone();
    uneven["directions"][0]["frames"][1]["width"] = serde_json::json!(7);
    assert!(FrameTable::parse(&uneven).is_err());

    let mut outside = valid.clone();
    outside["directions"][0]["frames"][1]["x"] = serde_json::json!(12);
    assert!(FrameTable::parse(&outside).is_err());

    let mut bad_fps = valid.clone();
    bad_fps["fps"] = serde_json::json!(0.0);
    assert!(FrameTable::parse(&bad_fps).is_err());
  }
}
