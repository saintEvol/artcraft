extends SceneTree
## Supported command-line entry for CI and developers using the same component.
const Importer := preload("res://addons/game_assets/importer.gd")
const Builder := preload("res://addons/game_assets/resource_builder.gd")
const Report := preload("res://addons/game_assets/engine_report.gd")

func _init() -> void:
	call_deferred("_run")

func _run() -> void:
	var args := OS.get_cmdline_user_args()
	if args.size() < 1:
		push_error("用法：--script res://addons/game_assets/import_cli.gd -- /path/to/unpacked-pack [cancel|keep|copy|replace]")
		quit(2); return
	var importer := Importer.new()
	var ok := importer.import_pack(args[0], args[1] if args.size() > 1 else "cancel")
	if not ok:
		push_error("\n".join(importer.report)); quit(1); return
	if importer.result.get("kept_current", false):
		Report.save(importer.result, "user://game_assets_reports/import-report.json"); quit(0); return
	var filesystem := EditorInterface.get_resource_filesystem()
	filesystem.scan()
	var deadline := Time.get_ticks_msec() + 60000
	while filesystem.is_scanning() or filesystem.is_importing():
		if Time.get_ticks_msec() > deadline:
			importer.rollback(); push_error("资源扫描超时，已请求恢复上一份。"); quit(1); return
		await process_frame
	var paths: PackedStringArray = []
	for asset in importer.manifest_data.assets:
		for file in asset.files:
			if String(file.path).get_extension() in ["png", "glb"]:
				paths.append(importer.managed_root.path_join(String(file.path)))
	filesystem.reimport_files(paths)
	while filesystem.is_scanning() or filesystem.is_importing():
		if Time.get_ticks_msec() > deadline:
			importer.rollback(); push_error("资源导入超时，已请求恢复上一份。"); quit(1); return
		await process_frame
	var builder := Builder.new()
	if not builder.build(importer.manifest_data, importer.managed_root, importer.managed_namespace) or not importer.finish_import():
		importer.rollback(); push_error("\n".join(builder.problems) + "\n" + "\n".join(importer.report)); quit(1); return
	var report_path := "user://game_assets_reports/%s-import.json" % String(importer.manifest_data.pack_id).validate_filename()
	if not Report.save(importer.result, report_path):
		push_error("无法保存导入报告。"); quit(1); return
	print("ARTCRAFT_IMPORT_OK ", builder.preview_path, " report=", ProjectSettings.globalize_path(report_path))
	quit(0)
