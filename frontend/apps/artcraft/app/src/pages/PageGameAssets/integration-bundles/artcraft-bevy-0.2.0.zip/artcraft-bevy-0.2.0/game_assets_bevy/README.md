# Artcraft Bevy 集成 0.2.0

支持 Bevy 0.20.0。本 crate 和示例是可信集成组件，工作台下载的另一份 ZIP 是只读资产数据，两者分别解压。

## 导入并实际运行

将本目录放到自己工程的 `vendor/game_assets_bevy`。先将资源 ZIP 解压为一个包含 manifest.json 的目录，然后运行：

```sh
cargo run --locked --manifest-path vendor/game_assets_bevy/Cargo.toml --example import_pack -- /path/to/unpacked-pack ./assets
```

命令核对文件后会显示 `assets/game_assets/<项目身份>` 的安装位置。以该位置运行实际预览：

```sh
cargo run --locked --manifest-path vendor/game_assets_bevy/Cargo.toml --example preview_pack -- ./assets/game_assets/项目身份
```

图标以 64px 背包格显示；模型使用真实米制。方向键旋转，+/- 缩放。报告保存于命令当前目录的 `game_assets_reports`，回到工作台相应交付记录上传。初次导入、文件加载、实际实例化/渲染分别记录。

## 更新与本地修改

继续对同一个游戏 assets 目录执行导入命令。默认遇到本地修改停止，不覆盖。第三个参数可选：

- `keep`：保留工程当前版本，不应用本次更新，并记录部分完成。
- `copy`：写入独立副本，不改变已有引用。
- `replace`：保留完整旧目录备份，再替换受管理文件。

被新包省略的旧文件不自动删除。源文件先核验并准备完整目录，再替换；恢复标记用于处理中断。正常更新使用相同项目命名空间、稳定资产 ID 和资源路径。

随附预览程序在启动时读取清单。导入新包后关闭并重新运行预览，取得对应新包的运行报告。在自己的持续运行游戏中，重新读取并验证新清单后调用 `GameAssetCatalog::reload_pack`；通过本 crate 辅助函数生成的实体按稳定 ID 更新资源，原实体及游戏中的位置保持。自行创建的实体需由游戏接入资源更新。

## 在自己的游戏使用

添加 path 依赖 `game_assets_bevy = { path = "vendor/game_assets_bevy" }`，注册 `GameAssetPackPlugin`。用 `GameAssetPackManifest::parse_and_validate` 和 `verify_pack_files` 检查包，以 `GameAssetCatalog::load_pack` 加载。必须等待 `GameAssetLoadStateTracker` 确认依赖就绪，再调用 `spawn_game_sprite` 或 `spawn_game_prop`。

采样和图集由每个资产独立的图像资源应用；不会改动整个游戏的 ImagePlugin。Sprite 按清单 PPU 与锚点创建，UI 图像大小可另行设置。基础 crate 仅提供碰撞描述，实际物理需游戏选择并锁定物理适配。

预览示例内嵌 Noto Sans SC 以显示中文资产名，字体原文件和 SIL OFL 声明位于 `assets/fonts`。组件的 Rust 代码沿用上层项目许可证。
