@tool
extends RefCounted
## §12.3 animation binding. Two halves:
##
## 1. At character import, build the COMPLETE glTF node path → imported
##    scene NodePath / Skeleton3D bone map from GLTFState — the structural
##    authority of Godot's own glTF importer, never a guess from terminal
##    bone names. The map is stored as a derived binding file next to the
##    character scene and recorded in the journal.
## 2. At anim_3d import, retarget the clip's Godot-baked animation tracks
##    through that map into an AnimationLibrary whose track paths address
##    the target rig's nodes and bones. Target rest TRS semantics are kept
##    (values are copied verbatim; y-up +z-forward passes through), and
##    the motion root holds its rest TRS for the whole clip. The library
##    records the coordinate conversion and importer version, and every
##    retargeted track is verified key-by-key against the baked source.
##
## Runs headless: GLTFDocument/GLTFState work without the editor importer.

const SKELETON_MAP_SCHEMA := "game.anim3d.skeleton_map.v1"
const BINDING_FORMAT := "game-assets-animation-binding.v1"
const COORDINATE_CONVERSION := "y_up_z_forward_passthrough"
const Report := preload("res://addons/game_assets/engine_report.gd")

var problems: PackedStringArray = PackedStringArray()

## Parse and validate a skeleton_map.json (animation_3d.rs::SkeletonMap).
## Returns {} and appends reasons on any contract violation.
static func parse_skeleton_map(text: String, errors: PackedStringArray) -> Dictionary:
	var parsed: Variant = JSON.parse_string(text)
	if not (parsed is Dictionary):
		errors.append("skeleton_map 不是 JSON 对象。")
		return {}
	var m: Dictionary = parsed
	for key in m:
		if not (String(key) in ["schema_version", "rig_version_token", "rig_main_sha256", "clip", "mappings"]):
			errors.append("skeleton_map 包含未知字段：%s" % String(key))
			return {}
	var sha := String(m.get("rig_main_sha256", ""))
	if String(m.get("schema_version", "")) != SKELETON_MAP_SCHEMA:
		errors.append("skeleton_map 的 schema_version 不是 %s。" % SKELETON_MAP_SCHEMA)
		return {}
	var token := String(m.get("rig_version_token", ""))
	if token.is_empty() or token.length() > 32 or not is_sha256(sha):
		errors.append("skeleton_map 的 rig 身份不完整。")
		return {}
	var clip: Variant = m.get("clip")
	if not (clip is Dictionary):
		errors.append("skeleton_map 缺少 clip 块。")
		return {}
	var c: Dictionary = clip
	for key in c:
		if not (String(key) in ["animation_index", "name", "duration_seconds", "loop", "root_motion"]):
			errors.append("skeleton_map 的 clip 包含未知字段：%s" % String(key))
			return {}
	if int(c.get("animation_index", -1)) != 0 or not safe_clip_name(String(c.get("name", ""))) or not (typeof(c.get("duration_seconds")) in [TYPE_INT, TYPE_FLOAT]) or not is_finite(float(c.get("duration_seconds", 0))) or float(c.get("duration_seconds", 0)) <= 0 or String(c.get("root_motion", "")) != "in_place":
		errors.append("skeleton_map 的 clip 描述不合法。")
		return {}
	var mappings: Variant = m.get("mappings")
	if not (mappings is Array) or (mappings as Array).is_empty():
		errors.append("skeleton_map 没有节点映射。")
		return {}
	var seen := {}
	for mapping in mappings:
		if not (mapping is Dictionary):
			errors.append("skeleton_map 的映射条目不是对象。")
			return {}
		var d: Dictionary = mapping
		for key in d:
			if not (String(key) in ["animation_node_path", "rig_node_path"]):
				errors.append("skeleton_map 的映射包含未知字段：%s" % String(key))
				return {}
		if not _paths_equal(d.get("animation_node_path"), d.get("rig_node_path")) or not valid_node_path(d.get("rig_node_path")):
			errors.append("skeleton_map 的映射路径不合法。")
			return {}
		var key := "/"
		for part in d.get("rig_node_path", []) as Array:
			key += String(part) + "/"
		if seen.has(key):
			errors.append("skeleton_map 的映射路径重复。")
			return {}
		seen[key] = true
	return m

## Build the glTF path → scene node/bone map for one rigged GLB.
## `scene_prefix` is prepended to scene paths (the generated scene is
## instanced as a child of the managed character scene root).
## Returns {"format", "scene_prefix", "paths": {...}, "skeletons": [...]}
## or {} on failure; appends reasons to `problems` (member).
func build_node_map(glb_path: String, scene_prefix: String) -> Dictionary:
	problems = PackedStringArray()
	var state := _read_state(glb_path)
	if state == null:
		return {}
	var nodes: Array = state.get_nodes()
	if nodes.is_empty():
		problems.append("模型没有可绑定的节点：" + glb_path)
		return {}
	var scene := _generate_scene(state)
	if scene == null:
		return {}
	var skeleton_paths := _skeleton_scene_paths(state, scene)
	var paths := {}
	for index in nodes.size():
		var node = nodes[index]
		if node == null:
			continue
		var gltf_path := _gltf_path(nodes, index)
		if gltf_path.is_empty():
			continue
		var key := "/".join(gltf_path)
		var skeleton_index := int(node.get_skeleton())
		var entry := {}
		if skeleton_index >= 0 and skeleton_paths.has(skeleton_index):
			var skeleton: Skeleton3D = skeleton_paths[skeleton_index]["skeleton"]
			var bone := String(node.get_name())
			var bone_index := skeleton.find_bone(bone)
			if bone_index < 0:
				problems.append("骨骼 %s 不在导入的 Skeleton3D 中。" % key)
				continue
			var rest := skeleton.get_bone_pose(bone_index)
			entry = {
				"is_joint": true,
				"node_path": skeleton_paths[skeleton_index]["path"],
				"bone": bone,
				"bone_index": bone_index,
				"rest": _transform_record(rest),
			}
		else:
			var node_path := _scene_node_path(nodes, index, skeleton_paths, scene)
			if node_path.is_empty():
				problems.append("glTF 节点 %s 在导入场景中没有对应节点。" % key)
				continue
			var scene_node := scene.get_node_or_null(NodePath(node_path))
			if scene_node == null or not (scene_node is Node3D):
				problems.append("glTF 节点 %s 的导入节点缺失。" % key)
				continue
			entry = {
				"is_joint": false,
				"node_path": node_path,
				"rest": _node3d_record(scene_node as Node3D),
			}
		if not scene_prefix.is_empty():
			entry["node_path"] = scene_prefix + "/" + String(entry["node_path"])
		paths[key] = entry
	var skeletons := []
	for index in skeleton_paths:
		var record: Dictionary = skeleton_paths[index]
		var skeleton: Skeleton3D = record["skeleton"]
		var bones := []
		for bone in skeleton.get_bone_count():
			bones.append(skeleton.get_bone_name(bone))
		var skeleton_path := String(record["path"])
		if not scene_prefix.is_empty():
			skeleton_path = scene_prefix + "/" + skeleton_path
		skeletons.append({"path": skeleton_path, "bones": bones})
	return {"format": BINDING_FORMAT, "scene_prefix": scene_prefix, "paths": paths, "skeletons": skeletons}

## Retarget the clip's baked animation tracks onto the target rig binding.
## `binding` is a stored build_node_map result; `skeleton_map` a validated
## parse_skeleton_map result; `motion_root_path` the rig's contract
## motion-root glTF path. Returns {"library": AnimationLibrary,
## "clip": String} or {}.
func build_animation_library(clip_path: String, binding: Dictionary, skeleton_map: Dictionary, motion_root_path: Array) -> Dictionary:
	problems = PackedStringArray()
	var state := _read_state(clip_path)
	if state == null:
		return {}
	var scene := _generate_scene(state)
	if scene == null:
		return {}
	var players: Array = scene.find_children("*", "AnimationPlayer", true, false)
	if players.is_empty():
		problems.append("动画文件没有可用的 AnimationPlayer：" + clip_path)
		return {}
	var source_library: AnimationLibrary = (players[0] as AnimationPlayer).get_animation_library("")
	if source_library == null or source_library.get_animation_list().is_empty():
		problems.append("动画文件没有烘焙的动画轨道：" + clip_path)
		return {}
	if source_library.get_animation_list().size() != 1:
		problems.append("动画文件包含多个 clip；此组件一次导入一个 clip。")
		return {}
	var nodes: Array = state.get_nodes()
	var gltf_paths := {}
	for index in nodes.size():
		var path := _gltf_path(nodes, index)
		if not path.is_empty():
			gltf_paths["/".join(path)] = index
	var skeleton_paths := _skeleton_scene_paths(state, scene)
	var clip_name := String((skeleton_map.get("clip", {}) as Dictionary).get("name", ""))
	var looping := bool((skeleton_map.get("clip", {}) as Dictionary).get("loop", false))
	var motion_root_key := "/".join(motion_root_path)
	var source: Animation = source_library.get_animation(source_library.get_animation_list()[0])
	var target := Animation.new()
	target.length = source.length
	target.step = source.step
	target.loop_mode = Animation.LOOP_LINEAR if looping else Animation.LOOP_NONE
	for track in source.get_track_count():
		if not _retarget_track(source, track, target, nodes, gltf_paths, skeleton_paths, binding, motion_root_key):
			return {}
	var library := AnimationLibrary.new()
	library.add_animation(clip_name, target)
	library.set_meta("artcraft_coordinate_conversion", COORDINATE_CONVERSION)
	library.set_meta("artcraft_importer_version", "game_assets_addon_1@" + Report.COMPONENT_VERSION)
	library.set_meta("artcraft_rig_main_sha256", String(skeleton_map.get("rig_main_sha256", "")))
	library.set_meta("artcraft_rig_version_token", String(skeleton_map.get("rig_version_token", "")))
	library.set_meta("artcraft_motion_root_path", motion_root_path.duplicate())
	library.set_meta("artcraft_clip_loop", looping)
	return {"library": library, "clip": clip_name}

## Every skeleton_map mapping must resolve through the binding: the clip
## addresses exactly these glTF paths, so a missing entry means the target
## rig scene cannot reproduce the clip.
func verify_contract_mapping(binding: Dictionary, skeleton_map: Dictionary) -> bool:
	problems = PackedStringArray()
	var paths: Dictionary = binding.get("paths", {})
	for mapping in skeleton_map.get("mappings", []) as Array:
		var key := "/".join((mapping as Dictionary).get("rig_node_path", []) as Array)
		if not paths.has(key):
			problems.append("绑定缺少 skeleton_map 中的节点：%s" % key)
	return problems.is_empty()

func _retarget_track(source: Animation, track: int, target: Animation, nodes: Array, gltf_paths: Dictionary, skeleton_paths: Dictionary, binding: Dictionary, motion_root_key: String) -> bool:
	var track_type := source.track_get_type(track)
	if track_type not in [Animation.TYPE_POSITION_3D, Animation.TYPE_ROTATION_3D, Animation.TYPE_SCALE_3D]:
		problems.append("动画包含此组件不支持的轨道类型（混合形状或方法）。")
		return false
	var path: NodePath = source.track_get_path(track)
	var names := String(path.get_concatenated_names())
	var sub := String(path.get_concatenated_subnames())
	var node_index := -1
	if not sub.is_empty():
		# Bone-addressed track: the bone belongs to the skeleton whose scene
		# path the track names; resolve the joint's glTF node from it.
		for skeleton_index in skeleton_paths:
			var record: Dictionary = skeleton_paths[skeleton_index]
			if String(record["path"]) != names:
				continue
			for joint in record.get("joints", []) as Array:
				var joint_index := int(joint)
				if joint_index >= 0 and joint_index < nodes.size() and String(nodes[joint_index].get_name()) == sub:
					node_index = joint_index
					break
	else:
		node_index = int(gltf_paths.get(names, -1))
	if node_index < 0:
		problems.append("动画轨道 %s 无法在动画文件中定位 glTF 节点。" % names)
		return false
	var gltf_key := "/".join(_gltf_path(nodes, node_index))
	var entry: Dictionary = (binding.get("paths", {}) as Dictionary).get(gltf_key, {}) as Dictionary
	if entry.is_empty():
		problems.append("目标角色缺少动画引用的节点：%s" % gltf_key)
		return false
	var new_path := NodePath("%s:%s" % [entry.get("node_path", ""), entry.get("bone", "")]) if bool(entry.get("is_joint", false)) else NodePath(String(entry.get("node_path", "")))
	target.add_track(track_type)
	var new_track := target.get_track_count() - 1
	target.track_set_path(new_track, new_path)
	target.track_set_interpolation_type(new_track, source.track_get_interpolation_type(track))
	var key_count := source.track_get_key_count(track)
	if gltf_key == motion_root_key:
		# The motion root keeps its rest TRS for the whole clip.
		var rest: Dictionary = entry.get("rest", {})
		var value: Variant = null
		match track_type:
			Animation.TYPE_POSITION_3D: value = _vector3(rest.get("position", [0, 0, 0]))
			Animation.TYPE_ROTATION_3D: value = _quaternion(rest.get("rotation", [0, 0, 0, 1]))
			Animation.TYPE_SCALE_3D: value = _vector3(rest.get("scale", [1, 1, 1]))
		target.track_insert_key(new_track, 0.0, value)
		return true
	for key in key_count:
		var time := source.track_get_key_time(track, key)
		var value: Variant = source.track_get_key_value(track, key)
		target.track_insert_key(new_track, time, value)
		# Per-key verification against the baked source (逐关节对照已烘焙结果).
		if target.track_get_key_value(new_track, target.track_get_key_count(new_track) - 1) != value or absf(target.track_get_key_time(new_track, target.track_get_key_count(new_track) - 1) - time) > 0.000001:
			problems.append("重定向后的轨道数据与烘焙结果不一致：%s" % gltf_key)
			return false
	return true

func _read_state(glb_path: String) -> GLTFState:
	var document := GLTFDocument.new()
	var state := GLTFState.new()
	if document.append_from_file(glb_path, state) != OK:
		problems.append("无法解析 GLB：" + glb_path)
		return null
	return state

func _generate_scene(state: GLTFState) -> Node:
	var document := GLTFDocument.new()
	var scene := document.generate_scene(state)
	if scene == null:
		problems.append("无法从 GLB 生成场景。")
	return scene

## glTF node index -> full path of node names (root inclusive).
func _gltf_path(nodes: Array, index: int) -> PackedStringArray:
	var parts := PackedStringArray()
	var current := index
	var guard := 0
	while current >= 0 and current < nodes.size() and guard < nodes.size() + 1:
		var node = nodes[current]
		if node == null:
			return PackedStringArray()
		parts.insert(0, String(node.get_name()))
		current = int(node.get_parent())
		guard += 1
	return parts

## Skeleton index -> {"skeleton": Skeleton3D, "path": scene-relative path,
## "joints": glTF node indices}. The Skeleton3D instance comes from the
## GLTFState itself, so the map is anchored to the importer's structure.
func _skeleton_scene_paths(state: GLTFState, scene: Node) -> Dictionary:
	var result := {}
	var skeletons: Array = state.get_skeletons()
	for index in skeletons.size():
		var skeleton: Skeleton3D = skeletons[index].get_godot_skeleton()
		if skeleton == null:
			continue
		var path := _relative_node_path(scene, skeleton)
		if path.is_empty():
			continue
		result[index] = {"skeleton": skeleton, "path": path, "joints": skeletons[index].get_joints()}
	return result

func _relative_node_path(root: Node, node: Node) -> String:
	if node == root:
		return ""
	var current := node
	var parts := PackedStringArray()
	var guard := 0
	while current != null and current != root and guard < 4096:
		parts.insert(0, String(current.name))
		current = current.get_parent()
		guard += 1
	if current == null:
		return ""
	return "/".join(parts)

## Scene node path for a NON-joint glTF node: children of the scene root
## hang directly under it; children of a joint hang under that joint's
## Skeleton3D; everything else extends its parent's path.
func _scene_node_path(nodes: Array, index: int, skeleton_paths: Dictionary, scene: Node) -> String:
	var node = nodes[index]
	var parent := int(node.get_parent())
	if parent < 0:
		return String(node.get_name())
	var parent_skeleton := int(nodes[parent].get_skeleton())
	if parent_skeleton >= 0 and skeleton_paths.has(parent_skeleton):
		return String(skeleton_paths[parent_skeleton]["path"]) + "/" + String(node.get_name())
	return _scene_node_path(nodes, parent, skeleton_paths, scene) + "/" + String(node.get_name())

func _transform_record(transform: Transform3D) -> Dictionary:
	return {
		"position": [transform.origin.x, transform.origin.y, transform.origin.z],
		"rotation": [transform.basis.get_rotation_quaternion().x, transform.basis.get_rotation_quaternion().y, transform.basis.get_rotation_quaternion().z, transform.basis.get_rotation_quaternion().w],
		"scale": [transform.basis.get_scale().x, transform.basis.get_scale().y, transform.basis.get_scale().z],
	}

func _node3d_record(node: Node3D) -> Dictionary:
	var rotation := node.quaternion
	return {
		"position": [node.position.x, node.position.y, node.position.z],
		"rotation": [rotation.x, rotation.y, rotation.z, rotation.w],
		"scale": [node.scale.x, node.scale.y, node.scale.z],
	}

func _vector3(values: Variant) -> Vector3:
	var array: Array = values if values is Array else [0, 0, 0]
	return Vector3(float(array[0]), float(array[1]), float(array[2]))

func _quaternion(values: Variant) -> Quaternion:
	var array: Array = values if values is Array else [0, 0, 0, 1]
	return Quaternion(float(array[0]), float(array[1]), float(array[2]), float(array[3]))

static func valid_node_path(path: Variant) -> bool:
	if not (path is Array) or (path as Array).is_empty():
		return false
	for part in path:
		var s := String(part)
		if s.is_empty() or s.contains("/") or s.contains("\\") or s.contains(":") or s.contains(".") or s.contains("%"):
			return false
	return true

static func _paths_equal(a: Variant, b: Variant) -> bool:
	if not (a is Array) or not (b is Array) or (a as Array).size() != (b as Array).size():
		return false
	for i in (a as Array).size():
		if String((a as Array)[i]) != String((b as Array)[i]):
			return false
	return true

static func safe_clip_name(value: String) -> bool:
	if value.is_empty() or value.length() > 64:
		return false
	if not (value[0] >= "a" and value[0] <= "z"):
		return false
	for i in value.length():
		var c := value[i]
		if not ((c >= "a" and c <= "z") or (c >= "0" and c <= "9") or c == "_"):
			return false
	return true

static func is_sha256(value: String) -> bool:
	return value.length() == 64 and RegEx.create_from_string("^[0-9a-f]{64}$").search(value) != null
