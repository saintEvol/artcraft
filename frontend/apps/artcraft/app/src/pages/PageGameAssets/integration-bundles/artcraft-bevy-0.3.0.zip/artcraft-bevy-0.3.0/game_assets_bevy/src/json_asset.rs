//! JSON pack sidecars (frames.json / skeleton_map.json) as AssetServer
//! assets (plan 12.4: runtime reads through resource paths, never
//! developer-machine absolute paths).

use bevy::asset::io::Reader;
use bevy::asset::{Asset, AssetLoader, LoadContext};
use bevy::reflect::TypePath;
use serde_json::Value;

#[derive(Asset, TypePath, Debug, Clone)]
pub struct JsonAsset(pub Value);

#[derive(Default, TypePath)]
pub struct JsonAssetLoader;

#[derive(Debug)]
pub enum JsonAssetError {
  Io(std::io::Error),
  Parse(serde_json::Error),
}

impl std::fmt::Display for JsonAssetError {
  fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
    match self {
      JsonAssetError::Io(error) => write!(formatter, "json asset read failed: {error}"),
      JsonAssetError::Parse(error) => write!(formatter, "json asset parse failed: {error}"),
    }
  }
}

impl std::error::Error for JsonAssetError {}

impl AssetLoader for JsonAssetLoader {
  type Asset = JsonAsset;
  type Settings = ();
  type Error = JsonAssetError;

  async fn load(
    &self,
    reader: &mut dyn Reader,
    _settings: &Self::Settings,
    _context: &mut LoadContext<'_>,
  ) -> Result<Self::Asset, Self::Error> {
    let mut bytes = Vec::new();
    reader.read_to_end(&mut bytes).await.map_err(JsonAssetError::Io)?;
    let value = serde_json::from_slice(&bytes).map_err(JsonAssetError::Parse)?;
    Ok(JsonAsset(value))
  }

  fn extensions(&self) -> &[&str] {
    &["json"]
  }
}
