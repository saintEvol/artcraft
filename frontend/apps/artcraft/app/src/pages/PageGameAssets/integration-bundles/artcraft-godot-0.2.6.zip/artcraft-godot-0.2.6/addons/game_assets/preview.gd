extends Node
## Reusable real-engine showcase; all PackedScenes are export dependencies.

const Report := preload("res://addons/game_assets/engine_report.gd")
@export var asset_scenes: Array[PackedScene] = []
@export var manifest: Dictionary = {}
var _camera: Camera3D
var _center := Vector3.ZERO
var _distance := 6.0
var _yaw := 0.35
var _pitch := 0.25
var _status: Label
var _results: Array = []
var _problems: Array = []
var _report_path := ""

func _ready() -> void:
	var world := Node3D.new(); add_child(world)
	_camera = Camera3D.new(); world.add_child(_camera); _camera.current = true
	var light := DirectionalLight3D.new(); light.rotation_degrees = Vector3(-45, -30, 0); light.light_energy = 1.0; world.add_child(light)
	var environment := WorldEnvironment.new(); environment.environment = Environment.new()
	environment.environment.background_mode = Environment.BG_COLOR
	environment.environment.background_color = Color("242b36")
	environment.environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.environment.ambient_light_color = Color.WHITE
	environment.environment.ambient_light_energy = 0.7
	world.add_child(environment)
	var layer := CanvasLayer.new(); add_child(layer)
	var margin := MarginContainer.new(); layer.add_child(margin)
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 20)
	margin.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var column := VBoxContainer.new(); column.mouse_filter = Control.MOUSE_FILTER_IGNORE; margin.add_child(column)
	var title := Label.new(); title.text = "游戏资产 · Godot 实际运行预览"; title.add_theme_font_size_override("font_size", 24); column.add_child(title)
	var hint := Label.new(); hint.text = "左键拖动旋转，滚轮缩放；图标按 64px 背包格显示，模型保持真实米制。"; column.add_child(hint)
	var grid := GridContainer.new(); grid.columns = 6; column.add_child(grid)
	var lane := 0.0
	if asset_scenes.size() != manifest.get("assets", []).size() or asset_scenes.is_empty():
		_problems.append("场景引用数量与清单不一致。")
	for i in mini(asset_scenes.size(), manifest.get("assets", []).size()):
		var asset: Dictionary = manifest.assets[i]
		var outcome := {"asset_id": asset.asset_id, "version_id": asset.version_id, "status": "failed"}
		if asset_scenes[i] == null:
			_problems.append("资源无法加载：" + String(asset.get("display_name", asset.stable_key)))
			_results.append(outcome); continue
		var instance := asset_scenes[i].instantiate()
		if instance is Sprite2D and instance.texture != null:
			var cell := VBoxContainer.new(); grid.add_child(cell)
			var button := TextureButton.new(); button.texture_normal = instance.texture
			button.ignore_texture_size = true; button.stretch_mode = TextureButton.STRETCH_KEEP_ASPECT_CENTERED
			button.custom_minimum_size = Vector2(64, 64); button.texture_filter = instance.texture_filter
			button.pressed.connect(func() -> void: _status.text = "已选择：" + String(asset.get("display_name", asset.stable_key)))
			cell.add_child(button)
			var label := Label.new(); label.text = String(asset.get("display_name", asset.stable_key)); cell.add_child(label)
			outcome.status = "loaded"; outcome["pixels"] = [instance.texture.get_width(), instance.texture.get_height()]
			instance.free()
		elif instance is Node3D:
			world.add_child(instance); instance.position.x = lane
			lane += 2.2
			outcome.status = "loaded"
		else:
			_problems.append("资产没有可实例化的图像或模型：" + String(asset.stable_key)); instance.free()
		_results.append(outcome)
	if lane > 0:
		var reference := MeshInstance3D.new(); reference.mesh = BoxMesh.new(); reference.mesh.size = Vector3(0.4, 1.7, 0.25)
		reference.position = Vector3(lane, 0.85, 0); world.add_child(reference)
		_center = Vector3(lane / 2, 0.9, 0); _distance = maxf(5.0, lane * 1.3)
		var floor_mesh := MeshInstance3D.new(); floor_mesh.mesh = PlaneMesh.new(); floor_mesh.mesh.size = Vector2(maxf(lane * 2, 12), 12); floor_mesh.position.x = lane / 2
		world.add_child(floor_mesh)
	_update_camera()
	var spacer := Control.new(); spacer.mouse_filter = Control.MOUSE_FILTER_IGNORE; spacer.size_flags_vertical = Control.SIZE_EXPAND_FILL; column.add_child(spacer)
	_status = Label.new(); _status.text = "等待全部实例进入场景并记录运行报告…"; column.add_child(_status)
	var open_report := Button.new(); open_report.text = "打开运行报告目录"; open_report.pressed.connect(func() -> void: OS.shell_open(ProjectSettings.globalize_path("user://game_assets_reports"))); column.add_child(open_report)
	call_deferred("_save_runtime_report")

func _save_runtime_report() -> void:
	await get_tree().process_frame
	var rendered := DisplayServer.get_name() != "headless"
	for frame in 3:
		if rendered:
			await RenderingServer.frame_post_draw
		else:
			await get_tree().process_frame
	var report := Report.create(manifest, "runtime", "failed" if not _problems.is_empty() else "succeeded" if rendered else "loaded", _results, _problems)
	report.rendered = rendered
	if rendered:
		var screenshot := "user://game_assets_reports/%s-preview.png" % String(manifest.get("pack_id", "preview")).validate_filename()
		DirAccess.make_dir_recursive_absolute(screenshot.get_base_dir())
		if get_viewport().get_texture().get_image().save_png(screenshot) == OK:
			report["preview_image"] = screenshot
	_report_path = "user://game_assets_reports/%s_runtime_%s.json" % [String(manifest.get("pack_id", "unknown")).validate_filename(), Time.get_unix_time_from_system()]
	if Report.save(report, _report_path):
		_status.text = "运行报告已保存；%d 项已实例化。可打开目录并回到工作台上传。" % _results.size()
	else:
		_status.text = "运行报告未能写入，请检查工程的数据目录。"

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
		_yaw -= event.relative.x * 0.008; _pitch = clampf(_pitch - event.relative.y * 0.008, -1.2, 1.2); _update_camera()
	elif event is InputEventMouseButton and event.pressed:
		if event.button_index == MOUSE_BUTTON_WHEEL_UP: _distance = maxf(0.5, _distance * 0.85)
		elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN: _distance *= 1.15
		_update_camera()

func _update_camera() -> void:
	_camera.position = _center + Vector3(sin(_yaw) * cos(_pitch), sin(_pitch), cos(_yaw) * cos(_pitch)) * _distance
	_camera.look_at(_center)
