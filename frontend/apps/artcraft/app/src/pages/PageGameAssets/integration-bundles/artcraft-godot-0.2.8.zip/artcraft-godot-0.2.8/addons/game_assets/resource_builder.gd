@tool
extends RefCounted
## Trusted integration code creates reusable scenes; resource packs supply only data.

const Collision := preload("res://addons/game_assets/collision.gd")
const Preview := preload("res://addons/game_assets/preview.gd")
const Prop := preload("res://addons/game_assets/prop.gd")
const Journal := preload("res://addons/game_assets/journal.gd")

var problems: PackedStringArray = []
var preview_path := ""

func build(manifest: Dictionary, root: String, managed_namespace: String, unchanged: Array = []) -> bool:
	var scenes: Array[PackedScene] = []
	var journal := Journal.new()
	if not journal.load_from(managed_namespace):
		problems.append("导入记录缺失，不能创建资产场景。")
		return false
	if DirAccess.make_dir_recursive_absolute(root.path_join("scenes")) != OK:
		return false
	for asset in manifest.assets:
		var path: String = root.path_join("scenes/" + String(asset.stable_key) + ".tscn")
		var packed: PackedScene
		if String(asset.stable_key) in unchanged and FileAccess.file_exists(path):
			packed = ResourceLoader.load(path, "PackedScene", ResourceLoader.CACHE_MODE_REPLACE) as PackedScene
			if packed == null:
				problems.append("无法读取原有资产场景：" + path); return false
		else:
			var previous: Node
			if FileAccess.file_exists(path):
				var prior := ResourceLoader.load(path, "PackedScene", ResourceLoader.CACHE_MODE_IGNORE) as PackedScene
				if prior != null: previous = prior.instantiate()
			var node: Node
			if asset.kind in ["icon_2d", "sprite_2d"]:
				if previous != null and not previous is Sprite2D: previous.free(); previous = null
				node = _sprite(asset, root, previous)
			else:
				if previous != null and not previous is Node3D: previous.free(); previous = null
				node = _prop(asset, root, previous)
			if node == null:
				if is_instance_valid(previous): previous.free()
				return false
			node.name = String(asset.stable_key)
			node.set_meta("artcraft_asset_id", asset.asset_id)
			node.set_meta("artcraft_version_id", asset.version_id)
			packed = PackedScene.new()
			var error := packed.pack(node)
			node.free()
			if error != OK or not _save_scene(packed, path):
				return false
		scenes.append(packed)
		var entry: Dictionary = journal.entries[String(asset.asset_id)]
		var files: Array = entry.files.filter(func(file: Dictionary) -> bool: return file.get("role") != "generated_scene")
		files.append({"role": "generated_scene", "path": "scenes/" + String(asset.stable_key) + ".tscn", "sha256": FileAccess.get_sha256(path)})
		entry.files = files
	preview_path = root.path_join("preview.tscn")
	var preview := Node.new()
	preview.name = "GameAssetsPreview"
	preview.set_script(Preview)
	preview.set("asset_scenes", scenes)
	preview.set("manifest", manifest)
	var packed := PackedScene.new()
	var error := packed.pack(preview)
	preview.free()
	if error != OK or not _save_scene(packed, preview_path):
		return false
	journal.generated_files = [{"path": "preview.tscn", "sha256": FileAccess.get_sha256(preview_path)}]
	if not journal.save(managed_namespace):
		problems.append("无法保存资源映射，导入尚未完成。")
		return false
	return true

func _sprite(asset: Dictionary, root: String, previous: Sprite2D = null) -> Sprite2D:
	var image: Dictionary = asset.image
	var atlas: Dictionary = image.get("atlas", {})
	var entry: Dictionary = {}
	if not atlas.is_empty():
		entry = asset.files[int(atlas.page_file_index)]
	else:
		for file in asset.files:
			if file.role == "main":
				entry = file
	if entry.is_empty():
		problems.append("图像缺少主文件：" + String(asset.stable_key))
		return null
	var texture := ResourceLoader.load(root.path_join(String(entry.path)), "Texture2D", ResourceLoader.CACHE_MODE_REPLACE) as Texture2D
	if texture == null:
		problems.append("Godot 未成功导入图像：" + String(entry.path))
		return null
	var width: float = image.width
	var height: float = image.height
	var anchor: Dictionary = image.get("anchor", {"x": 0.5, "y": 0.5})
	if not atlas.is_empty():
		var cropped := AtlasTexture.new()
		cropped.atlas = texture
		var rect: Dictionary = atlas.rect
		cropped.region = Rect2(rect.x, rect.y, rect.width, rect.height)
		width = atlas.uncropped_size.width; height = atlas.uncropped_size.height
		cropped.margin = Rect2(atlas.crop_offset.x, atlas.crop_offset.y, width - rect.width, height - rect.height)
		cropped.filter_clip = true
		texture = cropped
		anchor = atlas.anchor
	var sprite := previous if previous != null else Sprite2D.new()
	sprite.texture = texture
	sprite.offset = Vector2((0.5 - float(anchor.x)) * width, (0.5 - float(anchor.y)) * height)
	sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST if image.sampling == "nearest" else CanvasItem.TEXTURE_FILTER_LINEAR
	sprite.set_meta("pixels_per_world_unit", image.get("pixels_per_world_unit", 100.0))
	return sprite

func _prop(asset: Dictionary, root: String, previous: Node3D = null) -> Node3D:
	var node := previous if previous != null else Node3D.new()
	for child in node.get_children(): node.remove_child(child); child.free()
	node.set_script(Prop)
	node.set("lod_description", asset.mesh.get("lod", {}))
	var levels: Array = [{"level": -1, "file_index": -1}]
	levels.append_array(asset.mesh.get("lod", {}).get("levels", []))
	for level in levels:
		var file: Dictionary = {}
		if int(level.level) == -1:
			for candidate in asset.files:
				if candidate.role == "main":
					file = candidate
		else:
			file = asset.files[int(level.file_index)]
		var scene := ResourceLoader.load(root.path_join(String(file.get("path", ""))), "PackedScene", ResourceLoader.CACHE_MODE_REPLACE) as PackedScene
		if scene == null:
			problems.append("模型或 LOD 未成功导入：" + String(asset.stable_key))
			node.free(); return null
		var instance := scene.instantiate()
		if not _has_mesh(instance):
			problems.append("模型或 LOD 没有可显示的网格：" + String(asset.get("display_name", asset.stable_key)))
			instance.free(); node.free(); return null
		instance.name = "Model" if int(level.level) == -1 else "LOD%d" % int(level.level)
		node.add_child(instance); instance.owner = node
	var nodes: Variant = Collision.build(asset.mesh, problems)
	if nodes == null:
		node.free(); return null
	for collision in nodes:
		node.add_child(collision)
		_set_owner(collision, node)
	return node

func _has_mesh(node: Node) -> bool:
	if node is MeshInstance3D and node.mesh != null and node.mesh.get_surface_count() > 0:
		return true
	for child in node.get_children():
		if _has_mesh(child): return true
	return false

func _save_scene(scene: PackedScene, path: String) -> bool:
	var previous_uid := ResourceSaver.get_resource_id_for_path(path, false)
	if ResourceSaver.save(scene, path) != OK:
		problems.append("无法保存资产场景：" + path); return false
	if previous_uid != ResourceUID.INVALID_ID and ResourceSaver.set_uid(path, previous_uid) != OK:
		problems.append("无法保留已有资源 UID：" + path); return false
	return true

func _set_owner(node: Node, root: Node) -> void:
	node.owner = root
	for child in node.get_children():
		_set_owner(child, root)
