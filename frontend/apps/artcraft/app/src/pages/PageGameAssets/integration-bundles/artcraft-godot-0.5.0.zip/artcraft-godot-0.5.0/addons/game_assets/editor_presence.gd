@tool
extends RefCounted
## Each enabled editor plugin announces its process; command-line writers can
## refuse to modify a project that another editor may be holding in memory.

const DIRECTORY := "res://.godot/artcraft_asset_editors"
const TAG := "artcraft-editor-presence.v1"
const ProcessState := preload("res://addons/game_assets/process_state.gd")
static var registration_problem := ""
var _record := ""

func register() -> bool:
	registration_problem = ""
	if not _safe_directory() or DirAccess.make_dir_recursive_absolute(DIRECTORY) != OK:
		registration_problem = "无法保存当前编辑器会话记录，暂停资源写入；请检查工程 .godot 目录后重新启用插件。"; return false
	_record = DIRECTORY.path_join("%s-%s.json" % [OS.get_process_id(), Crypto.new().generate_random_bytes(8).hex_encode()])
	var file := FileAccess.open(_record, FileAccess.WRITE)
	if file == null:
		registration_problem = "无法保存当前编辑器会话记录，暂停资源写入；检查目录后请重新启用插件。"; return false
	file.store_string(JSON.stringify({"format": TAG, "pid": OS.get_process_id()})); file.flush(); file.close()
	return true

func release() -> void:
	if not _record.is_empty() and FileAccess.file_exists(_record): DirAccess.remove_absolute(_record)
	_record = ""

static func other_editors() -> PackedStringArray:
	var problems := PackedStringArray()
	if not registration_problem.is_empty(): problems.append(registration_problem); return problems
	if not _safe_directory(): problems.append("编辑器会话目录包含链接，未改动资源。"); return problems
	var directory := DirAccess.open(DIRECTORY)
	if directory == null: return problems
	for name in directory.get_files():
		if not name.ends_with(".json"): continue
		var path := DIRECTORY.path_join(name)
		if directory.is_link(name): problems.append("编辑器会话记录包含链接，未改动资源。"); continue
		var file := FileAccess.open(path, FileAccess.READ)
		if file == null or file.get_length() > 4096:
			problems.append("无法读取编辑器会话记录，请核对：" + path); continue
		var value: Variant = JSON.parse_string(file.get_as_text()); file.close()
		if not (value is Dictionary) or value.get("format") != TAG or not (value.get("pid") is float or value.get("pid") is int) or int(value.pid) <= 0:
			problems.append("编辑器会话记录不完整，请核对：" + path); continue
		var pid := int(value.pid)
		if pid == OS.get_process_id(): continue
		var state := ProcessState.state(pid)
		if state == 0:
			DirAccess.remove_absolute(path) # Immutable, nonce-named record belongs to the exited process only.
		else:
			problems.append("当前工程还有记录为活动或无法确认已退出的编辑器进程（%s）。请关闭对应工程窗口，再导入；当前资产未改动。" % pid)
	return problems

static func _safe_directory() -> bool:
	var project := DirAccess.open("res://")
	if project == null or project.is_link(".godot"): return false
	var parent := DirAccess.open("res://.godot")
	return parent == null or not parent.is_link("artcraft_asset_editors")
