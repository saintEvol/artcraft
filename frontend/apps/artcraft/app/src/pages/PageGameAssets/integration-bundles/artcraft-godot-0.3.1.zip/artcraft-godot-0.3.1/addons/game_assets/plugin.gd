@tool
extends EditorPlugin

const ImportRunner := preload("res://addons/game_assets/import_runner.gd")
const GAME_ASSETS_PANEL := preload("res://addons/game_assets/panel.tscn")

var _panel: Control
var _runner: Node

func _enter_tree() -> void:
	# Use the normal editor main loop, rather than replacing it with a SceneTree script.
	var args := OS.get_cmdline_user_args()
	if not args.is_empty() and args[0] == "--game-assets-import":
		call_deferred("_start_import", args.slice(1)); return
	if OS.get_cmdline_args().has("--script") and OS.get_cmdline_args().has("res://addons/game_assets/import_cli.gd"):
		return
	_panel = GAME_ASSETS_PANEL.instantiate()
	_panel.name = "GameAssets"
	add_control_to_dock(DOCK_SLOT_RIGHT_BL, _panel)

func _exit_tree() -> void:
	if _panel:
		remove_control_from_docks(_panel)
		_panel.queue_free()

func _start_import(args: PackedStringArray) -> void:
	_runner = ImportRunner.new()
	add_child(_runner)
	_runner.completed.connect(_import_completed)
	_runner.run(args)

func _import_completed(exit_code: int) -> void:
	_runner.queue_free()
	await get_tree().process_frame
	get_tree().quit(exit_code)
