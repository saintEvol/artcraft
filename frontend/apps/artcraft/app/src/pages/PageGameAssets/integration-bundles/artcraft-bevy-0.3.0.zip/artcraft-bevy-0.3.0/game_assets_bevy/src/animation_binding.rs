//! Skinned-character + external 3D clip binding (plan section 12.3).
//!
//! B14 fact: a clip-less character GLB gets NO AnimationTargetId /
//! AnimatedBy / AnimationPlayer from bevy_gltf — this module installs
//! them explicitly. Targets are found by their FULL name path from the
//! GLB scene root (spawn wrapper names never join the path), the
//! AnimationPlayer lives on the selected motion root's playback context,
//! and each AnimationTargetId is generated from the same full path so
//! clips exported onto the rig's named hierarchy drive this instance —
//! and only this instance.

use bevy::animation::{AnimatedBy, AnimationTargetId};
use bevy::asset::AssetId;
use bevy::camera::visibility::DynamicSkinnedMeshBounds;
use bevy::ecs::entity::Entity;
use bevy::ecs::hierarchy::Children;
use bevy::ecs::name::Name;
use bevy::mesh::skinning::SkinnedMesh;
use bevy::prelude::*;

use crate::catalog::{GameAssetCatalog, GameAssetLoadStateTracker};
use crate::manifest::ManifestRig;
use crate::{GameAssetId, GameAssetInstance, GameAssetLoadState};

/// Installed rig binding for one character instance: the player entity
/// (on the motion root), every driven target, the recorded rest pose
/// (clip switches must restore it) and which clip is currently playing.
#[derive(Component, Debug)]
pub struct GameAssetRigBinding {
  pub player: Entity,
  pub targets: Vec<(Entity, AnimationTargetId)>,
  pub rest: Vec<(Entity, Transform)>,
  pub current_clip: Option<AssetId<AnimationClip>>,
}

/// Declarative clip selection: attach to a character instance to play the
/// given anim_3d asset on it. Changing `id`/`version` switches clips.
#[derive(Component, Debug, Clone)]
pub struct GameAssetAnimation3d {
  pub id: GameAssetId,
  pub version: String,
}

/// Walk the FULL name path starting at the spawned scene's root NODES.
/// Two wrapper layers never join the path: the spawn wrapper entity the
/// game created, and bevy_gltf's own scene-instance root ("Scene0") —
/// the latter is confirmed by the loader's AnimationTargetId convention
/// (clip target ids start at the glTF root NODES, not the scene wrapper).
/// When the first path segment matches none of a level's children and
/// that level has exactly one child, that single child is treated as an
/// engine wrapper and skipped. Global same-name bones cannot cross wires
/// because the whole path must match.
pub fn find_entity_by_path(
  root: Entity,
  path: &[String],
  children: &Query<&Children>,
  names: &Query<&Name>,
) -> Option<Entity> {
  fn named_child(
    entity: Entity,
    segment: &str,
    children: &Query<&Children>,
    names: &Query<&Name>,
  ) -> Option<Entity> {
    children.get(entity).ok()?.iter().find(|candidate| {
      names.get(*candidate).is_ok_and(|name| name.as_str() == segment)
    })
  }
  let (first, rest) = path.split_first()?;
  let mut current = match named_child(root, first, children, names) {
    Some(entity) => entity,
    None => {
      // Skip one engine wrapper level (bevy_gltf's scene root).
      let mut only = children.get(root).ok()?.iter();
      let child = only.next()?;
      if only.next().is_some() {
        return None;
      }
      named_child(child, first, children, names)?
    },
  };
  for segment in rest {
    current = named_child(current, segment, children, names)?;
  }
  Some(current)
}

/// All driven paths of a rig: the motion root itself plus every semantic
/// bone path (deduplicated, order preserved).
fn rig_paths(rig: &ManifestRig) -> Vec<Vec<String>> {
  let mut paths: Vec<Vec<String>> = vec![rig.motion_root_path.clone()];
  for path in rig.semantic_bones.values() {
    if !paths.iter().any(|existing| existing == path) {
      paths.push(path.clone());
    }
  }
  paths
}

/// Bind every loaded character_3d instance: install the player on the
/// motion root, generate per-target AnimationTargetId + AnimatedBy from
/// full paths, record the rest pose, and let skinned meshes keep bounds
/// that cover the diagnostic motion (static bounds would cull deforming
/// meshes mid-motion).
pub fn bind_character_rigs(
  mut commands: Commands,
  catalog: Res<GameAssetCatalog>,
  tracker: Res<GameAssetLoadStateTracker>,
  children: Query<&Children>,
  names: Query<&Name>,
  transforms: Query<&Transform>,
  skinned: Query<(), With<SkinnedMesh>>,
  instances: Query<(Entity, &GameAssetInstance)>,
  already_bound: Query<(), With<GameAssetRigBinding>>,
) {
  for (root, instance) in &instances {
    if already_bound.contains(root) {
      continue;
    }
    if tracker.state(&instance.id) != GameAssetLoadState::Loaded {
      continue;
    }
    let Some(entry) = catalog.entries.get(&instance.id) else { continue };
    if entry.kind != "character_3d" {
      continue;
    }
    let Some(rig) = &entry.rig else { continue };
    // The scene must actually be instantiated under the wrapper; binding
    // retries on later frames until it is.
    if children.get(root).is_err() {
      continue;
    }
    let Some(player_entity) = find_entity_by_path(root, &rig.motion_root_path, &children, &names)
    else {
      continue;
    };
    let mut targets = Vec::new();
    let mut rest = Vec::new();
    let mut complete = true;
    for path in rig_paths(rig) {
      let Some(entity) = find_entity_by_path(root, &path, &children, &names) else {
        complete = false;
        break;
      };
      // The path segments ARE the glTF node names; IDs generated from
      // them match clips exported onto the same named hierarchy.
      let target_id = target_id_from_path(&path);
      if let Ok(transform) = transforms.get(entity) {
        rest.push((entity, *transform));
      }
      targets.push((entity, target_id));
    }
    if !complete {
      continue;
    }
    // Skinned meshes under this instance track deformation dynamically.
    for entity in children.iter_descendants(root) {
      if skinned.contains(entity) {
        commands.entity(entity).insert(DynamicSkinnedMeshBounds);
      }
    }
    commands.entity(player_entity).insert(AnimationPlayer::default());
    for (entity, id) in &targets {
      commands.entity(*entity).insert((*id, AnimatedBy(player_entity)));
    }
    commands.entity(root).insert(GameAssetRigBinding {
      player: player_entity,
      targets,
      rest,
      current_clip: None,
    });
  }
}

/// AnimationTargetId from a full scene-root path (export convention).
pub fn target_id_from_path(path: &[String]) -> AnimationTargetId {
  let names: Vec<Name> = path.iter().map(|segment| Name::new(segment.clone())).collect();
  AnimationTargetId::from_names(names.iter())
}

/// Play the requested anim_3d clip on a bound character instance. Clip
/// switches stop everything and restore the recorded rest pose first, so
/// joints the new clip does not drive return to rest (plan 9.2). Two
/// instances each own their player + AnimatedBy links, so they stay
/// independent even when playing the same clip asset.
pub fn sync_animation_3d_playback(
  mut commands: Commands,
  catalog: Res<GameAssetCatalog>,
  tracker: Res<GameAssetLoadStateTracker>,
  mut graphs: ResMut<Assets<AnimationGraph>>,
  mut players: Query<&mut AnimationPlayer>,
  mut transforms: Query<&mut Transform>,
  mut bound: Query<(
    &mut GameAssetRigBinding,
    &GameAssetInstance,
    &GameAssetAnimation3d,
  )>,
) {
  for (mut binding, instance, request) in &mut bound {
    if tracker.state(&request.id) != GameAssetLoadState::Loaded {
      continue;
    }
    let Some(animation) = catalog.entries.get(&request.id) else { continue };
    let Some(block) = &animation.animation_3d else { continue };
    let Some(clip) = &block.clip else { continue };
    // The clip must target THIS character: dependency identity has to
    // match the bound rig asset/version (runtime mirror of the install
    // graph check; a catalog can hold several characters).
    let Some(character) = catalog.entries.get(&instance.id) else { continue };
    let matches_character = animation.dependencies.iter().any(|dependency| {
      dependency.asset_id == character.asset_id && dependency.version_id == character.version_id
    });
    if !matches_character {
      continue;
    }
    if binding.current_clip == Some(clip.id()) && request.version == animation.version_id {
      continue;
    }
    // Switch (or first play): stop, restore rest, then start fresh.
    if let Ok(mut player) = players.get_mut(binding.player) {
      player.stop_all();
    }
    if binding.current_clip.is_some() {
      for (entity, rest) in &binding.rest {
        if let Ok(mut transform) = transforms.get_mut(*entity) {
          *transform = *rest;
        }
      }
    }
    let (graph, node) = AnimationGraph::from_clip(clip.clone());
    commands
      .entity(binding.player)
      .insert(AnimationGraphHandle(graphs.add(graph)));
    if let Ok(mut player) = players.get_mut(binding.player) {
      let active = player.play(node);
      if block.looping {
        active.repeat();
      }
    }
    binding.current_clip = Some(clip.id());
  }
}

#[cfg(test)]
mod tests {
  use super::*;
  use bevy::app::App;
  use bevy::ecs::system::RunSystemOnce;
  use std::collections::BTreeMap;

  struct Hierarchy {
    wrapper: Entity,
    hero: Entity,
    hip: Entity,
    visual: Entity,
  }

  /// rigged_triangle-style scene under a spawn wrapper: wrapper holds the
  /// scene root nodes Hero (with child Hip) and the skinned Visual node.
  fn spawn_hierarchy(world: &mut World) -> Hierarchy {
    let hero_name = Name::new("Hero");
    let hip = world
      .spawn((Name::new("Hip"), Transform::from_xyz(0.0, 1.0, 0.0)))
      .id();
    let hero = world
      .spawn((hero_name, Transform::from_xyz(1.0, 0.0, 0.0)))
      .add_child(hip)
      .id();
    let visual = world
      .spawn((Name::new("Visual"), Transform::IDENTITY, SkinnedMesh::default()))
      .id();
    let wrapper = world
      .spawn((Name::new("GameWrapper"), Transform::IDENTITY))
      .add_child(hero)
      .add_child(visual)
      .id();
    Hierarchy { wrapper, hero, hip, visual }
  }

  #[test]
  fn paths_start_at_the_scene_root_and_never_include_wrapper_names() {
    let mut app = App::new();
    let scene = spawn_hierarchy(app.world_mut());
    // Mirror the real engine layout: bevy_gltf nests the glTF root nodes
    // under a "Scene0" world root, which is itself a child of the spawn
    // wrapper. Neither wrapper name may join a path.
    let world = app.world_mut();
    let scene0 = world
      .spawn((Name::new("Scene0"), Transform::IDENTITY))
      .add_child(scene.hero)
      .add_child(scene.visual)
      .id();
    world.entity_mut(scene.wrapper).replace_children(&[scene0]);
    app.world_mut().run_system_once(
      move |children: Query<&Children>, names: Query<&Name>| {
        assert_eq!(
          find_entity_by_path(scene.wrapper, &["Hero".into()], &children, &names),
          Some(scene.hero),
          "the Scene0 wrapper is skipped"
        );
        assert_eq!(
          find_entity_by_path(scene.wrapper, &["Hero".into(), "Hip".into()], &children, &names),
          Some(scene.hip),
          "full path Hero/Hip resolves to the Hip node"
        );
        // Wrapper names themselves never match.
        assert_eq!(
          find_entity_by_path(scene.wrapper, &["GameWrapper".into()], &children, &names),
          None
        );
        // Wrong deeper path with a globally existing name still misses.
        assert_eq!(
          find_entity_by_path(scene.wrapper, &["Visual".into(), "Hip".into()], &children, &names),
          None
        );
      },
    )
    .unwrap();
  }

  #[test]
  fn target_ids_come_from_full_paths() {
    let id = target_id_from_path(&["Hero".into(), "Hip".into()]);
    let names = [Name::new("Hero"), Name::new("Hip")];
    assert_eq!(id, AnimationTargetId::from_names(names.iter()));
    assert_ne!(id, target_id_from_path(&["Hip".into()]));
  }

  #[test]
  fn binding_installs_player_targets_rest_pose_and_dynamic_bounds() {
    let mut app = App::new();
    app.init_resource::<GameAssetCatalog>();
    app.init_resource::<GameAssetLoadStateTracker>();
    let scene = spawn_hierarchy(app.world_mut());
    let id = GameAssetId::new("qa", "characters/hero");
    let rig = ManifestRig {
      scene_index: 0,
      rig_profile: None,
      rig_profile_hash: "a".repeat(64),
      motion_root_path: vec!["Hero".into()],
      semantic_bones: BTreeMap::from([
        ("root".to_string(), vec!["Hero".to_string()]),
        ("hips".to_string(), vec!["Hero".to_string(), "Hip".to_string()]),
      ]),
      bone_count: 1,
      skin_count: 1,
      max_influences_per_vertex: 1,
      node_rest_sha256: "b".repeat(64),
      skin_sha256: "c".repeat(64),
    };
    app.world_mut().entity_mut(scene.wrapper).insert(crate::GameAssetInstance {
      id: id.clone(),
      version: "v1".into(),
      lod_level: None,
      automatic_lod: false,
    });
    app.world_mut().resource_mut::<GameAssetCatalog>().entries.insert(
      id.clone(),
      crate::catalog::GameAssetEntry {
        id: id.clone(),
        asset_id: "hero".into(),
        version_id: "v1".into(),
        display_name: "hero".into(),
        kind: "character_3d".into(),
        dependencies: vec![],
        image: None,
        render_image: None,
        atlas: None,
        pixels_per_world_unit: 100.0,
        scene: None,
        width: 0,
        height: 0,
        anchor: (0.5, 0.5),
        sampling: "linear".into(),
        triangles: None,
        collision: None,
        lod: None,
        rig: Some(rig),
        animation_2d: None,
        animation_3d: None,
      },
    );
    app
      .world_mut()
      .resource_mut::<GameAssetLoadStateTracker>()
      .states
      .insert(id.clone(), GameAssetLoadState::Loaded);

    app.world_mut().run_system_once(bind_character_rigs).unwrap();
    app.world_mut().flush();

    let world = app.world_mut();
    let binding = world.get::<GameAssetRigBinding>(scene.wrapper).expect("binding installed");
    assert_eq!(binding.player, scene.hero, "player sits on the motion root");
    assert!(world.get::<AnimationPlayer>(scene.hero).is_some());
    // Hero + Hip both driven, with AnimatedBy pointing at the player.
    assert_eq!(
      *world.get::<AnimationTargetId>(scene.hero).expect("hero target"),
      target_id_from_path(&["Hero".into()])
    );
    assert_eq!(
      *world.get::<AnimationTargetId>(scene.hip).expect("hip target"),
      target_id_from_path(&["Hero".into(), "Hip".into()])
    );
    assert_eq!(world.get::<AnimatedBy>(scene.hero).unwrap().0, scene.hero);
    assert_eq!(world.get::<AnimatedBy>(scene.hip).unwrap().0, scene.hero);
    // Rest pose recorded from the scene's transforms.
    assert_eq!(binding.rest.len(), 2);
    assert_eq!(binding.rest[0].1, Transform::from_xyz(1.0, 0.0, 0.0));
    // Skinned meshes opt into deformation-tracking bounds.
    assert!(world.get::<DynamicSkinnedMeshBounds>(scene.visual).is_some());
  }

  #[test]
  fn two_instances_bind_independent_players_and_targets() {
    let mut app = App::new();
    app.init_resource::<GameAssetCatalog>();
    app.init_resource::<GameAssetLoadStateTracker>();
    let first = spawn_hierarchy(app.world_mut());
    let second = spawn_hierarchy(app.world_mut());
    let id = GameAssetId::new("qa", "characters/hero");
    let rig = ManifestRig {
      scene_index: 0,
      rig_profile: None,
      rig_profile_hash: "a".repeat(64),
      motion_root_path: vec!["Hero".into()],
      semantic_bones: BTreeMap::from([("root".to_string(), vec!["Hero".to_string()])]),
      bone_count: 1,
      skin_count: 1,
      max_influences_per_vertex: 1,
      node_rest_sha256: "b".repeat(64),
      skin_sha256: "c".repeat(64),
    };
    for wrapper in [first.wrapper, second.wrapper] {
      app.world_mut().entity_mut(wrapper).insert(crate::GameAssetInstance {
        id: id.clone(),
        version: "v1".into(),
        lod_level: None,
        automatic_lod: false,
      });
    }
    app.world_mut().resource_mut::<GameAssetCatalog>().entries.insert(
      id.clone(),
      crate::catalog::GameAssetEntry {
        id: id.clone(),
        asset_id: "hero".into(),
        version_id: "v1".into(),
        display_name: "hero".into(),
        kind: "character_3d".into(),
        dependencies: vec![],
        image: None,
        render_image: None,
        atlas: None,
        pixels_per_world_unit: 100.0,
        scene: None,
        width: 0,
        height: 0,
        anchor: (0.5, 0.5),
        sampling: "linear".into(),
        triangles: None,
        collision: None,
        lod: None,
        rig: Some(rig),
        animation_2d: None,
        animation_3d: None,
      },
    );
    app
      .world_mut()
      .resource_mut::<GameAssetLoadStateTracker>()
      .states
      .insert(id.clone(), GameAssetLoadState::Loaded);

    app.world_mut().run_system_once(bind_character_rigs).unwrap();
    app.world_mut().flush();
    let world = app.world_mut();
    let first_binding = world.get::<GameAssetRigBinding>(first.wrapper).unwrap();
    let second_binding = world.get::<GameAssetRigBinding>(second.wrapper).unwrap();
    assert_ne!(first_binding.player, second_binding.player);
    // Same names, same target ids, but AnimatedBy never crosses roots.
    assert_eq!(first_binding.targets[0].1, second_binding.targets[0].1);
    assert_eq!(world.get::<AnimatedBy>(first.hero).unwrap().0, first.hero);
    assert_eq!(world.get::<AnimatedBy>(second.hero).unwrap().0, second.hero);
  }
}
