@tool
extends RefCounted
## is_scanning becomes false before the scanned index is installed (Godot 4.7.2).
## filesystem_changed also covers automatic import completion; do not start a second import.

static func scan(filesystem: EditorFileSystem, tree: SceneTree, expected: PackedStringArray = []) -> bool:
	var state := {"finished": false}
	var callback := func() -> void:
		if not filesystem.is_scanning() and not filesystem.is_importing(): state.finished = true
	filesystem.filesystem_changed.connect(callback)
	var requested := false
	var deadline := Time.get_ticks_msec() + 60000
	while Time.get_ticks_msec() < deadline:
		if not requested and not filesystem.is_scanning() and not filesystem.is_importing():
			state.finished = false
			filesystem.scan()
			# scan() may be ignored while the previous worker is awaiting its index
			# commit. Retry only after yielding back to the editor in that case.
			requested = filesystem.is_scanning() or state.finished
		if requested and state.finished and not filesystem.is_scanning() and not filesystem.is_importing():
			await tree.process_frame
			if not filesystem.is_scanning() and not filesystem.is_importing() and _indexed(filesystem, expected):
				filesystem.filesystem_changed.disconnect(callback); return true
			requested = false
		await tree.process_frame
	filesystem.filesystem_changed.disconnect(callback)
	return false

static func expected_data(manifest: Dictionary, root: String) -> PackedStringArray:
	var paths := PackedStringArray()
	for asset in manifest.assets:
		for file in asset.files:
			if String(file.path).get_extension().to_lower() in ["png", "glb"]: paths.append(root.path_join(String(file.path)))
	return paths

static func _indexed(filesystem: EditorFileSystem, paths: PackedStringArray) -> bool:
	for path in paths:
		if filesystem.get_file_type(path).is_empty() or not FileAccess.file_exists(path + ".import"): return false
		var directory := filesystem.get_filesystem_path(path.get_base_dir())
		if directory == null: return false
		var found := false
		for index in directory.get_file_count():
			if directory.get_file_path(index) == path:
				if not directory.get_file_import_is_valid(index): return false
				found = true; break
		if not found: return false
	return true

static func guard_managed_changes(root: String) -> PackedStringArray:
	var problems := PackedStringArray()
	if EditorInterface.is_playing_scene():
		problems.append("游戏正在运行。请先停止运行，再核对或导入；当前资产文件未改动。")
	for path in EditorInterface.get_unsaved_scenes():
		if path.begins_with(root + "/"):
			problems.append("受管理场景有未保存编辑，请先保存或撤销，再重试：" + path)
	return problems

static func reload_changed_open_scenes(root: String, backup: String) -> PackedStringArray:
	var problems := guard_managed_changes(root)
	if not problems.is_empty(): return problems
	for path in EditorInterface.get_open_scenes():
		if not path.begins_with(root + "/"): continue
		var previous := backup.path_join(path.substr(root.length() + 1))
		if FileAccess.file_exists(previous) and FileAccess.get_sha256(path) == FileAccess.get_sha256(previous): continue
		EditorInterface.reload_scene_from_path(path)
	return problems
