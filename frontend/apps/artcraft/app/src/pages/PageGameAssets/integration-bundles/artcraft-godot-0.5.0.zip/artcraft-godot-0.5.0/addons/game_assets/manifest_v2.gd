@tool
extends RefCounted
## Manifest 2.0 contract validation. Mirrors the authoritative Rust types in
## artcraft-services (crates/lib/game_asset_contracts/src/manifest.rs and
## manifest_validation.rs) so the Godot and Bevy consumers never drift on the
## same pack. Pure logic — no editor dependencies — so it runs headless.
##
## Deliberate boundary: rig_profile_hash is checked for shape (64 lowercase
## hex) but NOT recomputed. The services canonical hash serializes over typed
## Rust values where integers and floats stay distinct; Godot's JSON parser
## collapses both to float, so a recomputation here could disagree with the
## exporter even for valid packs. Structure-level profile validation below is
## the consumer-side guarantee instead.

const SCHEMA := "2.0"
const FEATURE_CHARACTER := "game.character3d.rig.v1"
const FEATURE_ANIMATION_2D := "game.anim2d.frames.v1"
const FEATURE_ANIMATION_3D := "game.anim3d.skeleton_map.v1"
## Features this addon implements; a 2.0 godot profile may not require more.
const SUPPORTED_FEATURES := [FEATURE_CHARACTER, FEATURE_ANIMATION_2D, FEATURE_ANIMATION_3D]
const MAX_ASSETS := 100
## Plugin data budgets shared with the 1.x parser; the contract itself only
## requires byte_length >= 1.
const MAX_FILE_BYTES := 250 * 1024 * 1024
const MAX_PACK_BYTES := 1024 * 1024 * 1024

## kind -> delivery contract (manifest_validation.rs ManifestAsset::validate).
const KIND_CONTRACT := {
	"icon_2d": {"stage": "asset", "directory": "icons", "blocks": ["image"], "main_mime": "image/png", "feature": ""},
	"sprite_2d": {"stage": "asset", "directory": "sprites", "blocks": ["image"], "main_mime": "image/png", "feature": ""},
	"prop_3d": {"stage": "asset", "directory": "props", "blocks": ["mesh"], "main_mime": "model/gltf-binary", "feature": ""},
	"character_3d": {"stage": "rigged", "directory": "characters", "blocks": ["mesh", "rig"], "main_mime": "model/gltf-binary", "feature": FEATURE_CHARACTER},
	"anim_2d": {"stage": "animation", "directory": "animations_2d", "blocks": ["animation_2d"], "main_mime": "image/png", "feature": FEATURE_ANIMATION_2D},
	"anim_3d": {"stage": "animation", "directory": "animations_3d", "blocks": ["animation_3d"], "main_mime": "model/gltf-binary", "feature": FEATURE_ANIMATION_3D},
}
const MIME_EXTENSION := {"image/png": "png", "model/gltf-binary": "glb", "application/json": "json", "text/plain": "txt"}

## The contract types deny unknown fields (serde deny_unknown_fields);
## these key tables keep the Godot parser on the same page.
const TOP_LEVEL_KEYS := ["schema_version", "pack_id", "project_id", "export_id", "generated_at", "engine_profiles", "assets"]
const ASSET_KEYS := ["asset_id", "stable_key", "display_name", "version_id", "kind", "stage", "spec_hash", "files", "dependencies", "quality", "image", "mesh", "rig", "animation_2d", "animation_3d"]
const FILE_KEYS := ["role", "ordinal", "path", "sha256", "byte_length", "mime"]
const DEPENDENCY_KEYS := ["role", "asset_id", "version_id", "rig_main_sha256"]
const RIG_KEYS := ["scene_index", "rig_profile", "rig_profile_hash", "motion_root_path", "semantic_bones", "bone_count", "skin_count", "max_influences_per_vertex", "node_rest_sha256", "skin_sha256"]
const PROFILE_KEYS := ["schema_version", "id", "revision", "unit", "up_axis", "visual_forward", "pose", "motion_root_slot", "bones", "max_bones", "max_skins", "max_influences_per_vertex", "max_nodes", "max_accessors", "max_vertices", "tolerances", "diagnostic_poses"]
const BONE_KEYS := ["slot", "allowed_parents", "rest_rotation", "rest_translation_bounds_m"]
const TOLERANCE_KEYS := ["weight_sum", "bind_matrix", "rest_pose_radians", "quaternion_norm", "deformation_position_m"]
const BOUNDS_KEYS := ["min", "max"]
const POSE_KEYS := ["id", "joints", "deformed_bounds_m", "max_vertex_displacement_m"]
const JOINT_KEYS := ["slot", "rotation"]
const ANIMATION_2D_KEYS := ["frames_file", "pixels_per_world_unit", "sampling", "alpha_mode"]
const ANIMATION_3D_KEYS := ["scene_index", "skeleton_map_file"]
const ENGINE_PROFILE_KEYS := ["id", "engine", "engine_version", "renderer_backend", "importer_version", "coordinate_conversion", "required_features", "validation_status", "animation_2d_world_unit_scale"]
const IMAGE_KEYS := ["width", "height", "alpha_mode", "color_space", "anchor", "pixels_per_world_unit", "sampling", "atlas"]
const ATLAS_KEYS := ["page_file_index", "rect", "uncropped_size", "crop_offset", "anchor", "extrude_px"]
const MESH_KEYS := ["scene_index", "unit", "up_axis", "visual_forward", "origin", "measured_dimensions_m", "triangles", "material_workflow", "collision", "lod"]
const LOD_LEVEL_KEYS := ["level", "file_index", "scene_index", "triangles", "switch_distance_m", "hysteresis_m"]
const QUALITY_KEYS := ["technical_check", "human_review"]
const ANCHOR_KEYS := ["origin", "x", "y"]
const RECT_KEYS := ["x", "y", "width", "height"]
const DIMENSION_KEYS := ["width", "height"]
const FILE_REFERENCE_KEYS := ["role", "ordinal"]

var problems: PackedStringArray = PackedStringArray()

func _fail(token: String, detail: String) -> void:
	problems.append("%s: %s" % [token, detail])

func _reject_unknown(block: Dictionary, allowed: Array, token: String, context: String) -> void:
	for key in block:
		if not (String(key) in allowed):
			_fail(token, "unknown field %s in %s" % [String(key), context])

## Validate one parsed manifest dictionary (schema_version "2.0" only).
func validate(data: Dictionary) -> bool:
	problems = PackedStringArray()
	_reject_unknown(data, TOP_LEVEL_KEYS, "invalid_manifest_identity", "manifest")
	if String(data.get("schema_version", "")) != SCHEMA:
		_fail("invalid_manifest_identity", "schema_version must be \"2.0\"")
		return false
	for field in ["pack_id", "project_id", "export_id"]:
		if not safe_identifier(String(data.get(field, ""))):
			_fail("invalid_manifest_identity", "%s is not a safe identifier" % field)
	if not _valid_timestamp(String(data.get("generated_at", ""))):
		_fail("invalid_manifest_identity", "generated_at is not an RFC3339 timestamp")
	var assets: Variant = data.get("assets")
	var profiles: Variant = data.get("engine_profiles")
	if not (assets is Array) or not (profiles is Array):
		_fail("invalid_manifest_size", "assets and engine_profiles must be arrays")
		return false
	if (assets as Array).is_empty() or (assets as Array).size() > MAX_ASSETS or (profiles as Array).is_empty():
		_fail("invalid_manifest_size", "assets 1..%d and at least one engine_profile required" % MAX_ASSETS)
		return false

	var by_asset := {}
	var required_features := {}
	var paths := {}
	var stable_paths := {}
	var total_bytes := 0.0
	for asset in assets:
		if asset is Dictionary and by_asset.has(String((asset as Dictionary).get("asset_id", ""))):
			_fail("rig_version_conflict", "asset_id listed twice: %s" % String((asset as Dictionary).get("asset_id", "")))
		_validate_asset(asset, by_asset, paths, required_features)
		if asset is Dictionary:
			# The contract allows equal stable keys across kinds (each kind
			# delivers under its own directory); within one directory the
			# managed scene paths must stay unique.
			var contract: Dictionary = KIND_CONTRACT.get(String((asset as Dictionary).get("kind", "")), {}) as Dictionary
			var stable_path := "%s/%s" % [contract.get("directory", ""), String((asset as Dictionary).get("stable_key", ""))]
			if stable_paths.has(stable_path):
				_fail("duplicate_stable_path", stable_path)
			stable_paths[stable_path] = true
		if asset is Dictionary:
			for file in asset.get("files", []) as Array:
				if not (file is Dictionary): continue
				var path := String(file.get("path", ""))
				if paths.has(path):
					_fail("duplicate_pack_path", path)
				paths[path] = true
				var length: Variant = file.get("byte_length", -1)
				if typeof(length) in [TYPE_INT, TYPE_FLOAT] and float(length) >= 0:
					total_bytes += float(length)
	if total_bytes > MAX_PACK_BYTES:
		_fail("pack_byte_length_overflow", "pack data exceeds the 1 GiB import limit")

	for asset in assets:
		if not (asset is Dictionary): continue
		for dependency in asset.get("dependencies", []) as Array:
			if not (dependency is Dictionary): continue
			var target: Dictionary = by_asset.get(String(dependency.get("asset_id", "")), {}) as Dictionary
			if target.is_empty():
				_fail("rig_unavailable", "%s depends on missing asset %s" % [asset.get("stable_key", ""), dependency.get("asset_id", "")])
				continue
			var main_sha := _main_file_sha(target)
			if target.get("asset_id", "") == asset.get("asset_id", "") or target.get("kind", "") != "character_3d" or target.get("stage", "") != "rigged" or String(target.get("version_id", "")) != String(dependency.get("version_id", "")) or main_sha != String(dependency.get("rig_main_sha256", "")):
				_fail("dependency_changed", "%s depends on %s version %s which is not the rigged character in this pack" % [asset.get("stable_key", ""), dependency.get("asset_id", ""), dependency.get("version_id", "")])

	_validate_engine_profiles(profiles as Array, required_features)
	return problems.is_empty()

func _validate_asset(asset: Variant, by_asset: Dictionary, paths: Dictionary, required_features: Dictionary) -> void:
	if not (asset is Dictionary):
		_fail("invalid_manifest_identity", "asset entry is not an object")
		return
	var a: Dictionary = asset
	var stable_key := String(a.get("stable_key", ""))
	_reject_unknown(a, ASSET_KEYS, "invalid_asset_identity", "asset " + stable_key)
	if not safe_identifier(String(a.get("asset_id", ""))) or not safe_identifier(String(a.get("version_id", ""))) or not safe_stable_key(stable_key):
		_fail("invalid_asset_identity", "asset_id/version_id/stable_key unsafe: " + stable_key)
	var display := String(a.get("display_name", ""))
	if display.strip_edges().is_empty() or display.length() > 100:
		_fail("invalid_asset_identity", "display_name empty or longer than 100 chars: " + stable_key)
	if not is_sha256(String(a.get("spec_hash", ""))):
		_fail("invalid_asset_identity", "spec_hash must be a lowercase sha256: " + stable_key)
	if not (a.get("files") is Array) or (a.get("files") as Array).is_empty():
		_fail("incomplete_file_set", stable_key)
		return
	by_asset[String(a.get("asset_id", ""))] = a

	var kind := String(a.get("kind", ""))
	var contract: Dictionary = KIND_CONTRACT.get(kind, {}) as Dictionary
	if contract.is_empty():
		_fail("invalid_asset_identity", "unknown kind %s on %s" % [kind, stable_key])
		return
	if not contract.get("feature", "").is_empty():
		required_features[contract.get("feature", "")] = true

	var files: Array = a.get("files", []) as Array
	var roles := {}
	var has_main := false
	var main_mime := ""
	for file in files:
		if not (file is Dictionary):
			_fail("invalid_file_identity", "%s has a malformed file entry" % stable_key)
			continue
		var f: Dictionary = file
		var path := String(f.get("path", ""))
		_reject_unknown(f, FILE_KEYS, "invalid_file_identity", path)
		var ordinal: Variant = f.get("ordinal", null)
		var role := String(f.get("role", ""))
		var mime := String(f.get("mime", ""))
		if not safe_pack_path(path) or not is_sha256(String(f.get("sha256", ""))):
			_fail("invalid_file_identity", "%s file %s has an unsafe path or malformed sha256" % [stable_key, path])
			continue
		var length: Variant = f.get("byte_length", -1)
		if typeof(length) not in [TYPE_INT, TYPE_FLOAT] or float(length) < 1 or float(length) > MAX_FILE_BYTES or float(length) != floor(float(length)):
			_fail("invalid_file_identity", "%s file %s has an invalid byte_length" % [stable_key, path])
		if typeof(ordinal) not in [TYPE_INT, TYPE_FLOAT] or float(ordinal) < 0 or float(ordinal) != floor(float(ordinal)):
			_fail("invalid_file_identity", "%s file %s has an invalid ordinal" % [stable_key, path])
			continue
		var ordinal_value := int(ordinal)
		var binding := "%s:%d" % [role, ordinal_value]
		if roles.has(binding):
			_fail("duplicate_file_binding", "%s repeats role/ordinal %s" % [stable_key, binding])
		roles[binding] = true
		if role == "main" and ordinal_value == 0:
			has_main = true
			main_mime = mime
		if role in ["main", "frames", "skeleton_map"] and ordinal_value != 0:
			_fail("invalid_file_ordinal", "%s file %s: role %s requires ordinal 0" % [stable_key, path, role])
		if role in ["frames", "skeleton_map"] and mime != "application/json":
			_fail("file_role_mime_mismatch", "%s file %s: role %s must be JSON" % [stable_key, path, role])
		if not contract.get("feature", "").is_empty():
			# Private-stage kinds deliver exactly the public playback files.
			var allowed := false
			match [kind, role, mime]:
				["character_3d", "main", "model/gltf-binary"], ["anim_3d", "main", "model/gltf-binary"]:
					allowed = true
				["anim_2d", "main", "image/png"], ["anim_2d", "frames", "application/json"]:
					allowed = true
				["anim_3d", "skeleton_map", "application/json"]:
					allowed = true
				[_, "preview", "image/png"]:
					allowed = true
			var expected := "assets/%s/%s/%s.%s" % [contract.get("directory", ""), stable_key, role, MIME_EXTENSION.get(mime, "?")]
			if not allowed or ordinal_value != 0 or path != expected:
				_fail("private_or_unsupported_delivery_file", "%s delivers %s; only %s is importable" % [stable_key, path, expected])
		elif role in ["frames", "skeleton_map"]:
			_fail("unexpected_animation_sidecar", "%s is a static kind but lists %s" % [stable_key, path])
	if not has_main:
		_fail("missing_main", stable_key)
		return
	if main_mime != String(contract.get("main_mime", "")):
		_fail("main_mime_mismatch", "%s main file must be %s" % [stable_key, contract.get("main_mime", "")])

	# Kind <-> stage/metadata block parity.
	if String(a.get("stage", "")) != String(contract.get("stage", "")):
		_fail("kind_metadata_mismatch", "%s kind %s requires stage %s" % [stable_key, kind, contract.get("stage", "")])
	for block in ["image", "mesh", "rig", "animation_2d", "animation_3d"]:
		var present: bool = a.get(block) is Dictionary and not (a.get(block) as Dictionary).is_empty()
		var wanted: bool = (contract.get("blocks", []) as Array).has(block)
		if present != wanted:
			_fail("kind_metadata_mismatch", "%s kind %s must%s carry a %s block" % [stable_key, kind, "" if wanted else " not", block])

	# Dependency closure: exactly one rig dependency for anim_3d, none elsewhere.
	var dependencies: Array = a.get("dependencies", []) as Array
	if kind == "anim_3d":
		if dependencies.size() != 1:
			_fail("exactly_one_rig_required", stable_key)
	elif not dependencies.is_empty():
		_fail("unexpected_dependency", stable_key)
	for dependency in dependencies:
		if not (dependency is Dictionary): continue
		var d: Dictionary = dependency
		_reject_unknown(d, DEPENDENCY_KEYS, "invalid_dependency_identity", stable_key)
		if String(d.get("role", "")) != "rig" or not safe_identifier(String(d.get("asset_id", ""))) or not safe_identifier(String(d.get("version_id", ""))) or not is_sha256(String(d.get("rig_main_sha256", ""))):
			_fail("invalid_dependency_identity", stable_key)

	if a.get("image") is Dictionary:
		_validate_image(a.get("image") as Dictionary, files, stable_key)
	if a.get("mesh") is Dictionary:
		_validate_mesh(a.get("mesh") as Dictionary, a, files, stable_key)
	if a.get("rig") is Dictionary:
		_validate_rig(a.get("rig") as Dictionary, stable_key)
	if a.get("animation_2d") is Dictionary:
		_validate_animation_2d(a.get("animation_2d") as Dictionary, files, stable_key)
	if a.get("animation_3d") is Dictionary:
		_validate_animation_3d(a.get("animation_3d") as Dictionary, files, stable_key)
	var quality: Variant = a.get("quality")
	if not (quality is Dictionary) or not ((quality as Dictionary).get("technical_check") is Dictionary) or not ((quality as Dictionary).get("human_review") is Dictionary):
		_fail("invalid_quality_reference", stable_key)
	else:
		_reject_unknown(quality as Dictionary, QUALITY_KEYS, "invalid_quality_reference", stable_key + " quality")
		var technical: Dictionary = (quality as Dictionary).get("technical_check", {}) as Dictionary
		var human: Dictionary = (quality as Dictionary).get("human_review", {}) as Dictionary
		_reject_unknown(technical, ["status", "validator_version", "report_ref"], "invalid_quality_reference", stable_key + " technical_check")
		_reject_unknown(human, ["status", "review_token"], "invalid_quality_reference", stable_key + " human_review")
		if String(technical.get("validator_version", "")).strip_edges().is_empty() or not (String(technical.get("status", "")) in ["passed", "failed", "pending"]) or not (String(human.get("status", "")) in ["passed", "rejected", "pending"]):
			_fail("invalid_quality_reference", stable_key)
		if technical.has("report_ref") and not safe_identifier(String(technical.get("report_ref", ""))):
			_fail("invalid_quality_reference", stable_key + " report_ref")
		if human.has("review_token") and not safe_identifier(String(human.get("review_token", ""))):
			_fail("invalid_quality_reference", stable_key + " review_token")

func _validate_image(image: Dictionary, files: Array, stable_key: String) -> void:
	_reject_unknown(image, IMAGE_KEYS, "invalid_image_metadata", stable_key + " image")
	if image.get("anchor") is Dictionary:
		_reject_unknown(image.get("anchor") as Dictionary, ANCHOR_KEYS, "invalid_image_metadata", stable_key + " anchor")
	var width: Variant = image.get("width")
	var height: Variant = image.get("height")
	var ppu: Variant = image.get("pixels_per_world_unit")
	if typeof(width) not in [TYPE_INT, TYPE_FLOAT] or float(width) < 1 or float(width) != floor(float(width)) or typeof(height) not in [TYPE_INT, TYPE_FLOAT] or float(height) < 1 or float(height) != floor(float(height)) or not _positive(ppu) or not _valid_anchor(image.get("anchor")):
		_fail("invalid_image_metadata", stable_key)
		return
	if String(image.get("alpha_mode", "")) != "straight" or String(image.get("color_space", "")) != "srgb":
		_fail("invalid_image_metadata", stable_key + " alpha_mode/color_space")
	if not (String(image.get("sampling", "")) in ["nearest", "linear"]):
		_fail("invalid_image_metadata", stable_key + " sampling")
	var atlas: Variant = image.get("atlas")
	if atlas == null or not (atlas is Dictionary):
		return
	if not (atlas is Dictionary) or (atlas as Dictionary).is_empty():
		return
	var a: Dictionary = atlas
	_reject_unknown(a, ATLAS_KEYS, "invalid_static_atlas_reference", stable_key + " atlas")
	for block_name in ["rect", "uncropped_size", "crop_offset"]:
		if a.get(block_name) is Dictionary:
			var allowed := RECT_KEYS if block_name == "rect" else DIMENSION_KEYS if block_name != "crop_offset" else ["x", "y"]
			_reject_unknown(a.get(block_name) as Dictionary, allowed, "invalid_static_atlas_reference", stable_key + " " + block_name)
		if a.get(block_name) == null:
			_fail("invalid_static_atlas_reference", stable_key + " atlas." + block_name)
	if a.get("anchor") is Dictionary:
		_reject_unknown(a.get("anchor") as Dictionary, ANCHOR_KEYS, "invalid_static_atlas_reference", stable_key + " atlas.anchor")
	var page: Variant = a.get("page_file_index")
	if typeof(page) not in [TYPE_INT, TYPE_FLOAT] or int(page) < 0 or int(page) >= files.size():
		_fail("invalid_static_atlas_reference", stable_key)
		return
	var page_file: Dictionary = files[int(page)] as Dictionary
	var rect: Variant = a.get("rect")
	var uncropped: Variant = a.get("uncropped_size")
	var crop: Variant = a.get("crop_offset")
	var bounds_ok := rect is Dictionary and uncropped is Dictionary and crop is Dictionary
	if bounds_ok:
		var r: Dictionary = rect
		var u: Dictionary = uncropped
		var c: Dictionary = crop
		var rw := float(r.get("width", 0))
		var rh := float(r.get("height", 0))
		if String(page_file.get("role", "")) != "atlas_page" or String(page_file.get("mime", "")) != "image/png" or rw <= 0 or rh <= 0 or float(u.get("width", 0)) != float(width) or float(u.get("height", 0)) != float(height) or not _valid_anchor(a.get("anchor")) or float(c.get("x", -1)) + rw > float(u.get("width", 0)) or float(c.get("y", -1)) + rh > float(u.get("height", 0)):
			_fail("invalid_static_atlas_reference", stable_key)
		var extrude: Variant = a.get("extrude_px")
		if typeof(extrude) not in [TYPE_INT, TYPE_FLOAT] or float(extrude) < 0:
			_fail("invalid_static_atlas_reference", stable_key + " extrude_px")
	else:
		_fail("invalid_static_atlas_reference", stable_key)

func _validate_mesh(mesh: Dictionary, asset: Dictionary, files: Array, stable_key: String) -> void:
	_reject_unknown(mesh, MESH_KEYS, "invalid_mesh_measurement", stable_key + " mesh")
	var dimensions: Variant = mesh.get("measured_dimensions_m")
	var dims_ok := dimensions is Dictionary
	if int(mesh.get("scene_index", -1)) != 0 or float(mesh.get("triangles", 0)) < 1 or float(mesh.get("triangles", 0)) != floor(float(mesh.get("triangles", 0))) or not dims_ok:
		_fail("invalid_mesh_measurement", stable_key)
		return
	var d: Dictionary = dimensions
	for axis in ["x", "y", "z"]:
		var v: Variant = d.get(axis)
		if typeof(v) not in [TYPE_INT, TYPE_FLOAT] or not is_finite(float(v)) or float(v) < 0:
			_fail("invalid_mesh_measurement", stable_key)
			return
	if float(d.get("y", 0)) <= 0:
		_fail("invalid_mesh_measurement", stable_key)
	if String(mesh.get("unit", "")) != "meter" or String(mesh.get("up_axis", "")) != "+Y" or String(mesh.get("visual_forward", "")) != "+Z" or String(mesh.get("material_workflow", "")) != "gltf_metallic_roughness":
		_fail("invalid_mesh_measurement", stable_key + " unit/axis/workflow")

	var kind := String(asset.get("kind", ""))
	var collision: Variant = mesh.get("collision")
	if not (collision is Dictionary):
		_fail("invalid_mesh_measurement", stable_key + " collision")
		return
	var c: Dictionary = collision
	match String(c.get("kind", "")):
		"none":
			_reject_unknown(c, ["kind", "unit"], "invalid_mesh_measurement", stable_key + " collision")
		"box":
			_reject_unknown(c, ["kind", "unit", "center", "half_extents"], "invalid_box_collision", stable_key + " collision")
		"box":
			if kind == "character_3d" or not _finite_array(c.get("center")) or not _positive_array(c.get("half_extents")):
				_fail("invalid_box_collision", stable_key)
		"capsule":
			_reject_unknown(c, ["kind", "unit", "center", "radius_m", "total_height_m"], "invalid_character_capsule", stable_key + " collision")
			if kind != "character_3d" or not _finite_array(c.get("center")) or not _positive(c.get("radius_m")) or not _positive(c.get("total_height_m")) or float(c.get("total_height_m", 0)) < 2.0 * float(c.get("radius_m", 0)):
				_fail("invalid_character_capsule", stable_key)
		_:
			_fail("invalid_mesh_measurement", stable_key + " collision kind")

	var lod: Variant = mesh.get("lod")
	if kind == "character_3d":
		if lod is Dictionary and not (lod as Dictionary).is_empty():
			_fail("rigged_mesh_reprocessing_unsupported", stable_key + " lod")
		if String(mesh.get("origin", "")) != "profile_defined":
			_fail("rigged_mesh_reprocessing_unsupported", stable_key + " origin")
	elif String(mesh.get("origin", "")) != "bottom_center":
		_fail("invalid_prop_origin", stable_key)
	if not (lod is Dictionary) or (lod as Dictionary).is_empty():
		return
	var levels: Variant = (lod as Dictionary).get("levels")
	if not (levels is Array) or (levels as Array).is_empty():
		_fail("invalid_lod_chain", stable_key)
		return
	var previous_level := 0
	var previous_triangles := float(mesh.get("triangles", 0))
	var previous_distance := 0.0
	for entry in levels:
		if not (entry is Dictionary):
			_fail("invalid_lod_chain", stable_key)
			continue
		var l: Dictionary = entry
		_reject_unknown(l, LOD_LEVEL_KEYS, "invalid_lod_chain", stable_key + " lod level")
		var file_index: Variant = l.get("file_index")
		var level := int(l.get("level", 0))
		var triangles := float(l.get("triangles", 0))
		var switch_distance := float(l.get("switch_distance_m", 0))
		var hysteresis := float(l.get("hysteresis_m", -1))
		if int(l.get("scene_index", -1)) != 0 or level <= previous_level or triangles < 1 or triangles >= previous_triangles or not _positive(l.get("switch_distance_m")) or switch_distance <= previous_distance or hysteresis < 0 or hysteresis > switch_distance:
			_fail("invalid_lod_chain", stable_key + " level %d" % level)
		if typeof(file_index) in [TYPE_INT, TYPE_FLOAT] and int(file_index) >= 0 and int(file_index) < files.size():
			var file: Dictionary = files[int(file_index)] as Dictionary
			if String(file.get("role", "")) != "lod" or int(file.get("ordinal", -1)) != level or String(file.get("mime", "")) != "model/gltf-binary":
				_fail("invalid_lod_chain", stable_key + " level %d file binding" % level)
		else:
			_fail("invalid_lod_chain", stable_key + " level %d file_index" % level)
		previous_level = level
		previous_triangles = triangles
		previous_distance = switch_distance

func _validate_rig(rig: Dictionary, stable_key: String) -> void:
	_reject_unknown(rig, RIG_KEYS, "invalid_rig_metadata", stable_key + " rig")
	var profile: Variant = rig.get("rig_profile")
	if not (profile is Dictionary):
		_fail("invalid_rig_metadata", stable_key + " rig_profile missing")
		return
	var p: Dictionary = profile
	_reject_unknown(p, PROFILE_KEYS, "invalid_rig_profile_identity", stable_key + " rig_profile")
	if not _validate_rig_profile(p, stable_key):
		return
	var bone_count := int(rig.get("bone_count", 0))
	var skin_count := int(rig.get("skin_count", 0))
	var influences := int(rig.get("max_influences_per_vertex", 0))
	if int(rig.get("scene_index", -1)) != 0 or bone_count < 1 or bone_count > int(p.get("max_bones", 0)) or skin_count < 1 or skin_count > int(p.get("max_skins", 0)) or influences < 1 or influences > int(p.get("max_influences_per_vertex", 0)) or not is_sha256(String(rig.get("node_rest_sha256", ""))) or not is_sha256(String(rig.get("skin_sha256", ""))) or not is_sha256(String(rig.get("rig_profile_hash", ""))):
		_fail("invalid_rig_metadata", stable_key)
	# Mapping completeness against the profile snapshot (RigProfile::validate_mapping).
	var motion_root: Variant = rig.get("motion_root_path")
	var semantic: Variant = rig.get("semantic_bones")
	if not (motion_root is Array) or not (semantic is Dictionary) or not _valid_node_path(motion_root):
		_fail("semantic_mapping_incomplete", stable_key)
		return
	var slots := {}
	for bone in p.get("bones", []) as Array:
		if bone is Dictionary:
			slots[String((bone as Dictionary).get("slot", ""))] = true
	if (semantic as Dictionary).size() != slots.size():
		_fail("semantic_mapping_incomplete", stable_key + " mapping covers %d of %d slots" % [(semantic as Dictionary).size(), slots.size()])
		return
	var seen := {}
	for slot in slots:
		if not (semantic as Dictionary).has(slot):
			_fail("semantic_mapping_incomplete", stable_key + " slot " + slot)
			continue
		var path: Variant = (semantic as Dictionary).get(slot)
		if not (path is Array):
			_fail("semantic_mapping_incomplete", stable_key + " slot " + slot)
			continue
		var key := "/"
		for part in path as Array:
			key += String(part) + "/"
		if seen.has(key):
			_fail("ambiguous_semantic_mapping", stable_key + " " + key)
		seen[key] = true
		if not _path_starts_with(path, motion_root):
			_fail("semantic_bone_outside_motion_root", stable_key + " slot " + slot)
	if (semantic as Dictionary).has(String(p.get("motion_root_slot", ""))) and not _paths_equal((semantic as Dictionary).get(String(p.get("motion_root_slot", ""))), motion_root):
		_fail("semantic_mapping_incomplete", stable_key + " motion root slot")
	for path in (semantic as Dictionary).values():
		if path is Array and not _valid_node_path(path):
			_fail("ambiguous_semantic_mapping", stable_key)

func _validate_rig_profile(p: Dictionary, stable_key: String) -> bool:
	if String(p.get("schema_version", "")) != "game.rig_profile.v1" or not safe_identifier(String(p.get("id", ""))) or not safe_identifier(String(p.get("revision", ""))):
		_fail("invalid_rig_profile_identity", stable_key)
		return false
	if String(p.get("unit", "")) != "meter" or String(p.get("up_axis", "")) != "+Y" or String(p.get("visual_forward", "")) != "+Z" or String(p.get("pose", "")) not in ["t_pose", "a_pose"]:
		_fail("invalid_rig_profile_identity", stable_key + " unit/axis/pose")
	for budget in ["max_bones", "max_skins", "max_nodes", "max_accessors"]:
		if int(p.get(budget, 0)) < 1:
			_fail("invalid_rig_budget", stable_key)
			return false
	if int(p.get("max_influences_per_vertex", 0)) < 1 or int(p.get("max_influences_per_vertex", 0)) > 4 or float(p.get("max_vertices", 0)) < 1:
		_fail("invalid_rig_budget", stable_key)
		return false
	var tolerances: Variant = p.get("tolerances")
	if not (tolerances is Dictionary):
		_fail("invalid_rig_tolerance", stable_key)
		return false
	var t: Dictionary = tolerances
	_reject_unknown(t, TOLERANCE_KEYS, "invalid_rig_tolerance", stable_key)
	for key in ["weight_sum", "bind_matrix", "rest_pose_radians", "quaternion_norm", "deformation_position_m"]:
		var v: Variant = t.get(key)
		if typeof(v) not in [TYPE_INT, TYPE_FLOAT] or not is_finite(float(v)) or float(v) < 0:
			_fail("invalid_rig_tolerance", stable_key)
			return false
	if float(t.get("weight_sum", 1)) >= 1.0 or float(t.get("quaternion_norm", 1)) >= 1.0 or float(t.get("rest_pose_radians", 4)) > PI:
		_fail("invalid_rig_tolerance", stable_key)
		return false
	var bones: Variant = p.get("bones")
	if not (bones is Array) or (bones as Array).is_empty() or (bones as Array).size() - 1 > int(p.get("max_bones", 0)):
		_fail("invalid_semantic_slots", stable_key)
		return false
	var slots := {}
	for bone in bones:
		if bone is Dictionary:
			slots[String((bone as Dictionary).get("slot", ""))] = true
	if slots.size() != (bones as Array).size() or not slots.has(String(p.get("motion_root_slot", ""))):
		_fail("invalid_semantic_slots", stable_key)
		return false
	for bone in bones:
		if not (bone is Dictionary):
			continue
		var b: Dictionary = bone
		_reject_unknown(b, BONE_KEYS, "invalid_bone_rule", stable_key + " bone " + String(b.get("slot", "")))
		if b.get("rest_translation_bounds_m") is Dictionary:
			_reject_unknown(b.get("rest_translation_bounds_m") as Dictionary, BOUNDS_KEYS, "invalid_vector_bounds", stable_key)
		if not safe_stable_key(String(b.get("slot", ""))) or not _unit_quaternion(b.get("rest_rotation"), float(t.get("quaternion_norm", 0))):
			_fail("invalid_bone_rule", stable_key)
			continue
		if not _valid_bounds(b.get("rest_translation_bounds_m")):
			_fail("invalid_vector_bounds", stable_key + " bone " + String(b.get("slot", "")))
		var parents: Variant = b.get("allowed_parents")
		if not (parents is Array) or (parents as Array).is_empty():
			_fail("invalid_semantic_parent", stable_key)
			continue
		var unique_parents := {}
		for parent in parents:
			# null permits a scene root and counts as one distinct parent.
			var parent_key := String(parent) if parent != null else " scene-root "
			if parent != null and (String(parent) == String(b.get("slot", "")) or not slots.has(String(parent))):
				_fail("invalid_semantic_parent", stable_key + " bone " + String(b.get("slot", "")))
			unique_parents[parent_key] = true
		if unique_parents.size() != (parents as Array).size():
			_fail("invalid_semantic_parent", stable_key + " duplicate parent of " + String(b.get("slot", "")))
	# Every slot must reach an explicitly permitted scene root.
	var rooted := {}
	for _iteration in (bones as Array).size():
		for bone in bones:
			if not (bone is Dictionary): continue
			var slot := String((bone as Dictionary).get("slot", ""))
			if rooted.has(slot): continue
			for parent in (bone as Dictionary).get("allowed_parents", []) as Array:
				if parent == null or rooted.has(String(parent)):
					rooted[slot] = true
					break
	if rooted.size() != slots.size():
		_fail("cyclic_semantic_parent_contract", stable_key)
		return false
	var poses: Variant = p.get("diagnostic_poses")
	if not (poses is Array) or (poses as Array).is_empty():
		_fail("diagnostic_poses_required", stable_key)
		return false
	var pose_ids := {}
	for pose in poses:
		if not (pose is Dictionary):
			continue
		var pose_dict: Dictionary = pose
		_reject_unknown(pose_dict, POSE_KEYS, "invalid_diagnostic_pose", stable_key + " pose")
		if pose_dict.get("deformed_bounds_m") is Dictionary:
			_reject_unknown(pose_dict.get("deformed_bounds_m") as Dictionary, BOUNDS_KEYS, "invalid_vector_bounds", stable_key)
		var id := String(pose_dict.get("id", ""))
		if not safe_stable_key(id) or pose_ids.has(id) or not (pose_dict.get("joints") is Array) or (pose_dict.get("joints") as Array).is_empty() or not _positive(pose_dict.get("max_vertex_displacement_m")) or not _valid_bounds(pose_dict.get("deformed_bounds_m")):
			_fail("invalid_diagnostic_pose", stable_key)
			return false
		pose_ids[id] = true
		for joint in pose_dict.get("joints", []) as Array:
			if joint is Dictionary:
				_reject_unknown(joint as Dictionary, JOINT_KEYS, "invalid_diagnostic_joint", stable_key + " joint")
			if not (joint is Dictionary) or not slots.has(String((joint as Dictionary).get("slot", ""))) or not _unit_quaternion((joint as Dictionary).get("rotation"), float(t.get("quaternion_norm", 0))):
				_fail("invalid_diagnostic_joint", stable_key)
				return false
	return true

func _validate_animation_2d(animation: Dictionary, files: Array, stable_key: String) -> void:
	_reject_unknown(animation, ANIMATION_2D_KEYS, "invalid_frames_reference", stable_key + " animation_2d")
	var reference: Variant = animation.get("frames_file")
	if reference is Dictionary:
		_reject_unknown(reference as Dictionary, FILE_REFERENCE_KEYS, "invalid_frames_reference", stable_key + " frames_file")
	var references_frames := false
	for file in files:
		if file is Dictionary and String((file as Dictionary).get("role", "")) == "frames" and int((file as Dictionary).get("ordinal", -1)) == 0 and String((file as Dictionary).get("mime", "")) == "application/json":
			references_frames = true
	if not (reference is Dictionary) or String((reference as Dictionary).get("role", "")) != "frames" or int((reference as Dictionary).get("ordinal", -1)) != 0 or not references_frames or not _positive(animation.get("pixels_per_world_unit")):
		_fail("invalid_frames_reference", stable_key)
	if not (String(animation.get("sampling", "")) in ["nearest", "linear"]) or String(animation.get("alpha_mode", "")) != "straight":
		_fail("invalid_frames_reference", stable_key + " sampling/alpha_mode")

func _validate_animation_3d(animation: Dictionary, files: Array, stable_key: String) -> void:
	_reject_unknown(animation, ANIMATION_3D_KEYS, "invalid_skeleton_map_reference", stable_key + " animation_3d")
	var reference: Variant = animation.get("skeleton_map_file")
	if reference is Dictionary:
		_reject_unknown(reference as Dictionary, FILE_REFERENCE_KEYS, "invalid_skeleton_map_reference", stable_key + " skeleton_map_file")
	var references_map := false
	for file in files:
		if file is Dictionary and String((file as Dictionary).get("role", "")) == "skeleton_map" and int((file as Dictionary).get("ordinal", -1)) == 0 and String((file as Dictionary).get("mime", "")) == "application/json":
			references_map = true
	if int(animation.get("scene_index", -1)) != 0 or not (reference is Dictionary) or String((reference as Dictionary).get("role", "")) != "skeleton_map" or int((reference as Dictionary).get("ordinal", -1)) != 0 or not references_map:
		_fail("invalid_skeleton_map_reference", stable_key)

func _validate_engine_profiles(profiles: Array, required_features: Dictionary) -> void:
	var ids := {}
	var has_godot := false
	for profile in profiles:
		if not (profile is Dictionary):
			_fail("invalid_engine_profile_identity", "profile entry is not an object")
			continue
		var p: Dictionary = profile
		_reject_unknown(p, ENGINE_PROFILE_KEYS, "invalid_engine_profile_identity", "engine profile")
		var id := String(p.get("id", ""))
		if not safe_identifier(id) or ids.has(id) or not _valid_engine_version(String(p.get("engine_version", ""))):
			_fail("invalid_engine_profile_identity", id)
		ids[id] = true
		for field in ["renderer_backend", "importer_version", "coordinate_conversion"]:
			if not safe_identifier(String(p.get(field, ""))):
				_fail("invalid_engine_profile_identity", "%s %s" % [id, field])
		if String(p.get("engine", "")) not in ["godot", "bevy"] or String(p.get("validation_status", "")) not in ["unverified", "verified"]:
			_fail("invalid_engine_profile_identity", id + " engine/validation_status")
		var features: Variant = p.get("required_features")
		if not (features is Array):
			_fail("missing_engine_feature_contract", id)
			continue
		var declared := {}
		for feature in features:
			if not safe_identifier(String(feature)) or declared.has(String(feature)):
				_fail("missing_engine_feature_contract", "%s feature %s" % [id, feature])
			declared[String(feature)] = true
		for feature in required_features:
			if not declared.has(String(feature)):
				_fail("missing_engine_feature_contract", "%s must declare required feature %s" % [id, feature])
		var scale: Variant = p.get("animation_2d_world_unit_scale")
		if scale != null and not _positive(scale):
			_fail("invalid_world_unit_conversion", id)
		if String(p.get("engine", "")) == "godot":
			has_godot = true
			if required_features.has(FEATURE_ANIMATION_2D) and (scale == null or absf(float(scale) - 100.0) > 0.0001):
				_fail("godot_animation_world_unit_conversion_required", id)
			for feature in declared:
				if not SUPPORTED_FEATURES.has(feature):
					problems.append("此组件尚不支持 2.0 特性 %s（%s）。请先升级 Godot 集成组件。" % [feature, id])
	if not has_godot:
		problems.append("no godot engine_profile in the pack (import would be unverified)")

func _main_file_sha(asset: Dictionary) -> String:
	for file in asset.get("files", []) as Array:
		if file is Dictionary and String((file as Dictionary).get("role", "")) == "main" and int((file as Dictionary).get("ordinal", -1)) == 0:
			return String((file as Dictionary).get("sha256", ""))
	return ""

## Value helpers (value_checks.rs + manifest_validation.rs parity).

static func safe_identifier(value: String) -> bool:
	if value.is_empty() or value.length() > 128:
		return false
	for i in value.length():
		var c := value.unicode_at(i)
		var lower_letter := (c >= 97 and c <= 122) or (c >= 65 and c <= 90)
		var digit := c >= 48 and c <= 57
		if not ((lower_letter or digit) or c == 95 or (i > 0 and (c == 46 or c == 45))):
			return false
	return true

static func safe_stable_key(value: String) -> bool:
	if not safe_clip_name(value):
		return false
	var stem := value.split(".")[0].to_lower()
	return not stem in ["con", "nul", "aux", "prn"] and not (stem.length() == 4 and stem.left(3) in ["com", "lpt"] and stem[3] >= "1" and stem[3] <= "9")

static func safe_clip_name(value: String) -> bool:
	if value.is_empty() or value.length() > 64:
		return false
	if not (value[0] >= "a" and value[0] <= "z"):
		return false
	for i in value.length():
		var c := value[i]
		if not ((c >= "a" and c <= "z") or (c >= "0" and c <= "9") or c == "_"):
			return false
	return true

static func is_sha256(value: String) -> bool:
	return value.length() == 64 and RegEx.create_from_string("^[0-9a-f]{64}$").search(value) != null

## safe_pack_path: ASCII path grammar + reserved device stems (manifest_validation.rs).
static func safe_pack_path(value: String) -> bool:
	if value.is_empty() or value.length() > 255 or value.begins_with("/"):
		return false
	for i in value.length():
		var c := value.unicode_at(i)
		var alnum := (c >= 97 and c <= 122) or (c >= 65 and c <= 90) or (c >= 48 and c <= 57)
		if not alnum and not c in [95, 45, 46, 47]:
			return false
	for part in value.split("/"):
		if part.is_empty() or part in [".", ".."] or part.ends_with("."):
			return false
		var stem := part.split(".")[0].to_lower()
		if stem in ["con", "nul", "aux", "prn"]:
			return false
		if stem.length() == 4 and stem.left(3) in ["com", "lpt"] and stem[3] >= "1" and stem[3] <= "9":
			return false
	return true

static func _valid_anchor(anchor: Variant) -> bool:
	if not (anchor is Dictionary):
		return false
	var a: Dictionary = anchor
	if String(a.get("origin", "")) != "top_left":
		return false
	for axis in ["x", "y"]:
		var v: Variant = a.get(axis)
		if typeof(v) not in [TYPE_INT, TYPE_FLOAT] or not is_finite(float(v)) or float(v) < 0 or float(v) > 1:
			return false
	return true

static func _valid_timestamp(value: String) -> bool:
	return RegEx.create_from_string("^\\d{4}-\\d{2}-\\d{2}[Tt]\\d{2}:\\d{2}:\\d{2}(\\.\\d+)?([Zz]|[+-]\\d{2}:\\d{2})$").search(value) != null

static func _valid_engine_version(value: String) -> bool:
	var numbers := value
	var suffix := ""
	if value.contains("-"):
		var parts := value.split("-", true, 1)
		numbers = parts[0]
		suffix = parts[1]
	var segments := numbers.split(".")
	if segments.size() < 2 or segments.size() > 3:
		return false
	for segment in segments:
		if segment.is_empty() or not segment.is_valid_int():
			return false
	for i in suffix.length():
		var c := suffix.unicode_at(i)
		var alnum := (c >= 97 and c <= 122) or (c >= 65 and c <= 90) or (c >= 48 and c <= 57)
		if not alnum and c != 46:
			return false
	return true

static func _positive(value: Variant) -> bool:
	return typeof(value) in [TYPE_INT, TYPE_FLOAT] and is_finite(float(value)) and float(value) > 0

static func _finite_array(value: Variant) -> bool:
	if not (value is Array) or (value as Array).size() != 3:
		return false
	for item in value:
		if typeof(item) not in [TYPE_INT, TYPE_FLOAT] or not is_finite(float(item)):
			return false
	return true

static func _positive_array(value: Variant) -> bool:
	if not _finite_array(value):
		return false
	for item in value:
		if float(item) <= 0:
			return false
	return true

static func _unit_quaternion(value: Variant, tolerance: float) -> bool:
	if not (value is Array) or (value as Array).size() != 4:
		return false
	var sum := 0.0
	for item in value:
		if typeof(item) not in [TYPE_INT, TYPE_FLOAT] or not is_finite(float(item)):
			return false
		sum += float(item) * float(item)
	return absf(sqrt(sum) - 1.0) <= tolerance

static func _valid_bounds(value: Variant) -> bool:
	if not (value is Dictionary):
		return false
	var b: Dictionary = value
	for side in ["min", "max"]:
		if not _finite_array(b.get(side)):
			return false
	for i in 3:
		if float((b.get("min") as Array)[i]) > float((b.get("max") as Array)[i]):
			return false
	return true

static func _valid_node_path(path: Variant) -> bool:
	if not (path is Array) or (path as Array).is_empty():
		return false
	for part in path:
		var s := String(part)
		if s.is_empty() or s.contains("/") or s.contains("\\") or s.contains(":") or s.contains(".") or s.contains("%"):
			return false
	return true

static func _paths_equal(a: Variant, b: Variant) -> bool:
	if not (a is Array) or not (b is Array) or (a as Array).size() != (b as Array).size():
		return false
	for i in (a as Array).size():
		if String((a as Array)[i]) != String((b as Array)[i]):
			return false
	return true

static func _path_starts_with(path: Variant, prefix: Variant) -> bool:
	if not (path is Array) or not (prefix is Array) or (path as Array).size() < (prefix as Array).size():
		return false
	return _paths_equal((path as Array).slice(0, (prefix as Array).size()), prefix)
