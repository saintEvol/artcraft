//! Transactional local-pack installation for the supported developer command.
use std::collections::{BTreeMap, HashMap, HashSet};
use std::fs;
use std::fs::FileTimes;
use std::io::Read;
use std::sync::atomic::{AtomicU64, Ordering};
use std::path::{Component, Path};
use std::time::{SystemTime, UNIX_EPOCH};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use crate::manifest::{
  verify_pack_files, GameAssetPackManifest, ManifestDependency, MAX_MANIFEST_BYTES,
};

pub const IMPORTER_VERSION: &str = "game_assets_bevy_1@0.3.0";
pub const JOURNAL_FORMAT_V1: &str = "artcraft-bevy-install.v1";
pub const JOURNAL_FORMAT_V2: &str = "artcraft-bevy-install.v2";
static NONCE_COUNTER: AtomicU64 = AtomicU64::new(0);

#[derive(Clone, Copy, PartialEq, Eq)]
pub enum ConflictDecision {
  Stop,
  Keep,
  Copy,
  Replace,
}

/// One asset of the FINAL install description (merged manifest), as
/// recorded in the v2 journal and hashed into install_state_hash.
#[derive(Clone)]
struct InstalledAsset {
  asset_id: String,
  stable_key: String,
  version_id: String,
  kind: String,
  stage: Option<String>,
  dependencies: Vec<ManifestDependency>,
  /// (role, pack-relative path, sha256) in manifest order.
  files: Vec<(String, String, String)>,
}

impl InstalledAsset {
  fn main_sha256(&self) -> Option<&str> {
    self
      .files
      .iter()
      .find(|(role, _, _)| role == "main")
      .map(|(_, _, sha)| sha.as_str())
      .or_else(|| self.files.first().map(|(_, _, sha)| sha.as_str()))
  }

  fn main_path(&self) -> Option<&str> {
    self
      .files
      .iter()
      .find(|(role, _, _)| role == "main")
      .map(|(_, path, _)| path.as_str())
      .or_else(|| self.files.first().map(|(_, path, _)| path.as_str()))
  }
}

fn installed_assets_from_manifest(manifest: &GameAssetPackManifest) -> Vec<InstalledAsset> {
  manifest
    .assets
    .iter()
    .map(|asset| InstalledAsset {
      asset_id: asset.asset_id.clone(),
      stable_key: asset.stable_key.clone(),
      version_id: asset.version_id.clone(),
      kind: asset.kind.clone(),
      stage: asset.stage.clone(),
      dependencies: asset.dependencies.clone().unwrap_or_default(),
      files: asset
        .files
        .iter()
        .map(|file| (file.role.clone(), file.path.clone(), file.sha256.to_lowercase()))
        .collect(),
    })
    .collect()
}

/// install_state_hash (plan 12.1): SHA-256 over the canonical final
/// description — every asset's identity/version/stage/dependencies/
/// verified file digests plus the managed file map. Deliberately excludes
/// project_id/pack_id: a copy namespace regenerates it from the ACTUAL
/// installed description, which is content-identical.
fn install_state_hash(assets: &[InstalledAsset], files: &BTreeMap<String, String>) -> String {
  let mut ordered: Vec<&InstalledAsset> = assets.iter().collect();
  ordered.sort_by(|a, b| a.asset_id.cmp(&b.asset_id));
  let mut hash = Sha256::new();
  hash.update(b"artcraft-install-state.v2\0");
  for asset in ordered {
    hash.update(asset.asset_id.as_bytes());
    hash.update(b"\0");
    hash.update(asset.stable_key.as_bytes());
    hash.update(b"\0");
    hash.update(asset.version_id.as_bytes());
    hash.update(b"\0");
    hash.update(asset.kind.as_bytes());
    hash.update(b"\0");
    hash.update(asset.stage.as_deref().unwrap_or("\0").as_bytes());
    hash.update(b"\0");
    let mut deps = asset.dependencies.clone();
    deps.sort_by(|a, b| {
      (a.role.clone(), a.asset_id.clone(), a.version_id.clone())
        .cmp(&(b.role.clone(), b.asset_id.clone(), b.version_id.clone()))
    });
    for dependency in deps {
      hash.update(dependency.role.as_bytes());
      hash.update(b"\0");
      hash.update(dependency.asset_id.as_bytes());
      hash.update(b"\0");
      hash.update(dependency.version_id.as_bytes());
      hash.update(b"\0");
      hash.update(dependency.rig_main_sha256.to_lowercase().as_bytes());
      hash.update(b"\0");
    }
    hash.update(b"\0");
    for (role, path, sha) in &asset.files {
      hash.update(role.as_bytes());
      hash.update(b"\0");
      hash.update(path.as_bytes());
      hash.update(b"\0");
      hash.update(sha.as_bytes());
      hash.update(b"\0");
    }
    hash.update(b"\0");
  }
  for (path, sha) in files {
    hash.update(path.as_bytes());
    hash.update(b"\0");
    hash.update(sha.as_bytes());
    hash.update(b"\0");
  }
  hex::encode(hash.finalize())
}

/// Final dependency-graph check (plan 12.1): with the merged description
/// in hand, every anim_3d must still resolve its rig inside the FINAL set
/// — including rigs and animations merely RETAINED from the previous
/// install. Retained rig main files are re-hashed from actual bytes so a
/// locally modified rig cannot masquerade as the animation's dependency.
fn validate_final_graph(
  final_assets: &[InstalledAsset],
  delivered: &HashSet<String>,
  destination: &Path,
) -> Vec<String> {
  let mut problems = Vec::new();
  let by_id: HashMap<&str, &InstalledAsset> =
    final_assets.iter().map(|asset| (asset.asset_id.as_str(), asset)).collect();
  for asset in final_assets {
    if asset.kind != "anim_3d" {
      continue;
    }
    if asset.dependencies.len() != 1 {
      problems.push(format!(
        "动画 {} 的 rig 依赖数量为 {}，必须恰好一个。",
        asset.stable_key,
        asset.dependencies.len()
      ));
      continue;
    }
    let dependency = &asset.dependencies[0];
    let Some(target) = by_id.get(dependency.asset_id.as_str()) else {
      problems.push(format!(
        "动画 {} 依赖的角色 {} 不在最终安装集合内。",
        asset.stable_key, dependency.asset_id
      ));
      continue;
    };
    if target.kind != "character_3d"
      || target.stage.as_deref() != Some("rigged")
      || target.version_id != dependency.version_id
      || target.main_sha256() != Some(dependency.rig_main_sha256.to_lowercase().as_str())
    {
      problems.push(format!(
        "动画 {} 依赖 {}@{} 与最终安装的角色 {}@{}（kind {}）不匹配，不能保留旧动画配新角色或反之。",
        asset.stable_key,
        dependency.asset_id,
        dependency.version_id,
        target.asset_id,
        target.version_id,
        target.kind
      ));
      continue;
    }
    // Retained (not delivered now) rigs: verify actual bytes, not the
    // recorded version string.
    if !delivered.contains(&target.asset_id) {
      if let Some(path) = target.main_path() {
        let file = destination.join(path);
        match sha(&file) {
          Ok(actual) if actual == dependency.rig_main_sha256.to_lowercase() => {},
          Ok(_) => problems.push(format!(
            "保留的角色主文件 {path} 实际字节与依赖声明不一致，不能作为 {} 的 rig。",
            asset.stable_key
          )),
          Err(error) => problems.push(format!(
            "保留的角色主文件 {path} 无法读取（{error}），不能验证 {} 的依赖。",
            asset.stable_key
          )),
        }
      }
    }
  }
  problems
}

pub fn install_pack(
  source: &Path,
  assets_root: &Path,
  decision: ConflictDecision,
) -> Result<Value, String> {
  no_links(source, "manifest.json")?;
  let mut text = String::new();
  fs::File::open(source.join("manifest.json"))
    .and_then(|file| file.take((MAX_MANIFEST_BYTES + 1) as u64).read_to_string(&mut text))
    .map_err(|e| format!("无法读取资源包清单：{e}"))?;
  if text.len() > MAX_MANIFEST_BYTES {
    return Err("清单超过 4 MiB。".into());
  }
  let manifest = GameAssetPackManifest::parse_and_validate(&text)
    .map_err(|p| p.into_iter().map(|p| p.message).collect::<Vec<_>>().join("; "))?;
  if manifest.assets.len() > 500 {
    return Err("每份包最多导入 500 项资产，请分批交付。".into());
  }
  if !manifest.engine_profiles.iter().any(|p| p.engine == "bevy" && p.engine_version == "0.20.0") {
    return Err("此组件要求包内 Bevy profile 为 0.20.0。".into());
  }
  let mut raw: Value = serde_json::from_str(&text).map_err(|e| e.to_string())?;
  let incoming = raw.clone();
  let mut namespace = manifest.project_namespace();
  if !safe_namespace(&namespace) {
    return Err("项目命名空间不安全。".into());
  }
  let mut total = 0u64;
  let mut paths = HashMap::new();
  for asset in &manifest.assets {
    for file in &asset.files {
      check_relative(&file.path)?;
      if !file.path.starts_with("assets/") {
        return Err("资源文件必须位于 assets 目录，不能覆盖导入状态。".into());
      }
      no_links(source, &file.path)?;
      let allowed = match file.mime.as_str() {
        "image/png" => "png",
        "model/gltf-binary" => "glb",
        "application/json" => "json",
        _ => return Err("包内只接受 PNG、GLB 和 JSON 数据。".into()),
      };
      if Path::new(&file.path).extension().and_then(|v| v.to_str()) != Some(allowed) {
        return Err(format!("扩展名与文件类型不同：{}", file.path));
      }
      if file.byte_length > 250 * 1024 * 1024 {
        return Err("单文件超过 250 MiB。".into());
      }
      if let Some(old) = paths.insert(file.path.clone(), file.sha256.clone()) {
        if old != file.sha256 {
          return Err("同一路径声明了不同内容。".into());
        }
      } else {
        total = total.checked_add(file.byte_length).ok_or("文件大小溢出")?;
      }
    }
  }
  if total > 1024 * 1024 * 1024 {
    return Err("包数据超过 1 GiB。".into());
  }
  let integrity = verify_pack_files(&manifest, &source.to_string_lossy());
  if !integrity.is_empty() {
    return Err(integrity.iter().map(|p| p.message.clone()).collect::<Vec<_>>().join("; "));
  }
  fs::create_dir_all(assets_root).map_err(|e| e.to_string())?;
  no_links(assets_root, "game_assets")?;
  let parent = assets_root.join("game_assets");
  fs::create_dir_all(&parent).map_err(|e| e.to_string())?;
  if decision == ConflictDecision::Copy {
    namespace = format!(
      "{}_copy_{}",
      namespace.chars().take(40).collect::<String>(),
      &hex::encode(Sha256::digest(nonce().as_bytes()))[..16]
    );
  }
  let lock_name = format!(".artcraft-lock-{namespace}");
  no_links(&parent, &lock_name)?;
  let lock = fs::OpenOptions::new()
    .create(true)
    .read(true)
    .write(true)
    .open(parent.join(lock_name))
    .map_err(|e| e.to_string())?;
  lock.try_lock().map_err(|_| "同一项目还有导入正在进行，请稍后再试。")?;
  let destination = parent.join(&namespace);
  no_links(&parent, &namespace)?;
  let marker = parent.join(format!(".artcraft-pending-{namespace}.json"));
  recover(&destination, &marker)?;
  let existed = destination.exists();
  let journal_path = destination.join("import_journal.json");
  // Journal gate (plan 12.1): a journal that is missing on an existing
  // install, corrupt, or of an unknown format STOPS the update — it is
  // never treated as an empty installation. Fresh installs (no
  // destination yet) legitimately have no journal.
  let journal: Value = if journal_path.exists() {
    let parsed: Value = serde_json::from_slice(
      &fs::read(&journal_path).map_err(|e| e.to_string())?,
    )
    .map_err(|_| "已有导入记录损坏，停止更新而不是当作空安装。".to_string())?;
    match parsed.get("format").and_then(Value::as_str) {
      Some(JOURNAL_FORMAT_V1) | Some(JOURNAL_FORMAT_V2) => parsed,
      other => {
        return Err(format!(
          "已有导入记录格式未知（{other:?}），停止更新而不是当作空安装。"
        ));
      },
    }
  } else if existed {
    return Err("已有安装缺少导入记录，停止更新而不是当作空安装。".into());
  } else {
    json!({"format": JOURNAL_FORMAT_V2, "files": {}})
  };
  let recorded = journal.get("files").and_then(Value::as_object).ok_or("导入记录格式无效。")?;
  let mut conflicts = Vec::new();
  for (path, expected) in &paths {
    no_links(&destination, path)?;
    let file = destination.join(path);
    if file.exists()
      && (recorded.get(path).and_then(Value::as_str).is_none()
        || sha(&file)? != recorded[path].as_str().unwrap_or(""))
    {
      conflicts.push(path.clone());
    }
    if let Some(old) = recorded.get(path) {
      if !file.exists() && old.as_str() != Some(expected) {
        conflicts.push(path.clone());
      }
    }
  }
  if !conflicts.is_empty() && decision == ConflictDecision::Stop {
    return Ok(report(
      &raw,
      "update",
      "conflicts",
      vec![],
      json!({"conflicts":conflicts,"message":"发现本地修改，未写入当前资源；可保留、另存或备份后替换。"}),
    ));
  }
  if decision == ConflictDecision::Keep {
    return Ok(report(
      &raw,
      "update",
      "partial",
      vec![],
      json!({"conflicts":conflicts,"message":"已保留当前全部版本，没有应用本次更新。"}),
    ));
  }
  let delivered =
    manifest.assets.iter().map(|a| a.asset_id.clone()).collect::<std::collections::HashSet<_>>();
  // Merge retained assets. When either side is 2.0 the FINAL description
  // is 2.0: carried 1.x entries are normalized (stage/dependencies/
  // ordinal filled) so merging a static 1.x pack into a 2.0 install
  // never downgrades the description or drops dependencies (plan 12.1).
  let old_major = if destination.join("manifest.json").exists() {
    let old: Value = serde_json::from_slice(
      &fs::read(destination.join("manifest.json")).map_err(|e| e.to_string())?,
    )
    .map_err(|_| "旧清单无效，未替换当前资源。".to_string())?;
    let mut carried: Vec<Value> = old
      .get("assets")
      .and_then(Value::as_array)
      .map(|assets| {
        assets
          .iter()
          .filter(|asset| {
            asset.get("asset_id").and_then(Value::as_str).is_some_and(|id| !delivered.contains(id))
          })
          .cloned()
          .collect()
      })
      .unwrap_or_default();
    let major = old
      .get("schema_version")
      .and_then(Value::as_str)
      .and_then(|version| version.split('.').next().and_then(|part| part.parse::<u64>().ok()))
      .unwrap_or(1);
    if major == 2 || manifest.schema_major() == 2 {
      for asset in &mut carried {
        normalize_carried_asset_v2(asset);
      }
    }
    let assets = raw["assets"].as_array_mut().ok_or("清单格式无效")?;
    assets.extend(carried);
    // Engine profiles describe the installed set: profiles the incoming
    // pack doesn't re-deliver stay (their declared features still cover
    // the carried 2.0 assets).
    if let (Some(incoming_profiles), Some(old_profiles)) = (
      raw["engine_profiles"].as_array_mut(),
      old.get("engine_profiles").and_then(Value::as_array),
    ) {
      let incoming_ids: HashSet<String> = incoming_profiles
        .iter()
        .filter_map(|profile| profile.get("id").and_then(Value::as_str).map(String::from))
        .collect();
      for profile in old_profiles {
        if profile.get("id").and_then(Value::as_str).is_some_and(|id| !incoming_ids.contains(id)) {
          incoming_profiles.push(profile.clone());
        }
      }
    }
    major
  } else {
    1
  };
  if manifest.schema_major() == 2 || old_major == 2 {
    raw["schema_version"] = json!("2.0");
    if let Some(assets) = raw["assets"].as_array_mut() {
      for asset in assets.iter_mut() {
        normalize_carried_asset_v2(asset);
      }
    }
  }
  if decision == ConflictDecision::Copy {
    raw["source_project_id"] = raw["project_id"].clone();
    raw["project_id"] = json!(namespace);
  }
  raw["delivered_asset_ids"] =
    json!(manifest.assets.iter().map(|a| a.asset_id.clone()).collect::<Vec<_>>());
  // Final dependency-graph check BEFORE staging anything and BEFORE the
  // strict re-validation: the graph is the merged description, not just
  // this pack, and an inconsistent one (retained old animation + replaced
  // new rig) must surface as a conflicts report, not a hard error. The
  // draft parse only reshapes already-validated entries.
  let merged_draft: GameAssetPackManifest = serde_json::from_value(raw.clone())
    .map_err(|_| "合并后的受管理清单无效，未覆盖当前文件。".to_string())?;
  let draft_assets = installed_assets_from_manifest(&merged_draft);
  let graph_problems = validate_final_graph(&draft_assets, &delivered, &destination);
  if !graph_problems.is_empty() {
    return Ok(report(
      &incoming,
      "update",
      "conflicts",
      vec![],
      json!({
        "conflicts": [],
        "dependency_problems": graph_problems,
        "message": "最终安装图依赖不完整或哈希不匹配，已保留当前全部资源；请同时更新动画与其 rig。",
      }),
    ));
  }
  let merged = GameAssetPackManifest::parse_and_validate(&raw.to_string())
    .map_err(|_| "合并后的受管理清单无效，未覆盖当前文件。".to_string())?;
  let final_assets = installed_assets_from_manifest(&merged);
  let mut retained_files: BTreeMap<String, Value> = BTreeMap::new();
  if let Some(recorded) = journal.get("files").and_then(Value::as_object) {
    for (path, hash) in recorded {
      retained_files.insert(path.clone(), hash.clone());
    }
  }
  for (path, hash) in &paths {
    retained_files.insert(path.clone(), json!(hash));
  }
  let stamp = nonce();
  let stage = parent.join(format!(".artcraft-stage-{stamp}"));
  let backup = parent.join(format!(".artcraft-backup-{stamp}"));
  fs::create_dir(&stage).map_err(|e| e.to_string())?;
  if existed {
    copy_tree(&destination, &stage)?;
  }
  for asset in &manifest.assets {
    for file in &asset.files {
      let target = stage.join(&file.path);
      fs::create_dir_all(target.parent().ok_or("目标目录缺失")?).map_err(|e| e.to_string())?;
      if target.is_file() && sha(&target)? == file.sha256.to_lowercase() {
        continue;
      }
      fs::copy(source.join(&file.path), &target).map_err(|e| e.to_string())?;
      if sha(&target)? != file.sha256.to_lowercase() {
        return Err("准备后的文件校验不一致，未替换当前资源。".into());
      }
    }
  }
  fs::write(
    stage.join("manifest.json"),
    serde_json::to_vec_pretty(&raw).map_err(|e| e.to_string())?,
  )
  .map_err(|e| e.to_string())?;
  // Journal v2: per-asset records (identity/version/stage/dependencies/
  // verified main hash/all managed files) plus the whole managed file map
  // and the install_state_hash over that final description.
  let files_for_hash: BTreeMap<String, String> = retained_files
    .iter()
    .map(|(path, hash)| (path.clone(), hash.as_str().unwrap_or_default().to_string()))
    .collect();
  let state_hash = install_state_hash(&final_assets, &files_for_hash);
  let mut journal_assets: Vec<&InstalledAsset> = final_assets.iter().collect();
  journal_assets.sort_by(|a, b| a.asset_id.cmp(&b.asset_id));
  let journal_records: Vec<Value> = journal_assets
    .iter()
    .map(|asset| {
      json!({
        "asset_id": asset.asset_id,
        "stable_key": asset.stable_key,
        "version_id": asset.version_id,
        "kind": asset.kind,
        "stage": asset.stage,
        "dependencies": asset.dependencies.iter().map(|dependency| json!({
          "role": dependency.role,
          "asset_id": dependency.asset_id,
          "version_id": dependency.version_id,
          "rig_main_sha256": dependency.rig_main_sha256.to_lowercase(),
        })).collect::<Vec<_>>(),
        "main_sha256": asset.main_sha256(),
        "files": asset.files.iter().map(|(role, path, sha)| json!({
          "role": role, "path": path, "sha256": sha,
        })).collect::<Vec<_>>(),
      })
    })
    .collect();
  fs::write(
    stage.join("import_journal.json"),
    serde_json::to_vec_pretty(&json!({
      "format": JOURNAL_FORMAT_V2,
      "files": retained_files,
      "assets": journal_records,
      "install_state_hash": state_hash,
    }))
    .map_err(|e| e.to_string())?,
  )
  .map_err(|e| e.to_string())?;
  let pending = json!({"format":"artcraft-bevy-transaction.v1","stage":stage.file_name().unwrap().to_string_lossy(),"backup":backup.file_name().unwrap().to_string_lossy(),"committed":false});
  fs::write(&marker, serde_json::to_vec(&pending).unwrap()).map_err(|e| e.to_string())?;
  if existed {
    fs::rename(&destination, &backup).map_err(|e| e.to_string())?;
  }
  if let Err(error) = fs::rename(&stage, &destination) {
    recover(&destination, &marker)?;
    return Err(format!("替换未完成，已请求恢复：{error}"));
  }
  let mut committed = pending;
  committed["committed"] = json!(true);
  fs::write(&marker, serde_json::to_vec(&committed).unwrap()).map_err(|e| e.to_string())?;
  fs::remove_file(&marker).map_err(|e| e.to_string())?;
  let assets = manifest
    .assets
    .iter()
    .map(|a| json!({"asset_id":a.asset_id,"version_id":a.version_id,"status":"imported"}))
    .collect();
  Ok(report(
    &incoming,
    if existed { "update" } else { "import" },
    "succeeded",
    assets,
    json!({"managed_root":destination,"previous_files":if existed {Some(backup)} else {None},"missing_files_are_retained":true,"install_state_hash":state_hash}),
  ))
}

/// Lift a 1.x asset entry into 2.0 form when a merge produces a 2.0 final
/// description: fill the required stage/dependencies/ordinal fields the
/// 1.x exporter never wrote. Entries that already carry them are untouched.
fn normalize_carried_asset_v2(asset: &mut Value) {
  if asset.get("stage").is_none() {
    let stage = match asset.get("kind").and_then(Value::as_str) {
      Some("character_3d") => "rigged",
      Some("anim_2d" | "anim_3d") => "animation",
      _ => "asset",
    };
    asset["stage"] = json!(stage);
  }
  if asset.get("dependencies").is_none() {
    asset["dependencies"] = json!([]);
  }
  if let Some(files) = asset.get_mut("files").and_then(Value::as_array_mut) {
    for file in files {
      if file.get("ordinal").is_none() {
        file["ordinal"] = json!(0);
      }
    }
  }
}

pub fn report(
  manifest: &Value,
  operation: &str,
  status: &str,
  assets: Vec<Value>,
  detail: Value,
) -> Value {
  json!({"schema_version":"game-assets-engine-report.v1","pack_id":manifest.get("pack_id"),"engine":"bevy","engine_version":"0.20.0","importer_version":IMPORTER_VERSION,"operation":operation,"status":status,"rendered":false,"assets":assets,"detail":detail})
}

fn recover(destination: &Path, marker: &Path) -> Result<(), String> {
  if !marker.exists() {
    return Ok(());
  }
  let data: Value = serde_json::from_slice(&fs::read(marker).map_err(|e| e.to_string())?)
    .map_err(|_| "恢复记录无效，保留当前内容。")?;
  if data["format"] != "artcraft-bevy-transaction.v1" {
    return Err("恢复记录不属于此组件。".into());
  }
  let parent = destination.parent().ok_or("恢复目录无效")?;
  let stage_name = data["stage"].as_str().ok_or("恢复记录缺少工作目录")?;
  let backup_name = data["backup"].as_str().ok_or("恢复记录缺少备份目录")?;
  for name in [stage_name, backup_name] {
    check_relative(name)?;
    if name.contains('/') || !name.starts_with(".artcraft-") {
      return Err("恢复目录不属于组件。".into());
    }
  }
  let stage = parent.join(stage_name);
  let backup = parent.join(backup_name);
  if data["committed"] != true {
    if destination.exists() && stage.exists() && !backup.exists() {
      return fs::remove_file(marker).map_err(|e| e.to_string());
    }
    if destination.exists() {
      if stage.exists() {
        return Err("工作目录冲突，请保留当前文件并核对恢复记录。".into());
      }
      fs::rename(destination, &stage).map_err(|e| e.to_string())?;
    }
    if backup.exists() {
      fs::rename(backup, destination).map_err(|e| e.to_string())?;
    }
  }
  fs::remove_file(marker).map_err(|e| e.to_string())
}

fn safe_namespace(value: &str) -> bool {
  !value.is_empty()
    && value.len() <= 64
    && value.bytes().all(|b| b.is_ascii_lowercase() || b.is_ascii_digit() || b == b'_')
    && value.as_bytes()[0].is_ascii_lowercase()
}
fn check_relative(value: &str) -> Result<(), String> {
  if value.is_empty()
    || value.contains(['\\', ':'])
    || Path::new(value).components().any(|c| !matches!(c, Component::Normal(_)))
  {
    Err(format!("不安全的相对路径：{value}"))
  } else {
    Ok(())
  }
}
fn no_links(root: &Path, relative: &str) -> Result<(), String> {
  check_relative(relative)?;
  let mut path = root.to_path_buf();
  for part in Path::new(relative).components() {
    path.push(part);
    if let Ok(meta) = fs::symlink_metadata(&path) {
      if meta.file_type().is_symlink() {
        return Err("资源路径不能经过符号链接。".into());
      }
    }
  }
  Ok(())
}
fn sha(path: &Path) -> Result<String, String> {
  Ok(hex::encode(Sha256::digest(fs::read(path).map_err(|e| e.to_string())?)))
}
fn nonce() -> String {
  format!(
    "{}-{}-{}",
    std::process::id(),
    SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_nanos(),
    NONCE_COUNTER.fetch_add(1, Ordering::Relaxed)
  )
}
fn copy_tree(source: &Path, destination: &Path) -> Result<(), String> {
  for entry in fs::read_dir(source).map_err(|e| e.to_string())? {
    let entry = entry.map_err(|e| e.to_string())?;
    let meta = entry.file_type().map_err(|e| e.to_string())?;
    let target = destination.join(entry.file_name());
    if meta.is_symlink() {
      return Err("已有目录包含符号链接，未替换当前资源。".into());
    }
    if meta.is_dir() {
      fs::create_dir_all(&target).map_err(|e| e.to_string())?;
      copy_tree(&entry.path(), &target)?;
    } else {
      let modified = entry.metadata().and_then(|metadata| metadata.modified()).map_err(|e| e.to_string())?;
      // Keep an already-open handle: copying may make the new file read-only.
      let file = fs::OpenOptions::new().create_new(true).write(true).open(&target)
        .map_err(|e| e.to_string())?;
      fs::copy(entry.path(), &target).map_err(|e| e.to_string())?;
      file.set_times(FileTimes::new().set_modified(modified))
        .map_err(|e| format!("无法保留原文件的修改时间：{e}"))?;
    }
  }
  Ok(())
}

#[cfg(test)]
mod tests {
  use super::*;
  use std::path::PathBuf;

  struct Sandbox(PathBuf);
  impl Sandbox {
    fn new() -> Self {
      let p = std::env::temp_dir().join(format!("artcraft-install-test-{}", nonce()));
      fs::create_dir(&p).unwrap();
      Self(p)
    }
  }
  impl Drop for Sandbox {
    fn drop(&mut self) {
      let _ = fs::remove_dir_all(&self.0);
    }
  }

  #[test]
  fn conflict_choices_keep_original_and_copy_uses_a_different_identity_domain() {
    let sandbox = Sandbox::new();
    let source = sandbox.0.join("source");
    let assets = sandbox.0.join("assets");
    write_fixture(&source, &[("a", "v1")]);
    let first = install_pack(&source, &assets, ConflictDecision::Stop).unwrap();
    assert_eq!(first["status"], "succeeded");
    let destination = assets.join("game_assets/qa_game");
    let file = destination.join("assets/a/main.png");
    fs::write(&file, b"my local change").unwrap();
    write_fixture(&source, &[("a", "v2")]);
    assert_eq!(
      install_pack(&source, &assets, ConflictDecision::Stop).unwrap()["status"],
      "conflicts"
    );
    assert_eq!(
      install_pack(&source, &assets, ConflictDecision::Keep).unwrap()["status"],
      "partial"
    );
    assert_eq!(fs::read(&file).unwrap(), b"my local change");
    let copy = install_pack(&source, &assets, ConflictDecision::Copy).unwrap();
    let root = PathBuf::from(copy["detail"]["managed_root"].as_str().unwrap());
    assert_ne!(root, destination);
    let managed: Value =
      serde_json::from_slice(&fs::read(root.join("manifest.json")).unwrap()).unwrap();
    assert_ne!(managed["project_id"], "qa_game");
    assert_eq!(fs::read(&file).unwrap(), b"my local change");
    let replaced = install_pack(&source, &assets, ConflictDecision::Replace).unwrap();
    let backup = PathBuf::from(replaced["detail"]["previous_files"].as_str().unwrap());
    assert_eq!(fs::read(backup.join("assets/a/main.png")).unwrap(), b"my local change");
  }

  #[test]
  fn unchanged_files_keep_their_modification_times_and_read_only_permissions() {
    let sandbox = Sandbox::new();
    let source = sandbox.0.join("source");
    let assets = sandbox.0.join("assets");
    write_fixture(&source, &[("a", "v1"), ("b", "v1")]);
    install_pack(&source, &assets, ConflictDecision::Stop).unwrap();
    let destination = assets.join("game_assets/qa_game");
    let old = UNIX_EPOCH + std::time::Duration::from_nanos(1_600_000_000_123_456_789);
    for name in ["a", "b"] {
      let path = destination.join(format!("assets/{name}/main.png"));
      fs::OpenOptions::new().write(true).open(&path).unwrap()
        .set_times(FileTimes::new().set_modified(old)).unwrap();
    }
    let read_only = destination.join("assets/b/main.png");
    let mut permissions = fs::metadata(&read_only).unwrap().permissions();
    permissions.set_readonly(true);
    fs::set_permissions(&read_only, permissions).unwrap();
    write_fixture(&source, &[("a", "v2")]);
    install_pack(&source, &assets, ConflictDecision::Stop).unwrap();
    for name in ["a", "b"] {
      assert_eq!(fs::metadata(destination.join(format!("assets/{name}/main.png"))).unwrap().modified().unwrap(), old);
    }
    assert!(fs::metadata(read_only).unwrap().permissions().readonly());
  }

  #[test]
  fn keep_without_conflicts_does_not_apply_an_update() {
    let sandbox = Sandbox::new();
    let source = sandbox.0.join("source");
    let assets = sandbox.0.join("assets");
    write_fixture(&source, &[("a", "v1")]);
    install_pack(&source, &assets, ConflictDecision::Stop).unwrap();
    let installed = assets.join("game_assets/qa_game/manifest.json");
    let original = fs::read(&installed).unwrap();
    write_fixture(&source, &[("a", "v2")]);
    let kept = install_pack(&source, &assets, ConflictDecision::Keep).unwrap();
    assert_eq!(kept["status"], "partial");
    assert_eq!(fs::read(installed).unwrap(), original);
  }

  #[test]
  fn partial_update_retains_old_catalog_ids_files_and_expected_hashes() {
    let sandbox = Sandbox::new();
    let source = sandbox.0.join("source");
    let assets = sandbox.0.join("assets");
    write_fixture(&source, &[("a", "v1"), ("b", "v1")]);
    install_pack(&source, &assets, ConflictDecision::Stop).unwrap();
    write_fixture(&source, &[("a", "v2")]);
    let update = install_pack(&source, &assets, ConflictDecision::Stop).unwrap();
    assert_eq!(update["status"], "succeeded");
    assert_eq!(update["assets"].as_array().unwrap().len(), 1);
    let destination = assets.join("game_assets/qa_game");
    let managed: Value =
      serde_json::from_slice(&fs::read(destination.join("manifest.json")).unwrap()).unwrap();
    assert_eq!(managed["assets"].as_array().unwrap().len(), 2);
    assert!(destination.join("assets/b/main.png").exists());
    let journal: Value =
      serde_json::from_slice(&fs::read(destination.join("import_journal.json")).unwrap()).unwrap();
    assert!(journal["files"].get("assets/b/main.png").is_some());
  }

  #[test]
  fn interrupted_swap_recovers_before_or_after_directory_rename() {
    let sandbox = Sandbox::new();
    let root = sandbox.0.join("current");
    let stage = sandbox.0.join(".artcraft-stage-test");
    let backup = sandbox.0.join(".artcraft-backup-test");
    let marker = sandbox.0.join("pending.json");
    fs::create_dir(&root).unwrap();
    fs::write(root.join("original"), b"keep").unwrap();
    fs::create_dir(&stage).unwrap();
    fs::write(stage.join("new"), b"new").unwrap();
    let pending = json!({"format":"artcraft-bevy-transaction.v1","stage":".artcraft-stage-test","backup":".artcraft-backup-test","committed":false});
    fs::write(&marker, pending.to_string()).unwrap();
    recover(&root, &marker).unwrap();
    assert!(root.join("original").exists());
    fs::rename(&root, &backup).unwrap();
    fs::rename(&stage, &root).unwrap();
    fs::write(&marker, pending.to_string()).unwrap();
    recover(&root, &marker).unwrap();
    assert!(root.join("original").exists());
    assert!(!root.join("new").exists());
  }

  fn write_fixture(root: &Path, assets: &[(&str, &str)]) {
    let bytes=hex::decode("89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000a49444154789c63000100000500010d0a2db40000000049454e44ae426082").unwrap();
    let items=assets.iter().map(|(id,version)|{let path=format!("assets/{id}/main.png");fs::create_dir_all(root.join(format!("assets/{id}"))).unwrap();fs::write(root.join(&path),&bytes).unwrap();json!({"asset_id":id,"stable_key":id,"version_id":version,"kind":"icon_2d","files":[{"role":"main","path":path,"sha256":hex::encode(Sha256::digest(&bytes)),"byte_length":bytes.len(),"mime":"image/png"}],"image":{"width":1,"height":1,"sampling":"linear"}})}).collect::<Vec<_>>();
    fs::write(root.join("manifest.json"),json!({"schema_version":"1.1","pack_id":"p","project_id":"qa_game","export_id":"export","engine_profiles":[{"id":"bevy","engine":"bevy","engine_version":"0.20.0"}],"assets":items}).to_string()).unwrap();
  }

  /// The generated 2.0 pack fixture (script/artcraft/game-assets/
  /// generate_pack_v2_fixtures.py writes it; keep both in sync).
  fn pack_v2_root() -> PathBuf {
    PathBuf::from(format!(
      "{}/../../../test_data/game_assets/pack_v2_minimal",
      env!("CARGO_MANIFEST_DIR")
    ))
  }

  fn copy_pack_v2(target: &Path) {
    fs::create_dir_all(target).unwrap();
    copy_tree(&pack_v2_root(), target).expect("copy pack_v2_minimal fixture");
  }

  fn read_manifest_json(root: &Path) -> Value {
    serde_json::from_slice(&fs::read(root.join("manifest.json")).unwrap()).unwrap()
  }

  fn read_journal(root: &Path) -> Value {
    serde_json::from_slice(&fs::read(root.join("import_journal.json")).unwrap()).unwrap()
  }

  /// Rewrite the copied fixture so the hero asset becomes `version` with
  /// `glb` bytes (bumping every dependency hash that must follow it).
  fn rewrite_hero(target: &Path, version: &str, glb: &[u8]) {
    fs::write(target.join("assets/characters/hero/main.glb"), glb).unwrap();
    let sha = hex::encode(Sha256::digest(glb));
    let mut manifest = read_manifest_json(target);
    for asset in manifest["assets"].as_array_mut().unwrap() {
      if asset["asset_id"] == json!("hero") {
        asset["version_id"] = json!(version);
        asset["files"][0]["sha256"] = json!(sha);
        asset["files"][0]["byte_length"] = json!(glb.len());
      }
      if asset["asset_id"] == json!("spin_3d") {
        asset["dependencies"][0]["version_id"] = json!(version);
        asset["dependencies"][0]["rig_main_sha256"] = json!(sha);
      }
    }
    fs::write(target.join("manifest.json"), serde_json::to_vec_pretty(&manifest).unwrap()).unwrap();
  }

  /// Drop the animation assets from the copied fixture's manifest so an
  /// update delivers ONLY the character (retained-anim conflict case).
  fn keep_only_character(target: &Path) {
    let mut manifest = read_manifest_json(target);
    manifest["assets"] = json!(
      manifest["assets"]
        .as_array()
        .unwrap()
        .iter()
        .filter(|asset| asset["asset_id"] == json!("hero"))
        .cloned()
        .collect::<Vec<_>>()
    );
    fs::write(target.join("manifest.json"), serde_json::to_vec_pretty(&manifest).unwrap()).unwrap();
  }

  /// Any byte change produces a still-valid GLB for the hero main file.
  fn mutated_hero_glb() -> Vec<u8> {
    let mut bytes = fs::read(pack_v2_root().join("assets/characters/hero/main.glb")).unwrap();
    // Flip a payload byte inside the BIN chunk (after header + JSON).
    let last = bytes.len() - 1;
    bytes[last] = bytes[last].wrapping_add(1);
    bytes
  }

  #[test]
  fn v2_pack_installs_with_a_v2_journal_and_a_stable_state_hash() {
    let sandbox = Sandbox::new();
    let assets = sandbox.0.join("assets");
    let first_source = sandbox.0.join("pack_a");
    let second_source = sandbox.0.join("pack_b");
    copy_pack_v2(&first_source);
    copy_pack_v2(&second_source);

    let first = install_pack(&first_source, &assets, ConflictDecision::Stop).unwrap();
    assert_eq!(first["status"], "succeeded", "{first}");
    let hash = first["detail"]["install_state_hash"].as_str().unwrap().to_string();
    assert_eq!(hash.len(), 64);

    // Same content into a second sandbox: the state hash is content-stable
    // (independent of paths/timestamps/namespace writes).
    let second = install_pack(&second_source, &sandbox.0.join("assets_b"), ConflictDecision::Stop)
      .unwrap();
    assert_eq!(
      second["detail"]["install_state_hash"].as_str(),
      Some(hash.as_str()),
      "identical packs must produce an identical install_state_hash"
    );

    let destination = assets.join("game_assets/game_assets_v2");
    let journal = read_journal(&destination);
    assert_eq!(journal["format"], "artcraft-bevy-install.v2");
    assert_eq!(journal["install_state_hash"], json!(hash));
    let records = journal["assets"].as_array().unwrap();
    assert_eq!(records.len(), 3, "journal records every final asset");
    let spin = records.iter().find(|a| a["asset_id"] == json!("spin_3d")).unwrap();
    assert_eq!(spin["kind"], "anim_3d");
    assert_eq!(spin["dependencies"][0]["asset_id"], "hero");
    assert_eq!(
      spin["main_sha256"],
      spin["files"].as_array().unwrap()[0]["sha256"]
    );
    let hero = records.iter().find(|a| a["asset_id"] == json!("hero")).unwrap();
    assert_eq!(hero["stage"], "rigged");
    // walk's frames.json is a managed file too.
    assert!(journal["files"]
      .as_object()
      .unwrap()
      .contains_key("assets/animations_2d/walk/frames.json"));

    // Changing content (new hero version + synced dependency) must change
    // the state hash.
    rewrite_hero(&first_source, "rig_v2", &mutated_hero_glb());
    let updated = install_pack(&first_source, &assets, ConflictDecision::Stop).unwrap();
    assert_eq!(updated["status"], "succeeded", "{updated}");
    let new_hash = updated["detail"]["install_state_hash"].as_str().unwrap();
    assert_ne!(new_hash, hash, "content change must change install_state_hash");
  }

  #[test]
  fn replacing_a_rig_while_retaining_its_old_animation_is_rejected() {
    let sandbox = Sandbox::new();
    let source = sandbox.0.join("source");
    let assets = sandbox.0.join("assets");
    copy_pack_v2(&source);
    install_pack(&source, &assets, ConflictDecision::Stop).unwrap();
    let destination = assets.join("game_assets/game_assets_v2");
    let original_journal = fs::read(destination.join("import_journal.json")).unwrap();
    let original_manifest = fs::read(destination.join("manifest.json")).unwrap();

    // Deliver ONLY a new hero version; the installed spin_3d keeps
    // depending on rig_v1 bytes.
    rewrite_hero(&source, "rig_v2", &mutated_hero_glb());
    keep_only_character(&source);
    let rejected = install_pack(&source, &assets, ConflictDecision::Replace).unwrap();
    assert_eq!(rejected["status"], "conflicts", "{rejected}");
    let problems = rejected["detail"]["dependency_problems"].as_array().unwrap();
    assert!(
      problems.iter().any(|problem| problem.as_str().unwrap().contains("不匹配")),
      "{rejected}"
    );
    // Even Replace cannot push an inconsistent final graph: the existing
    // set is untouched, byte for byte.
    assert_eq!(fs::read(destination.join("import_journal.json")).unwrap(), original_journal);
    assert_eq!(fs::read(destination.join("manifest.json")).unwrap(), original_manifest);
    assert!(destination.join("assets/animations_3d/spin/main.glb").exists());
  }

  #[test]
  fn synchronized_rig_and_animation_updates_pass_the_final_graph() {
    let sandbox = Sandbox::new();
    let source = sandbox.0.join("source");
    let assets = sandbox.0.join("assets");
    copy_pack_v2(&source);
    install_pack(&source, &assets, ConflictDecision::Stop).unwrap();
    let destination = assets.join("game_assets/game_assets_v2");

    // Same pack, but the clip is re-versioned against the new rig bytes.
    rewrite_hero(&source, "rig_v2", &mutated_hero_glb());
    let mut manifest = read_manifest_json(&source);
    for asset in manifest["assets"].as_array_mut().unwrap() {
      if asset["asset_id"] == json!("spin_3d") {
        asset["version_id"] = json!("clip_v2");
      }
    }
    fs::write(source.join("manifest.json"), serde_json::to_vec_pretty(&manifest).unwrap()).unwrap();

    let updated = install_pack(&source, &assets, ConflictDecision::Stop).unwrap();
    assert_eq!(updated["status"], "succeeded", "{updated}");
    let journal = read_journal(&destination);
    let hero = journal["assets"]
      .as_array()
      .unwrap()
      .iter()
      .find(|a| a["asset_id"] == json!("hero"))
      .unwrap();
    assert_eq!(hero["version_id"], "rig_v2");
    let spin = journal["assets"]
      .as_array()
      .unwrap()
      .iter()
      .find(|a| a["asset_id"] == json!("spin_3d"))
      .unwrap();
    assert_eq!(spin["version_id"], "clip_v2");
    assert_eq!(spin["dependencies"][0]["version_id"], "rig_v2");
    // The managed manifest keeps the full merged description.
    let merged = read_manifest_json(&destination);
    assert_eq!(merged["schema_version"], "2.0");
  }

  #[test]
  fn missing_corrupt_or_unknown_journals_stop_the_update() {
    let sandbox = Sandbox::new();
    let source = sandbox.0.join("source");
    let assets = sandbox.0.join("assets");
    copy_pack_v2(&source);
    install_pack(&source, &assets, ConflictDecision::Stop).unwrap();
    let destination = assets.join("game_assets/game_assets_v2");
    let original = fs::read(destination.join("manifest.json")).unwrap();

    // A genuine 1.x-era journal (all managed files listed, v1 format) is
    // still readable: the update migrates it to v2 instead of failing.
    let v2_files = read_journal(&destination)["files"].clone();
    fs::write(
      destination.join("import_journal.json"),
      serde_json::to_vec(&json!({"format": "artcraft-bevy-install.v1", "files": v2_files}))
        .unwrap(),
    )
    .unwrap();
    let migrated = install_pack(&source, &assets, ConflictDecision::Stop).unwrap();
    assert_eq!(migrated["status"], "succeeded", "{migrated}");
    assert_eq!(read_journal(&destination)["format"], "artcraft-bevy-install.v2");

    fs::remove_file(destination.join("import_journal.json")).unwrap();
    let error = install_pack(&source, &assets, ConflictDecision::Stop).unwrap_err();
    assert!(error.contains("缺少导入记录"), "{error}");

    fs::write(destination.join("import_journal.json"), b"{ not json").unwrap();
    let error = install_pack(&source, &assets, ConflictDecision::Stop).unwrap_err();
    assert!(error.contains("损坏"), "{error}");

    fs::write(
      destination.join("import_journal.json"),
      serde_json::to_vec(&json!({"format": "some-future-v9", "files": {}})).unwrap(),
    )
    .unwrap();
    let error = install_pack(&source, &assets, ConflictDecision::Stop).unwrap_err();
    assert!(error.contains("格式未知"), "{error}");

    assert_eq!(fs::read(destination.join("manifest.json")).unwrap(), original);
  }

  #[test]
  fn a_static_1x_update_merges_into_a_2_0_install_without_dropping_dependencies() {
    let sandbox = Sandbox::new();
    let v2_source = sandbox.0.join("v2_source");
    let v1_source = sandbox.0.join("v1_source");
    let assets = sandbox.0.join("assets");
    copy_pack_v2(&v2_source);
    install_pack(&v2_source, &assets, ConflictDecision::Stop).unwrap();
    let destination = assets.join("game_assets/game_assets_v2");

    // The static 1.x update must target the SAME namespace to merge into
    // the existing 2.0 install.
    write_fixture(&v1_source, &[("gem", "v1")]);
    let mut v1_manifest = read_manifest_json(&v1_source);
    v1_manifest["project_id"] = json!("game_assets_v2");
    fs::write(v1_source.join("manifest.json"), serde_json::to_vec(&v1_manifest).unwrap())
      .unwrap();
    let merged = install_pack(&v1_source, &assets, ConflictDecision::Stop).unwrap();
    assert_eq!(merged["status"], "succeeded", "{merged}");

    let manifest = read_manifest_json(&destination);
    assert_eq!(manifest["schema_version"], "2.0", "final description stays 2.0");
    let spin = manifest["assets"]
      .as_array()
      .unwrap()
      .iter()
      .find(|a| a["asset_id"] == json!("spin_3d"))
      .unwrap();
    assert_eq!(
      spin["dependencies"][0]["asset_id"],
      "hero",
      "2.0 dependencies survive a 1.x static merge"
    );
    let gem = manifest["assets"]
      .as_array()
      .unwrap()
      .iter()
      .find(|a| a["asset_id"] == json!("gem"))
      .unwrap();
    assert_eq!(gem["stage"], "asset", "carried 1.x entries are normalized");
    assert_eq!(gem["dependencies"], json!([]));
    assert_eq!(gem["files"][0]["ordinal"], 0);
    // The journal covers both worlds.
    let journal = read_journal(&destination);
    assert_eq!(journal["assets"].as_array().unwrap().len(), 4);
  }
}
