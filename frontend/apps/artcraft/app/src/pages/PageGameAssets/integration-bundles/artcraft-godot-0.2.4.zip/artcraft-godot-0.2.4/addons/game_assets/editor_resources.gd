@tool
extends RefCounted
## Resume outside the scan/import stack; wait for the actual reimport event.

static func scan(filesystem: EditorFileSystem, tree: SceneTree) -> bool:
	filesystem.scan()
	return await _settle(filesystem, tree)

static func reimport(filesystem: EditorFileSystem, tree: SceneTree, files: PackedStringArray) -> bool:
	if files.is_empty(): return true
	var expected: Dictionary = {}
	for path in files: expected[path] = true
	var state := {"seen": {}, "finished": false}
	var callback := func(paths: PackedStringArray) -> void:
		for path in paths: state.seen[path] = true
		state.finished = expected.keys().all(func(path: String) -> bool: return state.seen.has(path))
	filesystem.resources_reimported.connect(callback)
	filesystem.call_deferred("reimport_files", files)
	var deadline := Time.get_ticks_msec() + 60000
	while not state.finished or filesystem.is_scanning() or filesystem.is_importing():
		if Time.get_ticks_msec() >= deadline:
			filesystem.resources_reimported.disconnect(callback)
			return false
		await tree.process_frame
	filesystem.resources_reimported.disconnect(callback)
	return true

static func _settle(filesystem: EditorFileSystem, tree: SceneTree) -> bool:
	var deadline := Time.get_ticks_msec() + 60000
	await tree.process_frame
	while filesystem.is_scanning() or filesystem.is_importing():
		if Time.get_ticks_msec() >= deadline: return false
		await tree.process_frame
	return true
