# Artcraft Godot 集成 0.2.4

支持 Godot 4.7.2。集成组件包含可执行插件代码；工作台另行下载的资产包只包含数据。两份 ZIP 分别解压。

1. 可以直接在 Godot 打开本组件的 `project.godot`。接入自己的工程时，只复制 `addons/game_assets`，然后在项目设置的插件页启用 GameAssets。
2. 在 GameAssets 面板选择资源包中包含 `manifest.json` 的目录，点击“核对清单与更新差异”。
3. 核对新增、更新、保持和本地修改冲突，再点击“导入这份包 / 应用更新”。默认遇到冲突停止；也可以保留当前工程版本、另存整包副本，或保留完整备份后替换。
4. 点击“打开资产预览”。2D 按 64px 背包格显示，模型保持米制。生成的 `game_assets/<项目身份>/scenes/*.tscn` 可拖入自己的场景，引用路径和已有 UID 在更新中保持。
5. “保存导入报告”记录导入结果。实际运行预览后点击“打开运行报告目录”，回到工作台当前交付记录上传 JSON。导入、加载、实际渲染和适合游戏的判断各自记录。

更新时继续使用同一工程和管理目录。自定义节点放在自己的场景中；直接修改受管理文件会在更新前被识别。旧资产不会因为新包没有列出就被删除，替换前的目录保留在报告中的备份位置。中断后再次核对会先处理恢复记录，不把半份更新报告成成功。

资源支持：透明 PNG、单场景自包含 GLB（scene_index 0）、图集、单资产采样/锚点、显式 LOD、none/box 碰撞。`Sprite2D` 的单位为像素；PPU 元数据供游戏自己的世界缩放使用，背包 UI 显示大小可单独设置。物理节点仅在清单声明 box 时建立。

命令行使用与编辑器相同组件：

```sh
godot --headless --editor --path /path/to/project --script res://addons/game_assets/import_cli.gd -- /path/to/unpacked-pack
```

首次导入与运行报告均保存在 Godot 工程的 `user://game_assets_reports` 中。命令会显示实际位置。

本预览工程包含“资源预览”打包配置。导入后可构建 PCK 并使用插件显示的预览场景路径运行：

```sh
godot --headless --path . --export-pack '资源预览' /path/to/preview.pck
godot --main-pack /path/to/preview.pck res://game_assets/项目身份/preview.tscn
```

自己的游戏应选择实际主场景及所需导出平台，保留所引用资源的依赖。集成不会替你更改主场景或全局渲染/采样设置。
