@tool
extends RefCounted
## Preserve old file timestamps so an unrelated update does not reimport every
## model or mark unchanged open scenes as modified outside the editor.

var problems: PackedStringArray = []

func preserve_tree(source: String, destination: String) -> bool:
	if not _plain_tree(source): return false
	var absolute_source := ProjectSettings.globalize_path(source)
	var absolute_destination := ProjectSettings.globalize_path(destination)
	var output: Array = []
	var status := -1
	if OS.get_name() in ["macOS", "Linux", "FreeBSD", "NetBSD", "OpenBSD"]:
		status = OS.execute("/bin/cp", PackedStringArray(["-pR", "-P", absolute_source.path_join("."), absolute_destination]), output, true)
	elif OS.get_name() == "Windows":
		var script := """$ErrorActionPreference='Stop'
function Copy-Tree([string]$source,[string]$destination) {
  $directory=[IO.DirectoryInfo]::new($source)
  if (($directory.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Linked directories are not managed asset files.' }
  [void][IO.Directory]::CreateDirectory($destination)
  foreach ($entry in $directory.GetFileSystemInfos()) {
    if (($entry.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Linked files are not managed asset files.' }
    $target=[IO.Path]::Combine($destination,$entry.Name)
    if (($entry.Attributes -band [IO.FileAttributes]::Directory) -ne 0) { Copy-Tree $entry.FullName $target }
    else { [IO.File]::Copy($entry.FullName,$target,$false); [IO.File]::SetLastWriteTimeUtc($target,$entry.LastWriteTimeUtc) }
  }
}
"""
		script += "Copy-Tree '" + absolute_source.replace("'", "''") + "' '" + absolute_destination.replace("'", "''") + "'"
		var executable := OS.get_environment("SystemRoot").path_join("System32/WindowsPowerShell/v1.0/powershell.exe")
		status = OS.execute(executable, PackedStringArray(["-NoProfile", "-NonInteractive", "-EncodedCommand", Marshalls.raw_to_base64(script.to_utf16_buffer())]), output, true)
	else:
		problems.append("此系统没有配置保留文件时间的复制方式，未改动当前资产。"); return false
	if status != 0:
		problems.append("无法保留原文件及修改时间，未替换当前资源。系统复制工具：" + "".join(output).left(1200)); return false
	return _plain_tree(destination)

func _plain_tree(path: String) -> bool:
	var directory := DirAccess.open(path)
	if directory == null: problems.append("无法读取受管理文件目录：" + path); return false
	directory.include_hidden = true
	for name in directory.get_files():
		if directory.is_link(name) or not FileAccess.file_exists(path.path_join(name)):
			problems.append("受管理目录包含链接或非常规文件：" + name); return false
	for name in directory.get_directories():
		if directory.is_link(name): problems.append("受管理目录包含目录链接：" + name); return false
		if not _plain_tree(path.path_join(name)): return false
	return true
