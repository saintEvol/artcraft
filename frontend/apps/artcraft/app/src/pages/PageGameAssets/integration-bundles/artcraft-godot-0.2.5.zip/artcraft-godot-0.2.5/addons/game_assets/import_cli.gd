extends SceneTree
## Supported command-line entry for CI and developers using the same component.
const Importer := preload("res://addons/game_assets/importer.gd")
const Builder := preload("res://addons/game_assets/resource_builder.gd")
const Report := preload("res://addons/game_assets/engine_report.gd")
const EditorResources := preload("res://addons/game_assets/editor_resources.gd")

func _init() -> void:
	call_deferred("_run")

func _run() -> void:
	var args := OS.get_cmdline_user_args()
	if args.size() < 1:
		push_error("用法：--script res://addons/game_assets/import_cli.gd -- /path/to/unpacked-pack [cancel|keep|copy|replace]")
		quit(2); return
	var importer := Importer.new()
	var ok := importer.import_pack(args[0], args[1] if args.size() > 1 else "cancel")
	if not ok:
		_save_result(importer.failure_report()); push_error("\n".join(importer.report)); quit(1); return
	if importer.result.get("kept_current", false):
		quit(0 if _save_result(importer.result) else 1); return
	var filesystem := EditorInterface.get_resource_filesystem()
	if not await EditorResources.scan(filesystem, self):
		importer.rollback(); _save_result(importer.failure_report(["资源扫描超时，已请求恢复原文件。"])); push_error("资源扫描超时。"); quit(1); return
	var builder := Builder.new()
	if not builder.build(importer.manifest_data, importer.managed_root, importer.managed_namespace) or not importer.finish_import():
		importer.rollback(); _save_result(importer.failure_report(builder.problems)); push_error("\n".join(importer.report)); quit(1); return
	if not _save_result(importer.result):
		push_error("无法保存导入报告。"); quit(1); return
	print("ARTCRAFT_IMPORT_OK ", builder.preview_path)
	quit(0)

func _save_result(value: Dictionary) -> bool:
	if String(value.get("pack_id", "")).is_empty():
		push_error("清单无法识别资源包身份，没有生成可上传的报告。")
		return false
	var report_path := "user://game_assets_reports/%s-import-%s-%s.json" % [String(value.pack_id).validate_filename(), Time.get_unix_time_from_system(), Crypto.new().generate_random_bytes(4).hex_encode()]
	if not Report.save(value, report_path): return false
	print("ARTCRAFT_IMPORT_REPORT ", ProjectSettings.globalize_path(report_path))
	return true
